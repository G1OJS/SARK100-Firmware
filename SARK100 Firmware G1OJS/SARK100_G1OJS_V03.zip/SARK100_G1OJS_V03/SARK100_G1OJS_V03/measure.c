//*****************************************************************************/
//  This file is a part of the "SARK100 SWR Analyzer firmware"
//
//	Copyright © 2025 Alan Robinson G1OJS Hampshire England G1OJS@yahoo.com with 
//  acknowledgement & thanks to Melchor Varela © 2010, EA4FRB Madrid, Spain 
//	(melchor.varela@gmail.com) for the overall software and ideas.
//
//  Copyright © 2010 Melchor Varela - EA4FRB.  All rights reserved.
//  Melchor Varela, Madrid, Spain.
//  melchor.varela@gmail.com
//  
//  "SARK100 SWR Analyzer firmware" is free software: you can redistribute it
//  and/or modify it under the terms of the GNU General Public License as
//  published by the Free Software Foundation, either version 3 of the License,
//  or (at your option) any later version.
//
//  "SARK100 SWR Analyzer firmware" is distributed in the hope that it will be
//  useful,  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with "SARK100 SWR Analyzer firmware".  If not,
//  see <http://www.gnu.org/licenses/>.
//*****************************************************************************/
//*****************************************************************************/
//
//	PROJECT:	SARK100 SWR Analyzer
// 	FILE NAME: 	measure.c
// 	AUTHOR:		G1OJS - Alan Robinson
// 	DESCRIPTION	Bridge measurement routines
// 	HISTORY
//	NAME   		DATE		REMARKS
//	MVM	   		DEC 2009	EA4FRB - creation	
//	G1OJS V03	Feb 2025	G1OJS  - rewrite & refactoring 
//*****************************************************************************/
#include "measure.h"

#include "PSoCAPI.h"
#include "glb_data.h"
#include "dds.h"
#include "util.h"

// Port settings
#define VfPort AMUX4_ADC_PORT0_1
#define VrPort AMUX4_ADC_PORT0_3
#define VzPort AMUX4_ADC_PORT0_5
#define VaPort AMUX4_ADC_PORT0_7

//-----------------------------------------------------------------------------
//  Prototypes
//-----------------------------------------------------------------------------
static WORD Read_ADC (BYTE VxPort);
//-----------------------------------------------------------------------------
//  FUNCTION NAME:	MeasureBridgeRatios
//  DESCRIPTION: Read all bridge voltages and set global ratios Vr/Vf and Vz/Va
//  NOTES:
//    - WORD with wUNITY=1000 can encode ratios from 0.001 to 65.535 
//	    which represents impedance from zero via 0.05 to 3276.75 ohms and 
//	    VSWR from 1.00:1 via 1.002:1 in 2% steps to ~8000:1 where Vr=3999 and Vf=4000 
//    - 3k ohms can be seen on open circuit at lower frequencies, so we need to 
//      cap the ratio 1000*Vz/Va at WORD_MAX, which is done in wDivide(WORD w1, WORD w2)
//    - Vr can sometimes slightly exceed Vf due to measurement error, but
//      this is capped after correction in CorrectBridgeRatios and the raw (uncorrected)
//      ratio is only ever seen if verbose pcLink is used in which case assume expert user 
//      and don't hide the measurement errors, but still use wDivide for WORD_MAX safety
//  ARGUMENTS: None
//  RETURNS: Nothing, but sets global variables:
//     g_xBridge.wVzVa (wUNITY x "Vz/Va")
//     g_xBridge.wVrVf (wUNITY x "Vr/Vf")
//-----------------------------------------------------------------------------
void MeasureBridgeRatios ( void )
{
	SetPowerDDS(ON);  // DDS is off by default, so turn it on
	g_xBridge.wVzVa = wDivide(Read_ADC(VzPort),Read_ADC(VaPort));
	g_xBridge.wVrVf = wDivide(Read_ADC(VrPort),Read_ADC(VfPort));
	SetPowerDDS(OFF); // Turn DDS off (this function isn't called from VFO mode)
}
//-----------------------------------------------------------------------------
//  FUNCTION NAME:	DDSOutputVoltage
//  DESCRIPTION: 	Turn on DDS and measure Vf for DDS output health
//  ARGUMENTS: 		None
//  RETURNS: 		WORD = Vf
//-----------------------------------------------------------------------------
WORD DDSOutputVoltage(void)
{	
	WORD wVal;
	SetPowerDDS(ON);
	wVal=Read_ADC(VfPort);
	if(g_bMode != MODE_VFO) SetPowerDDS(OFF);
	return wVal;
}
//-----------------------------------------------------------------------------
//  FUNCTION NAME:	ExternalRFVoltage
//  DESCRIPTION: 	Measure Vz for external RF check / power measurement
//  				Rough cal at 1MHz:
//						+10dBm = 1300,  +5dBm = 640,  0dBm = 380, -5dBm = 200, 
//						-10dBm =  100, -15dBm = 60, -20dBm = 40
//  ARGUMENTS: 		None
//  RETURNS: 		WORD = Vz
//-----------------------------------------------------------------------------
WORD ExternalRFVoltage(void)
{	// read Vz without turning DDS on or off (called from both SIG and VFO mode)					
	return Read_ADC(VzPort);
}
//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Read_ADC
//  DESCRIPTION:	Set & turn on DDS, and read the specified value
//  ARGUMENTS:		BYTE VxPort - which port (see #defines above)
//  RETURNS: 		Measured value
//-----------------------------------------------------------------------------
static WORD Read_ADC (BYTE VxPort)
{
	WORD wVal;
	AMUX4_ADC_InputSelect(VxPort);					// Select the input port needed to be read
	if(VxPort==VrPort) PGA_ADC_SetGain(PGA_ADC_G5_33);
	if (g_bMode!=MODE_SIG)	DDS_Set(g_dwCurrHz);	// Set freq & turn on DDS
	Delay_64ths(1);
	ADCINC12_GetSamples(1);               	    	// Ask for 1 sample
    while(ADCINC12_fIsDataAvailable() == 0);    	// Wait until next reading ready  
	wVal=(WORD)ADCINC12_iGetData()+2048;			// Take the reading
    ADCINC12_ClearFlag();                       	// Clear ADC flag  
	if(VxPort==VrPort) PGA_ADC_SetGain(PGA_ADC_G2_67);
  	
	return wVal; 	// Return the reading
}




