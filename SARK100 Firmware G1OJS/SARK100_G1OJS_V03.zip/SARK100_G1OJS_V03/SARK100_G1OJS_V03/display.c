//*****************************************************************************/
//  This file is a part of the "SARK100 SWR Analyzer firmware"
//
//  Copyright © 2010 Melchor Varela - EA4FRB.  All rights reserved.
//  Melchor Varela, Madrid, Spain.
//  melchor.varela@gmail.com
//
//  Modified in 2024 by Alan Robinson G1OJS Hampshire England G1OJS@yahoo.com 
//
//  "SARK100 SWR Analyzer firmware" is free software: you can redistribute it
//  and/or modify it under the terms of the GNU General Public License as
//  published by the Free Software Foundation, either version 3 of the License,
//  or (at your option) any later version.
//
//  "SARK100 SWR Analyzer firmware" is distributed in the hope that it will be
//  useful,  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with "SARK100 SWR Analyzer firmware".  If not,
//  see <http://www.gnu.org/licenses/>.
//*****************************************************************************/
//*****************************************************************************/
//
//	PROJECT:	SARK100 SWR Analyzer
// 	FILE NAME: 	DISPLAY.C
// 	AUTHOR:		Melchor Varela
//
// 	DESCRIPTION
//
//	Display utility functions
//
// 	HISTORY
//
//	NAME   		DATE		REMARKS
//
//	MVM	   		DEC 2009	Creation
//
//  G1OJSv1.0	DEC 2024	New screen layouts
//
//*****************************************************************************/
#include "Display.h"

#include <stdlib.h>
#include <string.h>
#include <m8c.h>
#include "Lcd.h"
#include "Util.h"
#include "Msg_generic.h"
#include "glb_data.h"

//-----------------------------------------------------------------------------
// Simler one-line functions to pass through Startup, Clear display, Display on no cursor, write to LCD
//-----------------------------------------------------------------------------
void DISP_Setup(void) 													{ LCD_Start(); LCD_InitBG(LCD_SOLID_BG);			}
void DISP_Clear(void) 													{ LCD_Control(LCD_CLEAR); 							}
void DISP_HideCursor(void) 												{ LCD_Control(LCD_ON);								}
void DISP_CStrAtRowCol(BYTE bRow, BYTE bCol, const char * sRomString)	{ LCD_Position(bRow, bCol); LCD_PrCString(sRomString);}
void DISP_StrAtRowCol(BYTE bRow, BYTE bCol, char * sString)				{ LCD_Position(bRow, bCol); LCD_PrString(sString);	}

//-----------------------------------------------------------------------------
// Longer functions
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//  FUNCTION NAME: DISP_Frequency
//
//  DESCRIPTION:
//
//	Display VFO frequency g_dwCurrHz in the current cursor position
//
//  ARGUMENTS:
//    none
//
//  RETURNS:
//    none.
//
//-----------------------------------------------------------------------------

void DISP_Frequency ( void )
{
	// display planner ...
	// 0123456789012345
	//        56295.350
	
	// display integer part
	ultoa(g_buffer16, g_dwCurrHz/1000, 10);
	DISP_CStrAtRowCol(0, 7, " ");			// in case we go from >=10MHz to below
	DISP_StrAtRowCol(0, 12-strlen(g_buffer16), g_buffer16);
	// display decimal point
	DISP_CStrAtRowCol(0, 12, ".");
	// display three decimal places
	ultoa(g_buffer16, g_dwCurrHz %1000, 10);
	DISP_CStrAtRowCol(0, 13, "00");			// provide leading zeros if needed
	DISP_StrAtRowCol(0, 16-strlen(g_buffer16), g_buffer16);
	
	// position the cursor to mark the frequency increment digit
	LCD_Position(0, g_xIncCtrl[g_bIncDigit].bCol);  
	// show the undescore normally, but if in IncDigitSelect mode show the block
	if (g_bIncDigitSelect) {LCD_Control(LCD_ON_BLINK);} else {LCD_Control(LCD_ON_CURSOR);}
}


//-----------------------------------------------------------------------------
//  FUNCTION NAME: DISP_SRXZ()
//
//  DESCRIPTION:
//
//	Display current impedance
//
//  ARGUMENTS:
//	  uses global char g_bSgnX as a flag (* means display ***)
//    can be set before calling, or set by the function
//
//  RETURNS:
//    none.
//
//-----------------------------------------------------------------------------
void DISP_SRXZ (void)
{
	// display planner ...
	// SWR0.0 51000.000
	// R999 X-j999 Z999
	// 0123456789012345
	
	// SWR top left
	DISP_CStrAtRowCol(0,3,gBlankStr_4);
	ultoSpecial((DWORD)g_wSwr100/10, 3);
	DISP_StrAtRowCol(0, 6-strlen(g_buffer16), g_buffer16);

	// clear bottom row
	DISP_CStrAtRowCol(1, 0, gBlankStr_16);

	// R bottom left
	DISP_CStrAtRowCol(1, 0, "R");
	ultoSpecial((DWORD)g_wR10, 3);
	DISP_StrAtRowCol(1, 4-strlen(g_buffer16), g_buffer16);

	// X bottom middle
	DISP_CStrAtRowCol(1, 5, "X");	
	ultoSpecial((DWORD)g_wX10, 3);
	LCD_Position(1, 11-(strlen(g_buffer16)+2));
	LCD_WriteData(g_bSgnX);
    LCD_PrCString("j");
	LCD_PrString(g_buffer16);
	
	// Z bottom right
	DISP_CStrAtRowCol(1, 12, "Z");
	ultoSpecial((DWORD)g_wZ10, 3);
	DISP_StrAtRowCol(1, 16-strlen(g_buffer16), g_buffer16);

}


//-----------------------------------------------------------------------------
//  FUNCTION NAME: DISP_Capacitance
//
//  DESCRIPTION:
//
//	Display capacitance
//
//  ARGUMENTS:
//		uses global values:
//		WORD g_wC10		10 x (Capacitance in pF)
//		WORD g_wR10		10 x (R in ohms)
//
//  RETURNS:
//    none.
//
//-----------------------------------------------------------------------------
void DISP_Capacitance (void)
{
	// clear bottom row
	DISP_CStrAtRowCol(1, 0, gBlankStr_16);
	
	if(g_wX10==0) {
		DISP_CStrAtRowCol(1, 0, gZeroReactanceStr);
	} else {
		ultoSpecial(g_wC10,4);
		DISP_StrAtRowCol(1, 0, g_buffer16);
		LCD_PrCString("pF R=");
		ultoSpecial(g_wR10,4);
		LCD_PrString(g_buffer16);
		LCD_PrCString("\xf4");
	}
}

//-----------------------------------------------------------------------------
//  FUNCTION NAME: DISP_Inductance
//
//  DESCRIPTION:
//
//	Display inductance
//
//  ARGUMENTS:
//		uses global values:
//		WORD g_wL10	10 x (Inductance in uH)
//		WORD g_wR10	10 x (R in ohms) 
//
//  RETURNS:
//    none
//
//-----------------------------------------------------------------------------
void DISP_Inductance ( void )
{
	DISP_CStrAtRowCol(1, 0, gBlankStr_16);	// clear bottom row
	ultoSpecial(g_wL10,4);
	DISP_StrAtRowCol(1, 0, g_buffer16);
	LCD_PrCString("uH R=");
	ultoSpecial(g_wR10,4);
	LCD_PrString(g_buffer16);
	LCD_PrCString("\xf4");
}

//-----------------------------------------------------------------------------
//  FUNCTION NAME: 	DISP_Power
//  DESCRIPTION: 	Display power at measurement port
//					Uses mVRMS = Vz / CAL_Vz_TO_mVRMS  for mVRMS display
//						 dBm   = 20*(Vz - CAL_Vz_TO_dBm) / (Vz + CAL_Vz_TO_dBm)
//
//1 MHz					
//		dBm(RSP1a)	Vrms_true	Vz_ADC	Vz_ADC*1000=Vrms x		n		20*(VzADC-n)/(VzADC+n)	
//		-8.8		79.9		311		3893					750		-9	
//		0.0			220.0		771		3504					750		0	
//		6.8			481.3		1747	3629					750		7	
//							
//10MHz	
//		dBm(RSP1a)	Vrms_true	Vz_ADC	Vz_ADC*1000=Vrms x		n		20*(VzADC-n)/(VzADC+n)	
//		-11.7		57.2		208		3636					750		-12	
//		-0.1		217.5		709		3260					750		-1	
//		7.2			504.0		1677	3327					750		7	
//							
//								Average	3542					750		
//										= CAL_Vz_TO_mVRMS		=CAL_Vz_TO_dBm
//
//  ARGUMENTS:		WORD: Measured Vz
//  RETURNS:  		none
//-----------------------------------------------------------------------------

void DISP_Power(WORD wVz)
{
	float mVRMS;
	DISP_CStrAtRowCol(1,0, gPowerLabelsStr);
	
	#define CAL_Vz_TO_mVRMS 	3542
	itoa(g_buffer16,(INT)( ((LONG)wVz*wUNITY)/CAL_Vz_TO_mVRMS  ),10); 
	DISP_StrAtRowCol(1, 3, g_buffer16);
	
	#define CAL_Vz_TO_dBm 	750
	#define LOG_TO_dB		20
	itoa(g_buffer16,(INT)( (((LONG)wVz-CAL_Vz_TO_dBm)*LOG_TO_dB) / (wVz+CAL_Vz_TO_dBm) ) ,10); 
	DISP_StrAtRowCol(1, 12, g_buffer16);
	
	if (g_bVFOConfig){
		LCD_Position(0, 13);  
		LCD_Control(LCD_ON_CURSOR);
	}

}