//*****************************************************************************/
//  This file is a part of the "SARK100 SWR Analyzer firmware"
//
//	Copyright © 2025 Alan Robinson G1OJS Hampshire England G1OJS@yahoo.com with 
//  acknowledgement & thanks to Melchor Varela © 2010, EA4FRB Madrid, Spain 
//	(melchor.varela@gmail.com) for the overall software and ideas.
//
//  Copyright © 2010 Melchor Varela - EA4FRB.  All rights reserved.
//  Melchor Varela, Madrid, Spain.
//  melchor.varela@gmail.com
//  
//  "SARK100 SWR Analyzer firmware" is free software: you can redistribute it
//  and/or modify it under the terms of the GNU General Public License as
//  published by the Free Software Foundation, either version 3 of the License,
//  or (at your option) any later version.
//
//  "SARK100 SWR Analyzer firmware" is distributed in the hope that it will be
//  useful,  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with "SARK100 SWR Analyzer firmware".  If not,
//  see <http://www.gnu.org/licenses/>.
//*****************************************************************************/
//*****************************************************************************/
//
//	PROJECT:	SARK100 SWR Analyzer
// 	FILE NAME: 	calibrate_reflectometer.c
// 	AUTHOR:		G1OJS - Alan Robinson
// 	DESCRIPTION	Gathers calibration data and implements corrections
// 	HISTORY
//	NAME   		DATE		REMARKS
//	MVM	   		DEC 2009	EA4FRB - creation	
//	G1OJS V03	Feb 2025	G1OJS  - new calibration approach and refactoring 
//*****************************************************************************/
#include "calibrate_reflectometer.h"

#include "util.h"
#include "storage.h"
#include "glb_data.h"
#include "keypad.h"
#include "msg_generic.h"
#include "buzzer.h"
#include "display.h"
#include "calcs.h"

typedef enum {STORE, RETRIEVE} ENCODE_DIRECTION;
typedef enum {MODZ,  MODGAMMA} ENCODE_TYPE;

//-----------------------------------------------------------------------------
//  Prototypes
//-----------------------------------------------------------------------------
static BOOL WaitLoadUser (const char *pszText);
static WORD wXPrime(DWORD dwX, DWORD dwX1, DWORD dwX2, DWORD dwXPrime1, DWORD dwXprime2);
static INT iRatioFromCalibration(ENCODE_DIRECTION xDir, ENCODE_TYPE xType, INT iRatio_true, INT iRatio);
//-----------------------------------------------------------------------------
//  Defines
//-----------------------------------------------------------------------------
// Full scale value with a little headroom for upward fluctuations with frequency
#define VF_REFERENCE_LEVEL	3900 
//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Calibrate_Reflectometer()
//  DESCRIPTION:	Calibration routine
//  ARGUMENTS: 		none.
//  RETURNS:		none.
//-----------------------------------------------------------------------------
void Calibrate_Reflectometer (void)
{
	BYTE bCalFreqIndex;
	BYTE bLoad;
	M8C_EnableGInt ;

	do
	{
		DISP_Clear();
	
		// Find DDS Gain step needed for reasonable Vf 
		// This is also an opportunity to abort the calibration without changing anything:
		if (!WaitLoadUser(gDisconnectLoadStr)) break;
  		DISP_CStrAtRowCol(1, 0, gSettingGainStr);
		g_dwCurrHz=FREQ_MIN_Hz;
		DISP_Frequency();
		for (g_bDDS_GainStep=0;g_bDDS_GainStep<GAIN_SETTINGS_MAX;g_bDDS_GainStep++)
		{
			PGA_DDS_1_SetGain(g_xGainDds[g_bDDS_GainStep].bGain1);
			PGA_DDS_2_SetGain(g_xGainDds[g_bDDS_GainStep].bGain2);
			if ( (DDSOutputVoltage() >= VF_REFERENCE_LEVEL) || (g_bDDS_GainStep==(GAIN_SETTINGS_MAX-1) ) ) break;
		}

		// now measure and store the uncalibrated ratios Vz/Va and Vr/Vf at each cal frequency and load			
		for (bLoad=0; bLoad < CAL_LOAD_MAX; bLoad++)
		{
			if (!WaitLoadUser(gCalLoadStr[bLoad])) break;
			DISP_Clear(); DISP_CStrAtRowCol(1, 0, gCalibratingStr);
			for (bCalFreqIndex=0; bCalFreqIndex<CAL_FREQS_MAX;bCalFreqIndex++)
			{
				g_dwCurrHz=CAL_START_Hz + (DWORD)(bCalFreqIndex * CAL_FREQ_STEP_Hz) ;
				DISP_Frequency();
				MeasureBridgeRatios();
				g_scVzVaCalTable[bCalFreqIndex][bLoad] = (BYTE)iRatioFromCalibration(STORE, MODZ, 	  g_wVzVaTrueArr[bLoad], g_xBridge.wVzVa);
				g_scVrVfCalTable[bCalFreqIndex][bLoad] = (BYTE)iRatioFromCalibration(STORE, MODGAMMA, g_wVrVfTrueArr[bLoad], g_xBridge.wVrVf);
			}
		}

		// Store cal factors in EEPROM
		g_bIsCalibrated=TRUE; // this needs to be set to True here, and only here
		STR_SaveCalibration();
	
		// Finish, alert user
		DISP_Clear();
		DISP_CStrAtRowCol(0,0, gConfigDoCalStr);
		DISP_CStrAtRowCol(1,0, gDoneRestartingStr);
		BUZZER_Morse_End();
		Delay_64ths(TIME_FLASH_MSG);
		M8C_DisableGInt;
		asm ("ljmp 0x0000"); // Perform Software Reset
	
	} while (FALSE);

}
//-----------------------------------------------------------------------------
//  FUNCTION NAME:	iRatioFromCalibration
//
//  DESCRIPTION:	Encodes or decodes a ratio measured during calibration 
//					so that the encoded result can be stored in the
//					BYTE arrays [bCalFreqIndex][bLoad] 
//					The measured ratio is first scaled to the true ratio, and then
//					log-like encoding is used to allow (measured/true) to range from
//						1/2 to 2 for (Vr/Vf measured) / (Vr/Vf true) -> -127 to 127 
//						1/5 to 5 for (Vz/Va measured) / (Vz/Va true) -> -127 to 127
//					hence the result can be encoded in an array of signed char.
//					Using signed innteger for the output and inputs means that the
//					single function can be used in each direction (encode & decode)
//
//  ARGUMENTS:		xDir		= STORE | RETRIEVE
//					xType	 	= MODZ | MODGAMMA
//					iRatio_true	= true ratio for the cal point scaled by wUNITY
//					iRatio		= ratio scaled by wUNITY, or encoded value, to convert 
//
//  RETURNS: 		signed int	= encoded value (range -127 to 127) when encoding
//					signed int	= Measured ratio (range 0 to 32767 scaled by wUNITY) when decoding
//
//	NOTES:			Whilst |Z|/50 can range to 65537/wUNITY, 32767 is enough for
//					the largest calibration load (560 ohms, true ratio 11200/wUNITY)
//					|Gamma| ranges 0 to 1000/wUNITY or slightly over with measurement error
//					The encoded output has zero indicating measured ratio = true ratio, so
//					the calibration table is initialised to zero by default
//-----------------------------------------------------------------------------

static INT iRatioFromCalibration(ENCODE_DIRECTION xDir, ENCODE_TYPE xType, INT iRatio_true, INT iRatio) {
	long lNum;
	long lDenom;
	INT iScale;
	BYTE bDRNG = (xType==MODGAMMA)? 2:4; // dynamic range 1/2.0 to 2.0 or 1/4.0 to 4.0
	
	#define ENC_MAX 127					// encoded range -127 to +127
	
	iScale = (ENC_MAX*(int)(bDRNG+1)) /(int)(bDRNG-1);

	if(xDir==STORE) {
    	lNum = iScale*(long)iRatio - (long)iScale*(long)iRatio_true;
    	lDenom = (long)iRatio + (long)iRatio_true;
		if (lDenom==0) {return 0;} else {				// lim x,y->0 of (x-y)/(x+y) is 0
			lNum /=lDenom;								// re-using the numerator var for the result
			lNum = (lNum>ENC_MAX)? ENC_MAX:lNum;		// clamp at +/- ENC_MAX; better than wrapped if stored in 8 bits
			lNum = (lNum<-ENC_MAX)? -ENC_MAX:lNum;		
    		return lNum; 
		}
	} else {
	    lNum = (long)iRatio_true*(long)iScale+(long)iRatio_true*(long)iRatio;
    	lDenom = (long)iScale - (long)iRatio;
    	return lNum / lDenom;  
	}
}
//-----------------------------------------------------------------------------
//  FUNCTION NAME:	CorrectBridgeRatios()
//  DESCRIPTION:	Interpolate storred correction ratios at frequency cal points
//					to calculate the Vz/Va and Vr/Vf ratios that would have been
//					measured at the current frequency when uncalibrated.
//					Use a mapping function to map the current measured ratios
//					to the true values that they should represent.
//  ARGUMENTS:none
//  RETURNS: none.
//-----------------------------------------------------------------------------
void CorrectBridgeRatios (void)
{
	DWORD dwCalFreq_Lower_kHz;
	WORD wVzVaCalValue[CAL_LOAD_MAX];		// still scope for reducing memory use, as we only need 2 of the load values
	WORD wVrVfCalValue[CAL_LOAD_MAX];		// on any one call of this function (may be diff pair for Vz/Va and Vr/Vf)
	BYTE bCalFreqIndex;
	BYTE bLoad;
	
	// retrieve (from encoded storage) the bridge ratios measured during cal for each cal load, 
	// and interpolate to what would have been measured at the current frequency
	bCalFreqIndex = (g_dwCurrHz - CAL_START_Hz) / CAL_FREQ_STEP_Hz;																		
	dwCalFreq_Lower_kHz = CAL_START_Hz/1000 + (CAL_FREQ_STEP_Hz/1000)*(DWORD)bCalFreqIndex;				
	for (bLoad=0; bLoad < CAL_LOAD_MAX; bLoad++)
	{	
		wVzVaCalValue[bLoad] = wXPrime(g_dwCurrHz/1000, dwCalFreq_Lower_kHz, dwCalFreq_Lower_kHz + CAL_FREQ_STEP_Hz/1000,
				iRatioFromCalibration(RETRIEVE, MODZ, g_wVzVaTrueArr[bLoad], g_scVzVaCalTable[bCalFreqIndex][bLoad]), 
				iRatioFromCalibration(RETRIEVE, MODZ, g_wVzVaTrueArr[bLoad], g_scVzVaCalTable[bCalFreqIndex+1][bLoad]) );			

		wVrVfCalValue[bLoad] = wXPrime(g_dwCurrHz/1000, dwCalFreq_Lower_kHz, dwCalFreq_Lower_kHz + CAL_FREQ_STEP_Hz/1000,
				iRatioFromCalibration(RETRIEVE, MODGAMMA, g_wVrVfTrueArr[bLoad], g_scVrVfCalTable[bCalFreqIndex][bLoad]), 
				iRatioFromCalibration(RETRIEVE, MODGAMMA, g_wVrVfTrueArr[bLoad], g_scVrVfCalTable[bCalFreqIndex+1][bLoad]) );			
	}	
	// At this point, measured ratios (this measurement and the calibration measurements) 
	// are all scaled by wUNITY in WORD with wUNITY -> Vz=Va, Vr=Vf

	// Next, map Vz/Va measured to Vz/Va true based on the true ratios and the ratios retrieved above.
	// If current value of the ratio is below that measured for 50 ohm cal  
	// use slope downwards towards lower cal point. Otherwise use upper slope towards upper cal points.
	if(g_xBridge.wVzVa < wVzVaCalValue[CAL_LOAD_MATCH]) 
	{									
		g_xBridge.wVzVa = wXPrime(g_xBridge.wVzVa, wVzVaCalValue[CAL_LOAD_MATCH], wVzVaCalValue[CAL_LOAD_LOW], g_wVzVaTrueArr[CAL_LOAD_MATCH],  g_wVzVaTrueArr[CAL_LOAD_LOW]);
	}	else if (g_xBridge.wVzVa< wVzVaCalValue[CAL_LOAD_HIGH]) {
		g_xBridge.wVzVa = wXPrime(g_xBridge.wVzVa, wVzVaCalValue[CAL_LOAD_MATCH], wVzVaCalValue[CAL_LOAD_HIGH], g_wVzVaTrueArr[CAL_LOAD_MATCH],  g_wVzVaTrueArr[CAL_LOAD_HIGH]);
	} else {
		g_xBridge.wVzVa = wXPrime(g_xBridge.wVzVa, wVzVaCalValue[CAL_LOAD_HIGH], wVzVaCalValue[CAL_LOAD_HIGH2], g_wVzVaTrueArr[CAL_LOAD_HIGH],  g_wVzVaTrueArr[CAL_LOAD_HIGH2]);
	}
	
	// Also do similar for Vr/Vf, now using corrected Vz/Va compared with Vz/Va=1 (50 ohms) to decide which half of the V slope to use
	if(g_xBridge.wVzVa < wUNITY) 
	{	// lower side of the V has only one slope from match to lower cal load
		g_xBridge.wVrVf = wXPrime(g_xBridge.wVrVf, wVrVfCalValue[CAL_LOAD_MATCH], wVrVfCalValue[CAL_LOAD_LOW], g_wVrVfTrueArr[CAL_LOAD_MATCH], g_wVrVfTrueArr[CAL_LOAD_LOW]);						
	} else { // upper side of the "V" is split into two slopes and the portion is determined by wVrVf
		if(  g_xBridge.wVrVf < wVrVfCalValue[CAL_LOAD_HIGH] ) {					
			g_xBridge.wVrVf  = wXPrime(g_xBridge.wVrVf, wVrVfCalValue[CAL_LOAD_MATCH], wVrVfCalValue[CAL_LOAD_HIGH], g_wVrVfTrueArr[CAL_LOAD_MATCH], g_wVrVfTrueArr[CAL_LOAD_HIGH]);	
		} else {
			g_xBridge.wVrVf  = wXPrime(g_xBridge.wVrVf, wVrVfCalValue[CAL_LOAD_HIGH], wVrVfCalValue[CAL_LOAD_HIGH2],g_wVrVfTrueArr[CAL_LOAD_HIGH], g_wVrVfTrueArr[CAL_LOAD_HIGH2]);	
		}
	}
		
	// Vr>Vf represents a failure in the assumptions in the calibration model and is better corrected by a simple cap
	// Also calculating SWRx100 in WORD from wUNITYxVr/Vf needs wUNITYxVr/Vf slightly less than wUNITY, so cap at that value rather than wUNITY  
	if(g_xBridge.wVrVf > VR_OVER_VF_MAX) g_xBridge.wVrVf = VR_OVER_VF_MAX;
}
//-----------------------------------------------------------------------------
//  FUNCTION NAME:	wXPrime(DWORD dwX, DWORD dwX1, DWORD dwX2, DWORD dwXPrime1, DWORD dwXPrime2)
//
//  DESCRIPTION:
//
//	Maps the range dwX1 .. dwX2 onto dwX1' .. dwX2'
//  Where dwX2 > dwX1 and dwXPrime2 > dwXPrime1
//  dwX>dwX2 is OK but note simple linear extrapolation based on X and X' ranges
//  dwX1' < dwX2' is OK provided both are positive and note that the return value must be positive 
//  Result is artificially enforced to be no less than zero and no greater than 
//  WORD_MAX (so no wrap around in WORD)
//  The function works to the precision set by the wUNITY #def
//
//  ARGUMENTS:
//		dwX - the value to map
//		dwX1, dwX2, dwX1', dwX2' end points of the mapping ranges
//
//  RETURNS:
//     wX' - the input value mapped into the range dwX1' .. dwX2'
//
//-----------------------------------------------------------------------------
static WORD wXPrime(DWORD dwX, DWORD dwX1, DWORD dwX2, DWORD dwXPrime1, DWORD dwXPrime2)
{
	// inputs are DWORD because of need to scale numerator again by wUNITY
	// use signed below because (wUNITY - lAlpha) can be negative
	long lAlpha = (DWORD)((DWORD)wUNITY*abs(dwX - dwX1)) / abs(dwX2 - dwX1);
	long tmp = (long)(lAlpha * (long)dwXPrime2)/(long)wUNITY;
	tmp += (long)dwXPrime1*((long)wUNITY - lAlpha)/(long)wUNITY;
	if(tmp < 0) tmp=0;
	if(tmp > WORD_MAX) tmp=WORD_MAX;
	return (WORD)tmp;
}

//-----------------------------------------------------------------------------
//  FUNCTION NAME:	WaitLoadUser()
//  DESCRIPTION:	Wait for user to change loads and confirm
//  ARGUMENTS:		pszText	Text in display
//  RETURNS: 		FALSE user abort
//-----------------------------------------------------------------------------
static BOOL WaitLoadUser (const char *pszText)
{
	DISP_Clear(); DISP_CStrAtRowCol(0,0, pszText);
	if(!getUserConfirmation()) return FALSE;
	
	BUZZER_Beep();
	DISP_CStrAtRowCol(0,0, gBlankStr_16);
	return TRUE;
}
//-----------------------------------------------------------------------------
//  FUNCTION NAME:	MeasureCorrectCalc()
//  DESCRIPTION: 	Measure, do correction, do calcs
//					Might be tidier to put this in the measure.c file ...
//  ARGUMENTS: 		none
//  RETURNS: 		none
//-----------------------------------------------------------------------------
void MeasureCorrectCalc(void)
{	
	MeasureBridgeRatios();
	CorrectBridgeRatios();
	Do_SZRX_Calcs();
	if(g_bMode==MODE_CAP) Calculate_C();
	if(g_bMode==MODE_IND) Calculate_L();
}
