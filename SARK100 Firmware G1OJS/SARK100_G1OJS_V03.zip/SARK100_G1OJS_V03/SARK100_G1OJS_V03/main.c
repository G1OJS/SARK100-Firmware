//*****************************************************************************/
//  This file is a part of the "SARK100 SWR Analyzer firmware"
//
//  Copyright © 2010 Melchor Varela - EA4FRB.  All rights reserved.
//  Melchor Varela, Madrid, Spain.
//  melchor.varela@gmail.com
//
//  Modified in 2024 by Alan Robinson G1OJS Hampshire England G1OJS@yahoo.com 
//
//  "SARK100 SWR Analyzer firmware" is free software: you can redistribute it
//  and/or modify it under the terms of the GNU General Public License as
//  published by the Free Software Foundation, either version 3 of the License,
//  or (at your option) any later version.
//
//  "SARK100 SWR Analyzer firmware" is distributed in the hope that it will be
//  useful,  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with "SARK100 SWR Analyzer firmware".  If not,
//  see <http://www.gnu.org/licenses/>.
//*****************************************************************************/
//*****************************************************************************/
//
//	PROJECT:	SARK100 SWR Analyzer
// 	FILE NAME: 	MAIN.C
// 	AUTHOR:		EA4FRB - Melchor Varela
//
// 	DESCRIPTION
//
//	Main program logic
//
// 	HISTORY
//
//	NAME   		DATE		REMARKS
//
//	MVM	   		DEC 2009	Creation
//
//  G1OJSv1.0	DEC 2024	Functional changes (see release notes)
//							added comments, functions & variable names more descriptive
//							more compact code layout & compact forms
//							
//
//*****************************************************************************/
#include <stdlib.h>
#include <m8c.h>
#include "Util.h"
#include "Display.h"
#include "glb_data.h"
#include "msg_generic.h"
#include "storage.h"
#include "keypad.h"
#include "buzzer.h"
#include "calibrate_reflectometer.h"
#include "pclink.h"

//-----------------------------------------------------------------------------
//  Prototypes
//-----------------------------------------------------------------------------
static void Do_VSWR_Scan (BYTE bBand);
static void Do_Config_Menu (void);
static void Do_Dizzle(void);
static void Load_Firmware(void);
static void Config_ByteSettingItem(const char **sSettingStrings, BYTE *bSetting, BYTE bMaxValue);
//-----------------------------------------------------------------------------
//  MAIN
//-----------------------------------------------------------------------------
void main(void)
{
	BYTE bBand;
	BYTE bKey = 0;
	BYTE SpeedKeysOn = 0;
	DWORD dwSaveFreqBand[BAND_MAX];		// Stores frequency val when switching bands
	
	M8C_ClearWDTAndSleep;		
	M8C_EnableIntMask(INT_MSK0, INT_MSK0_SLEEP);
	M8C_EnableGInt;					
	DISP_Setup();						// Initialise display
	
	SetPowerDigitalAndAnalogue(ON);
	
	// Display welcome screen
	DISP_CStrAtRowCol(0,0, g_welcome1Str);
	DISP_CStrAtRowCol(1,0, g_welcome2Str);
	Delay_64ths(TIME_FLASH_MSG);

	STR_Restore();					// Load cal and config data from EEPROM, with warning message if not calibrated
	SetDDSGain();					// it was set at power on but now STR_Restore() has given us a new setting
	
	// Set save band frequency to the center of each band
	for (bBand=0; bBand<BAND_MAX; bBand++) dwSaveFreqBand[bBand] = g_xBandLimits[bBand].middle * BAND_FREQ_ToHz;
	
	// Set current frequency to 20M band
	bBand = BAND_20M;
	g_dwCurrHz = g_xBandLimits[bBand].middle * BAND_FREQ_ToHz;					
										
	// Check Vf level
	if (DDSOutputVoltage()<500)							// Vf too low, warn user
	{
		BUZZER_Morse_Err();
		DISP_CStrAtRowCol(0,0, gErrorAdjustVfStr);
		DISP_CStrAtRowCol(1,0, gPressAnyKeyStr);
		KEYPAD_WaitKey(TIME_WAIT_KEY_S);				// Important, so wait for key press
	}
	
	// ******************************
	// Start main loop
	// ******************************
	DISP_Clear();
	g_bSgnX='?';
	g_bIdleCounter = g_bUserIdle[g_xConf.bUserIdle];	// Initial set Idle counter
	do
	{
		// ******************************
		// Measure and Display block
		// ******************************
		SpeedKeysOn = (bKey==KBD_2xUP || bKey==KBD_2xDWN);		// work out if we are in a fast frequency change state
		DISP_HideCursor();										// don't want the cursor showing until/unless shown by DISP_Frequency();
		DISP_CStrAtRowCol(0,0, gModeStr[g_bMode]);				// display top row for current mode
		if(g_bMode==MODE_VFO) DISP_Power(ExternalRFVoltage());	// 
		if(g_bMode==MODE_SIG) {									// SIG mode doesn't have frequency and can't have fast freq change
			DISP_Power(ExternalRFVoltage());					// So just measure Vz and display power 
		} else {
			if (SpeedKeysOn) {									// if in fast freq change state, we don't do main measure and don't display numbers
				g_bSgnX='*'; 									// so set g_bSgnX to '*' to flag to ultoSpecial to replace all numbers with * 
			} else {
				if (g_bSgnX=='*') g_bSgnX=' ';  				// just came out of fast freq change, so revert to showing numbers		
				if(g_bMode==MODE_IMPN) g_bSgnX='#';				// hide sign of reactance if in IMPNodizzle mode
				if(g_bMode==MODE_IMPD) Do_Dizzle();				// get sign of reactance if in IMPDizzle mode
				if(g_bMode!=MODE_VFO)  MeasureCorrectCalc();	// do the impedance measurement for this cycle
			} 
			// do the numeric displays based on impedance measurement
			if(g_bMode==MODE_IMPD || g_bMode==MODE_IMPN) DISP_SRXZ();
			if(g_bMode==MODE_CAP) DISP_Capacitance();
			if(g_bMode==MODE_IND) DISP_Inductance();
			DISP_Frequency();									// every other display needs frequency
		}

		// ******************************
		// Respond to key presses or timeout and loop
		// ******************************
		g_bMeasureCounter = MEASURE_PERIOD;		
		do
		{
			M8C_Sleep;
			
			// woke up by key press so which key was it?
			bKey = KEYPAD_Get();

			// key presses relevant to all modes:
			if(bKey == KBD_CONFIG)  {
				if (g_bIncDigitSelect) 	 	{g_bIncDigitSelect=0; break;}			// Config acts as an escape key for inc control digit select
				if (g_bMode == MODE_VFO) 	{g_bVFOConfig=~g_bVFOConfig; break;}	// If in VFO mode, config key toggles power setting & monitor options
				Do_Config_Menu(); 
				DISP_Clear();
			}
			
			if(bKey == KBD_SCAN) 	Do_VSWR_Scan(bBand);
			
			if(bKey == KBD_MODE)    {
				cycleParameter(&g_bMode, MODE_MAX, 0); 			// cycle to next MODE
				if (g_bMode == MODE_VFO) SetPowerDDS(ON);		// if going into VFO mode, turn on DDS
			}
			
			// key presses valid in all modes except SIG:
			if (g_bMode != MODE_SIG) {
			
				if(bKey == KBD_UP_DWN) g_bIncDigitSelect = ~g_bIncDigitSelect;	    // Toggle between cursor or frequency change modes
			
				switch ( bKey ) {
					case KBD_BAND:
						dwSaveFreqBand[bBand]=g_dwCurrHz;
						bBand = (bBand+1) % BAND_MAX; if(!bBand) BUZZER_Beep();
						g_dwCurrHz = dwSaveFreqBand[bBand];
						break;

					case KBD_2xUP:								// UP key held down, fall through to KBD_UP
					case KBD_UP:
						if (g_bIncDigitSelect) {cycleParameter(&g_bIncDigit, MAX_INCREMENT, 0); break;} 	// Move frequency cursor left & cycle back to right
						if (g_bVFOConfig) { if(g_bDDS_GainStep<GAIN_SETTINGS_MAX-1) g_bDDS_GainStep++;; SetDDSGain(); break;}				// increase DDS level
						#define min(a,b) (a>b)? b:a;
						g_dwCurrHz = min(g_dwCurrHz + g_xIncCtrl[g_bIncDigit].dwInc, g_xBandLimits[bBand].high * BAND_FREQ_ToHz); break; 	// increase frequency

					case KBD_2xDWN:								// DOWN key held down, fall through to KBD_DWN	
					case KBD_DWN:
						if (g_bIncDigitSelect) {cycleParameter(&g_bIncDigit, MAX_INCREMENT, 1); break;} 	// Move frequency cursor right & cycle back to left
						if (g_bVFOConfig) { if(g_bDDS_GainStep>0) g_bDDS_GainStep--; SetDDSGain(); break;}								// decrease DDS level
						#define max(a,b) (a>b)? a:b;
						g_dwCurrHz = max(g_dwCurrHz - g_xIncCtrl[g_bIncDigit].dwInc, g_xBandLimits[bBand].low * BAND_FREQ_ToHz); break; 	// decrease frequency
				}
			}

			if (bKey!=0) break;
			if (g_bMeasureCounter==0) break;
		} while(1);
	
		// If key was pressed, reset user Idle timer
		if (bKey != 0) g_bIdleCounter = g_bUserIdle[g_xConf.bUserIdle];

		// if idle counter times out, turn analogue and digital off and only turn back on after waking from key press
		// (code waits in KEYPAD_SysSuspendAndWakeFromPress until that happens)
		if ((g_bIdleCounter==0) && (g_bUserIdle[g_xConf.bUserIdle] != 0))
		{				
			SetPowerDigitalAndAnalogue(OFF);
			KEYPAD_SysSuspendAndWakeFromPress();
			SetPowerDigitalAndAnalogue(ON);
			g_bIdleCounter = g_bUserIdle[g_xConf.bUserIdle];
		}
		
	} while (TRUE);
	
}
//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Do_Dizzle
//  DESCRIPTION:  	Briefly step up in frequency & measure reactance. If reactance
//					increased, set sign of reactance to +ve else -ve, except
//					if the change is small, leave sign of reactance as it is.
//  ARGUMENTS:		none
//  RETURNS:		Nothing
//-----------------------------------------------------------------------------
static void Do_Dizzle(void)
{
	WORD wX10_DizBaseline 		= g_wX10;
	DWORD dwDizzlingMemoryHz 	= g_dwCurrHz;
	g_dwCurrHz = g_dwCurrHz*(100+DIZZLING_OFFSET_PERCENT) / 100;	// change to dizzled frequency
	MeasureCorrectCalc();					// find reactance at dizzling frequency
	g_dwCurrHz=dwDizzlingMemoryHz;			// change back to non-dizzled frequency
	if ( (int)(g_wX10-wX10_DizBaseline) > 5 || (g_wX10==0) ) 
		{g_bSgnX = '+';}
	else if ( (int)(wX10_DizBaseline-g_wX10) > 5) 
		{g_bSgnX = '-';}
}
//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Do_VSWR_Scan
//  DESCRIPTION:  	Scanning routine
//  ARGUMENTS:		bBand	Integer describing band number
//  RETURNS:		Nothing
//-----------------------------------------------------------------------------
static void Do_VSWR_Scan (BYTE bBand)
{

	typedef struct							// SCAN_RES definition
	{
		WORD wMinSwr100;
		WORD wMinSwrFreq_kHz;
		WORD wLowFreq_kHz;
		WORD wHighFreq_kHz;	
	} SCAN_RES;

	SCAN_RES xScanResults;
	BYTE bScanStepkHz=250;

	SetPowerDDS(ON);
	do{	// repeat the scan algorithm at smaller step if necessary
	
		BYTE bFlagLocalMinimum=0;
		BYTE bFlagFirstBeep=1;
		xScanResults.wLowFreq_kHz=(g_xBandLimits[bBand].low * BAND_FREQ_ToHz)/1000;  			// set f_low result in case we start the scan below SWR_BW_THRESH
		xScanResults.wHighFreq_kHz=(g_xBandLimits[bBand].high * BAND_FREQ_ToHz)/1000;   		// set f_low result in case we end the scan below SWR_BW_THRESH
		g_dwCurrHz = g_xBandLimits[bBand].low * BAND_FREQ_ToHz;	// set freq to lower band edge
		xScanResults.wMinSwr100 = SWR_BW_THRESH; 				// set min SWR tracker to threshold

		MeasureCorrectCalc();								// get starting SWR
		do 														// scan the whole band
		{	
			DISP_Frequency();
    	 	MeasureCorrectCalc();
			DISP_SRXZ();
		
			if(bFlagFirstBeep && (g_wSwr100 <= SWR_BW_THRESH))
			{							// Beep to indicate 'looks promising'!
				BUZZER_Beep();
				bFlagFirstBeep=0;
			}
		
			// keep track of most recent local minimum SWR seen, and frequency seen at
			if(g_wSwr100 < xScanResults.wMinSwr100) 
			{ 
				xScanResults.wMinSwr100=g_wSwr100;
				xScanResults.wMinSwrFreq_kHz = g_dwCurrHz/1000;
				bFlagLocalMinimum=1; // this might be the global minimum, so the next SWR>THRESH is worth remembering
	   	  	}
		
			// if SWR now going up from below threshold, and we cross the threshold or reach the band edge, 
			// then remember freq as Fhigh and reset the local minimum flag (in case we find another, lower, local min) 
 			if( bFlagLocalMinimum
				&& (g_wSwr100 >= SWR_BW_THRESH || (g_dwCurrHz + ((DWORD)bScanStepkHz)*1000 >= g_xBandLimits[bBand].high * BAND_FREQ_ToHz) ) )
			{
				xScanResults.wHighFreq_kHz=g_dwCurrHz/1000;
				bFlagLocalMinimum=0;  // in case we find another minimum (we want the low -> high after it)
			}
			
			g_dwCurrHz += ((DWORD)bScanStepkHz)*1000;		// next freq
		
		} while (g_dwCurrHz < g_xBandLimits[bBand].high * BAND_FREQ_ToHz);

		if (bScanStepkHz == 1) break;
		bScanStepkHz /=4;
	
		if(xScanResults.wMinSwr100 >=SWR_BW_THRESH)			// no match found - give opportunity to scan again at a finer step
		{
			BUZZER_Beep();
			DISP_CStrAtRowCol(0, 0, gBlankStr_16);
			DISP_CStrAtRowCol(0, 0, gErrNoMatchingStr);
   			DISP_CStrAtRowCol(1, 0, gErrNoMatchContinueStr);
			if (KEYPAD_WaitKey(TIME_WAIT_KEY_S) != KBD_DWN) break;
		}
	
	} while (xScanResults.wMinSwr100 >= SWR_BW_THRESH);
	
	// if a match was found, search downwards from the global minimum to find the closest freq at which SWR goes above threshold
    if(xScanResults.wMinSwr100 < SWR_BW_THRESH)
	{		
		BUZZER_Beep(); // match found
		g_dwCurrHz=1000*(DWORD)xScanResults.wMinSwrFreq_kHz;		// set freq to match freq
		do 
		{												
			g_dwCurrHz -= ((DWORD)bScanStepkHz)*1000;				// next freq down
			DISP_Frequency(); 
			MeasureCorrectCalc(); 
			DISP_SRXZ();
		} 
		while ((g_dwCurrHz > g_xBandLimits[bBand].low * BAND_FREQ_ToHz) && (g_wSwr100 < SWR_BW_THRESH)) ;
		xScanResults.wLowFreq_kHz=g_dwCurrHz/1000;
	
		// Display results & set g_dwCurrHz to min swr freq
		g_dwCurrHz=1000*((DWORD)xScanResults.wMinSwrFreq_kHz);
		DISP_Frequency(); 
		MeasureCorrectCalc();
		DISP_CStrAtRowCol(1, 0, gBlankStr_16);
		DISP_CStrAtRowCol(1, 0, gBandWidthStr);
		ultoa(g_buffer16, (DWORD)xScanResults.wHighFreq_kHz - (DWORD)xScanResults.wLowFreq_kHz	, 10);
		DISP_StrAtRowCol(1, 4, g_buffer16);
	}

	SetPowerDDS(OFF);
	KEYPAD_WaitKey(TIME_WAIT_KEY_S);

}

//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Do_Config_Menu
//
//  DESCRIPTION: 	Configuration routine
//
//  ARGUMENTS: 		none.
//
//  RETURNS: 		none.
//-----------------------------------------------------------------------------
static void Do_Config_Menu (void)
{
	BYTE bMenu = 0;
	BYTE bKey;

	DISP_Clear(); DISP_HideCursor();
	
	do  {	
		DISP_CStrAtRowCol(0, 0, gBlankStr_16);
		DISP_CStrAtRowCol(0, 0, gConfigStr[bMenu]);
		bKey = KEYPAD_WaitKey(TIME_WAIT_KEY_S);
		if (bKey==KBD_UP) 		return;
		if (bKey==KBD_CONFIG) 	cycleParameter(&bMenu, CONFIG_MAX, 0);	
		if (bKey==KBD_DWN) {
			if (bMenu==CONFIG_PCLINK) 	{ PcLink(); return; }
			if (bMenu==CONFIG_Idle) 	{ Config_ByteSettingItem(gIdleStr, &g_xConf.bUserIdle, USER_IDLE_MAX); return;}
			if (bMenu==CONFIG_CWPitch) 	{ Config_ByteSettingItem(gCWPitchStr, &g_xConf.bCWPitch, CWPitch_MAX); return;}
			if (bMenu==CONFIG_CALIB) 	{ Calibrate_Reflectometer();	return;	}	
			if (bMenu==CONFIG_SW_LOAD) 	{ Load_Firmware(); return; }
		}
	} while (TRUE);
}

//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Config_ByteSettingItem
//
//  DESCRIPTION:	On keypress 'config' steps through the values of a parameter
//					defined by a BYTE setting. At any point, pressing UP cancels 
//					the operation, pressing down confirms saving the displayed value.
//  ARGUMENTS:
//      const char **sSettingStrings, pointer to the array of pointers to the setting 
//									  strings for the parameter from glb_data.h
//		BYTE *bSetting,	pointer to the parameter to be set
//		BYTE bMaxValue, maximum value at which the value returns to zero
//
//  RETURNS: none.
//-----------------------------------------------------------------------------
static void Config_ByteSettingItem(const char **sSettingStrings, BYTE *bSetting, BYTE bMaxValue)
{
	BYTE bCurrValue = *bSetting;
	BYTE bKey;
	DISP_CStrAtRowCol(1, 0, sSettingStrings[bCurrValue]);
	do {
		DISP_CStrAtRowCol(1, 0, sSettingStrings[bCurrValue]);
		bKey = KEYPAD_WaitKey(TIME_WAIT_KEY_S);
		if (bKey==KBD_CONFIG) 	cycleParameter(&bCurrValue, bMaxValue, 0);
		if (bKey==KBD_UP) 		break;
		if (bKey==KBD_DWN){
			*bSetting = bCurrValue;
			STR_SaveConfig();
			DISP_CStrAtRowCol(1, 8, gValueSavedStr);
			Delay_64ths(TIME_FLASH_MSG);
			return;
		}
	} while(TRUE);
	
	DISP_CStrAtRowCol(1, 0, gNothingChangedStr);
	Delay_64ths(TIME_FLASH_MSG);
}

// Function to handle the load firmware branch of the config menu
static void Load_Firmware(void)
{
	if(getUserConfirmation()) {
		DISP_Clear(); DISP_CStrAtRowCol(0, 0, gSwLoadingStr);
		M8C_DisableGInt;
		asm ("ljmp 0x0000"); 	// Perform Software Reset
	}
}
