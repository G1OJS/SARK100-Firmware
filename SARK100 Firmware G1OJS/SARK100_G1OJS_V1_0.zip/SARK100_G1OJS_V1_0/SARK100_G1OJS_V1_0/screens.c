//*****************************************************************************/
//  This file is a part of the "SARK100 SWR Analyzer firmware"
//
//	Copyright © 2025 Alan Robinson G1OJS Hampshire England G1OJS@yahoo.com with 
//  acknowledgement & thanks to Melchor Varela © 2010, EA4FRB Madrid, Spain 
//	(melchor.varela@gmail.com) for the overall software and ideas.
//  
//  "SARK100 SWR Analyzer firmware" is free software: you can redistribute it
//  and/or modify it under the terms of the GNU General Public License as
//  published by the Free Software Foundation, either version 3 of the License,
//  or (at your option) any later version.
//
//  "SARK100 SWR Analyzer firmware" is distributed in the hope that it will be
//  useful,  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with "SARK100 SWR Analyzer firmware".  If not,
//  see <http://www.gnu.org/licenses/>.
//*****************************************************************************/
//*****************************************************************************/
//
//	PROJECT:	SARK100 SWR Analyzer
// 	FILE NAME: 	screens.c
// 	AUTHOR:		G1OJS - Alan Robinson
// 	DESCRIPTION	Display Screens for different modes and results
// 	HISTORY
//	NAME   		DATE		REMARKS
//	AJR			Feb 2025	G1OJS - creation
//*****************************************************************************/
#include "screens.h"

#include <stdlib.h>
#include <string.h>
#include <m8c.h>
#include "Lcd.h"
#include "control.h"
#include "Msg_generic.h"
#include "glb_data.h"
#include "keypad.h"
#include "timers.h"

void ultoSpecial(DWORD dwVal, BYTE maxLen);
#define LCD_CLEAR			0x01
#define LCD_ON_CURSOR		0x0e
#define LCD_ON_BLINK		0x0d

//-----------------------------------------------------------------------------
// Simpler one-line functions to pass through Clear display, Display on no cursor, write strings to LCD
//-----------------------------------------------------------------------------
void Screen_Clear(void) 													{ LCD_Control(LCD_CLEAR); 							}
void Screen_HideCursor(void) 												{ LCD_Control(LCD_CURSOR_OFF);								}
void Screen_CStr(const char * sRomString)									{ LCD_PrCString(sRomString);}
void Screen_Str(char * sString)												{ LCD_PrString(sString);	}
void Screen_CStrAtRowCol(BYTE bRow, BYTE bCol, const char * sRomString)		{ LCD_Position(bRow, bCol); LCD_PrCString(sRomString);}
void Screen_StrAtRowCol(BYTE bRow, BYTE bCol, char * sString)				{ LCD_Position(bRow, bCol); LCD_PrString(sString);	}


//-----------------------------------------------------------------------------
// Longer functions
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//  FUNCTION NAME: 	Screen_Frequency
//  DESCRIPTION:	Display VFO frequency g_dwCurrHz in the current cursor position
//  ARGUMENTS:		none
//  RETURNS:		none.
//-----------------------------------------------------------------------------
void Screen_Frequency(SCREEN_FREQ_UNITS xDisplayRes)
{
	// display planner ...
	// 0123456789012345
	//        56295.350
	BYTE bUnitsCol=15-((xDisplayRes == Display_Hz)? 4:0);
	// display integer part
	utoa(g_buffer16, g_dwCurrHz/1000, 10);
	Screen_CStrAtRowCol(0, bUnitsCol-4, " ");			// in case we go from a longer number to a shorter one
	Screen_StrAtRowCol(0, bUnitsCol+1-strlen(g_buffer16), g_buffer16);
	if (xDisplayRes == Display_Hz){
		// display decimal point
		Screen_CStrAtRowCol(0, bUnitsCol+1, ".000");
		// display three decimal places
		utoa(g_buffer16, g_dwCurrHz %1000, 10);
		Screen_StrAtRowCol(0, bUnitsCol+5-strlen(g_buffer16), g_buffer16);
	}
	
	// show the increment cursor unless in VFO power setting mode or 
	// a function calling here without using full Hz resolution (this is a 
	// shortcut in the logic & really needs separating into another argument)
	if((!g_bUP_DOWN_SelectsVFOPower) && (xDisplayRes==Display_Hz)){
	// position the cursor to mark the frequency increment digit
		LCD_Position(0, g_xIncCtrl[g_bIncDigit].bCol);  
	// show the undescore normally, but if in IncDigitSelect mode show the block
		if (g_bUP_DOWN_SelectsIncDigit) {LCD_Control(LCD_ON_BLINK);} else {LCD_Control(LCD_ON_CURSOR);}
	}
}
//-----------------------------------------------------------------------------
//  FUNCTION NAME: 	Screen_SRXZ()
//  DESCRIPTION:	Display current impedance
//  ARGUMENTS: 		uses global char g_bSgnX as a flag (* means display ***)
//    				can be set before calling, or set by the function
//  RETURNS: 		none.
//-----------------------------------------------------------------------------
void Screen_SRXZ (void)
{
	// display planner ...
	// SWR0.0 51000.000
	// R999 X-j999 Z999
	// 0123456789012345
	Screen_CStrAtRowCol(0,0, gModeStr[g_bMode]);				// display top row for current mode

	// SWR top left
	ultoSpecial((DWORD)g_wSwr100/10, 3);
	Screen_StrAtRowCol(0, 6-strlen(g_buffer16), g_buffer16);

	// clear bottom row
	Screen_CStrAtRowCol(1, 0, gBlankStr_16);

	// R bottom left
	Screen_CStrAtRowCol(1, 0, "R");
	ultoSpecial((DWORD)g_wR10, 3);
	Screen_StrAtRowCol(1, 4-strlen(g_buffer16), g_buffer16);

	// X bottom middle
	Screen_CStrAtRowCol(1, 5, "X");	
	ultoSpecial((DWORD)g_wX10, 3);
	LCD_Position(1, 11-(strlen(g_buffer16)+2));
	LCD_WriteData(g_bSgnX);
    LCD_PrCString("j");
	LCD_PrString(g_buffer16);
	
	// Z bottom right
	Screen_CStrAtRowCol(1, 12, "Z");
	ultoSpecial((DWORD)g_wZ10, 3);
	Screen_StrAtRowCol(1, 16-strlen(g_buffer16), g_buffer16);

}

//-----------------------------------------------------------------------------
//  FUNCTION NAME: 	Screen_Capacitance
//  DESCRIPTION:	Display capacitance
// 	ARGUMENTS:		uses global values:
//						WORD g_wC10		10 x (Capacitance in pF)
//						WORD g_wR10		10 x (R in ohms)
//  RETURNS: none.
//-----------------------------------------------------------------------------
void Screen_Capacitance (void)
{
	Screen_CStrAtRowCol(0,0, gModeStr[g_bMode]);				// display top row for current mode
	// clear bottom row
	Screen_CStrAtRowCol(1, 0, gBlankStr_16);
	if(g_wX10==0) {
		Screen_CStrAtRowCol(1, 0, gZeroReactanceStr);
	} else {
		ultoSpecial(g_wC10,4);
		Screen_StrAtRowCol(1, 0, g_buffer16);
		LCD_PrCString("pF R=");
		ultoSpecial(g_wR10,4);
		LCD_PrString(g_buffer16);
		LCD_PrCString("\xf4");
	}
}

//-----------------------------------------------------------------------------
//  FUNCTION NAME: 	Screen_Inductance
//  DESCRIPTION: 	Display inductance
//  ARGUMENTS:		uses global values:
//						WORD g_wL10	10 x (Inductance in uH)
//						WORD g_wR10	10 x (R in ohms) 
//  RETURNS:  none
//-----------------------------------------------------------------------------
void Screen_Inductance ( void )
{
	Screen_CStrAtRowCol(0,0, gModeStr[g_bMode]);				// display top row for current mode
	Screen_CStrAtRowCol(1, 0, gBlankStr_16);	// clear bottom row
	ultoSpecial(g_wL10,4);
	Screen_StrAtRowCol(1, 0, g_buffer16);
	LCD_PrCString("uH R=");
	ultoSpecial(g_wR10,4);
	LCD_PrString(g_buffer16);
	LCD_PrCString("\xf4");
}

//-----------------------------------------------------------------------------
//  FUNCTION NAME: 	Screen_Power
//  DESCRIPTION: 	Display power at measurement port
//					Uses mVRMS = Vz / CAL_Vz_TO_mVRMS  for mVRMS display
//						 dBm   = 20*(Vz - CAL_Vz_TO_dBm) / (Vz + CAL_Vz_TO_dBm)
//
//1 MHz					
//		dBm(RSP1a)	Vrms_true	Vz_ADC	Vz_ADC*1000=Vrms x		n		20*(VzADC-n)/(VzADC+n)	
//		-8.8		79.9		311		3893					750		-9	
//		0.0			220.0		771		3504					750		0	
//		6.8			481.3		1747	3629					750		7	
//							
//10MHz	
//		dBm(RSP1a)	Vrms_true	Vz_ADC	Vz_ADC*1000=Vrms x		n		20*(VzADC-n)/(VzADC+n)	
//		-11.7		57.2		208		3636					750		-12	
//		-0.1		217.5		709		3260					750		-1	
//		7.2			504.0		1677	3327					750		7	
//							
//								Average	3542					750		
//										= CAL_Vz_TO_mVRMS		=CAL_Vz_TO_dBm
//
//  ARGUMENTS:		WORD: Measured Vz
//  RETURNS:  		none
//-----------------------------------------------------------------------------

void Screen_Power(WORD wVz)
{
	signed char dBm;
	Screen_CStrAtRowCol(0,0, gModeStr[g_bMode]);				// display top row for current mode
	Screen_CStrAtRowCol(1,0, gPowerLabelsStr);
	
	#define CAL_Vz_TO_mVRMS 	3542
	utoa(g_buffer16,(INT)( ((LONG)wVz*wUNITY)/CAL_Vz_TO_mVRMS  ),10); 
	Screen_StrAtRowCol(1, 3, g_buffer16);
	
	#define CAL_Vz_TO_dBm 	750
	#define LOG_TO_dB		20
	dBm = (signed char)( (((long)wVz-CAL_Vz_TO_dBm)*LOG_TO_dB) / (wVz+CAL_Vz_TO_dBm) ); 
	Screen_CStrAtRowCol(1, 12, (dBm<0)? "-":"+");	// avoiding using itoa here means that utoa can be used exclusively, reducing memory requirements by 443 Bytes
	utoa(g_buffer16,(WORD)abs(dBm) ,10); 
	Screen_StrAtRowCol(1, 13, g_buffer16);
	
	Screen_CStrAtRowCol(1, 15, (g_bUP_DOWN_SelectsVFOPower)? "<":" ");

}

// Test floating point version of Screen_Power 
// Uses 2,367 BYTES more than integer version!
/*
void Screen_Power_f(WORD wVz)
{
	#include <math.h>
	#define CAL_Vz_TO_mVRMS 	1638
	float mVRMS = (float)wVz/CAL_Vz_TO_mVRMS;
	Screen_CStrAtRowCol(1,0, gPowerLabelsStr);
	itoa(g_buffer16,(INT)mVRMS,10); 
	Screen_StrAtRowCol(1, 3, g_buffer16);
	itoa(g_buffer16,(INT)(8.6859*log(mVRMS)-46.9897) ,10); 
	Screen_StrAtRowCol(1, 12, g_buffer16);
}
*/

void Screen_CableLength(WORD wLencm)
{	
	// display planner ...
	// Cable len, cm:
	// VF0.81: 99999999
	// 0123456789012345
	BYTE bCnt;
	Screen_HideCursor();
	Screen_Clear();
	Screen_CStrAtRowCol(0, 0, gCableLabels1Str);
	Screen_CStrAtRowCol(1, 0, "VF");
	utoa(g_buffer16,g_bVF[g_xConf.bVF],10); Screen_StrAtRowCol(1, 2,  g_buffer16);
	Screen_CStr(": ");
	utoa(g_buffer16, wLencm/100, 10);
	Screen_Str(g_buffer16);
	Screen_CStr(".");
	utoa(g_buffer16, wLencm % 100, 10);
	Screen_Str(g_buffer16);
	Screen_CStr("m");
	
}

//-----------------------------------------------------------------------------
//  FUNCTION NAME: 	ultoSpecial(DWORD dwVal, BYTE maxLen)
//  DESCRIPTION: 	ultoa with right justification and value-dependent precision
//
//					Given a DWORD dwVal that is 10 times a represented value:
//					dwVal = 0 to 100 results in 0.0 to 9.9
//					dwVal = 100 upwards results in 10, 11, 12 etc until
//					the resulting string has length > maxLen, then the string is 
//  				replaced with "*" x maxLen
//
//  ARGUMENTS:		DWORD dwVal, BYTE maxLen
//  RETURNS:		Updates g_buffer16 with the result
//-----------------------------------------------------------------------------
void ultoSpecial(DWORD dwVal, BYTE maxLen)
{
	BYTE ii;
	BYTE len;
	
	if(dwVal<10){
    	utoa(g_buffer16, dwVal, 10);
		len=strlen(g_buffer16);
		memmove(g_buffer16+2, g_buffer16, 2);
        g_buffer16[1]='.';
        g_buffer16[0]='0';
		g_buffer16[len+2]='\0';	
    } else if(dwVal<100){
        utoa(g_buffer16, dwVal, 10);
		len=strlen(g_buffer16);
        memmove(g_buffer16+1, g_buffer16, 2);
        g_buffer16[1]='.';
		g_buffer16[len+1]='\0'; 
    } else {
        utoa(g_buffer16, dwVal/10, 10);
    }
	
	if (strlen(g_buffer16) > maxLen){			
		for(ii=0; ii<maxLen; ii++) g_buffer16[ii]='*';	// fill with * to indicate overrange
		g_buffer16[maxLen]='\0';						// NUL terminate
    }
}
