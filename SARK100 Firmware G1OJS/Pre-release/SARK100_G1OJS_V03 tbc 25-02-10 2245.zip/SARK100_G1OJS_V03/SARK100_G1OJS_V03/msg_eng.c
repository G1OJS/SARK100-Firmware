//*****************************************************************************/
//  This file is a part of the "SARK100 SWR Analyzer firmware"
//
//  Copyright © 2010 Melchor Varela - EA4FRB.  All rights reserved.
//  Melchor Varela, Madrid, Spain.
//  melchor.varela@gmail.com
//
//  Modified in 2024 by Alan Robinson G1OJS Hampshire England G1OJS@yahoo.com 
//
//  "SARK100 SWR Analyzer firmware" is free software: you can redistribute it
//  and/or modify it under the terms of the GNU General Public License as
//  published by the Free Software Foundation, either version 3 of the License,
//  or (at your option) any later version.
//
//  "SARK100 SWR Analyzer firmware" is distributed in the hope that it will be
//  useful,  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with "SARK100 SWR Analyzer firmware".  If not,
//  see <http://www.gnu.org/licenses/>.
//*****************************************************************************/
//*****************************************************************************/
//
//	PROJECT:	SARK100 SWR Analyzer
// 	FILE NAME: 	MSG_ENG.C
// 	AUTHOR:		EA4FRB - Melchor Varela
//
// 	DESCRIPTION
//
//	Display texts: English
//
// 	HISTORY
//
//	NAME   		DATE		REMARKS
//
//	MVM	   		DEC 2009	Creation
//
//  G1OJSv1.0	DEC 2024	Align data with refactoring and functional changes
//
//*****************************************************************************/
#include "msg_generic.h"
#include "glb_data.h"

//-----------------------------------------------------------------------------
//  Display texts:
//-----------------------------------------------------------------------------
BYTE const gBlankStr_16	[] 		= "                ";
BYTE const gBlankStr_4	[] 		= "    ";
BYTE const gThousandStr [] 		= "000";
BYTE const gPowerLabelsStr [] 	= "mV:     dBm:    ";
BYTE const gZeroReactanceStr [] = "Reactance = 0\xf4";

BYTE const g_welcome1Str	[] 	= PRODUCT_NAME_STR " ANALYZER";
BYTE const g_welcome2Str	[] 	= "G1OJS " VERSION_STR;

BYTE const gConfigPcLinkStr	[] 	= "PC Link";
BYTE const gConfigIdleStr	[] 	= "Idle Timeout";
BYTE const gConfigDoCalStr	[] 	= "Calibrate";
BYTE const gConfigSwLoadStr	[] 	= "Firmware load";
BYTE const *gConfigStr[] = {
							gConfigPcLinkStr,
							gConfigIdleStr,
							gConfigDoCalStr,
							gConfigSwLoadStr
							};

BYTE const gModeImpDStr	[] = "SWR";
BYTE const gModeImpNStr	[] = "SWR";
BYTE const gModeCapStr	[] = "CAP    ";
BYTE const gModeIndStr	[] = "IND    ";
BYTE const gModeSigStr	[] = "Power lvl (RMS) ";
BYTE const gModeVfoStr	[] = "VFO             ";
BYTE const *gModeStr[] = {
							gModeImpDStr,
							gModeImpNStr,
							gModeCapStr,
							gModeIndStr,
							gModeSigStr,
							gModeVfoStr,
							};

BYTE const gIdleOffStr    [] = "Off";
BYTE const gIdle30SStr    [] = "30 S";
BYTE const gIdle60SStr    [] = "60 S";
BYTE const gIdle90SStr    [] = "90 S";
BYTE const *gIdleStr[] = {
							gIdleOffStr,
							gIdle30SStr,
							gIdle60SStr,
							gIdle90SStr
							};
							
BYTE const gLowLoadStr       [] = "Connect 10\xf4";
BYTE const gMatchLoadStr     [] = "Connect 50\xf4";
BYTE const gHighLoadStr      [] = "Connect 220\xf4";
BYTE const gHigh2LoadStr     [] = "Connect 560\xf4";
BYTE const *gCalLoadStr[] = {
							gLowLoadStr,
							gMatchLoadStr,
							gHighLoadStr,
							gHigh2LoadStr
							};
							
BYTE const gDisconnectLoadStr	[] = "Disconnect load ";

BYTE const gErrorAdjustVfStr	[] = "Error Vf Level";

BYTE const gSettingGainStr		[] = "Setting gain";
BYTE const gCalibratingStr		[] = "Calibrating...";
BYTE const gDoneRestartingStr	[] = "Done: restarting";

BYTE const gErrorUncalibratedStr[] = "Uncalibrated!";
BYTE const gPressAnyKeyStr		[] = "Press any key   ";

BYTE const gConfirmStr			[] = "Confirm?";

BYTE const gErrNoMatchingStr	[] = "Err No Match";
BYTE const gErrNoMatchContinueStr []= "Cont @ 1/4 step?";

BYTE const gBandWidthStr		[] = "BW:";

BYTE const gSwLoadingStr		[] = "FW Loading";

BYTE const gValueSavedStr		[] = "Value saved";

