//*****************************************************************************/
//  This file is a part of the "SARK100 SWR Analyzer firmware"
//
//  Copyright © 2010 Melchor Varela - EA4FRB.  All rights reserved.
//  Melchor Varela, Madrid, Spain.
//  melchor.varela@gmail.com
//
//  Modified in 2024 by Alan Robinson G1OJS Hampshire England G1OJS@yahoo.com 
//
//  "SARK100 SWR Analyzer firmware" is free software: you can redistribute it
//  and/or modify it under the terms of the GNU General Public License as
//  published by the Free Software Foundation, either version 3 of the License,
//  or (at your option) any later version.
//
//  "SARK100 SWR Analyzer firmware" is distributed in the hope that it will be
//  useful,  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with "SARK100 SWR Analyzer firmware".  If not,
//  see <http://www.gnu.org/licenses/>.
//*****************************************************************************/
//*****************************************************************************/
//
//	PROJECT:	SARK100 SWR Analyzer
// 	FILE NAME: 	PCLINK.C
// 	AUTHOR:		EA4FRB - Melchor Varela
//
// 	DESCRIPTION
//
//	PC link routines for update measurements
//
// 	HISTORY
//
//	NAME   		DATE		REMARKS
//
//	MVM	   		DEC 2009	Creation
//  G1OJSv1.0	DEC 2024	Add Cmd_Raw_verbose. Refactor to save memory (added
//							PrintDWordToSerial, PrintVoltagesToSerial,
//							PrintCorrectDataToSerial)
//
//*****************************************************************************/
#include "pclink.h"

#include <stdlib.h>
#include <string.h>
#include "util.h"
#include "keypad.h"
#include "UART.h"
#include "Display.h"
#include "msg_generic.h"
#include "glb_data.h"
#include "buzzer.h"
#include "calcs.h"
#include "calibrate_reflectometer.h"

//-----------------------------------------------------------------------------
//  Private data:
//-----------------------------------------------------------------------------
static BYTE const bufCmdOn		[] = "on";
static BYTE const bufCmdOff		[] = "off";
static BYTE const bufCmdFreq	[] = "freq";
static BYTE const bufCmdMeasImp	[] = "imp";
static BYTE const bufCmdMeasRaw	[] = "raw";
static BYTE const bufCmdScan	[] = "scan";
static BYTE const bufCmdScanRaw	[] = "scanr";
static BYTE const bufCmdScanRawPlus	[] = "scanrp";

static BYTE const bufWelcome	[] = "\r\n" PRODUCT_NAME_STR " SWR Analyzer " VERSION_STR "\r\n";
static BYTE const bufCmdPrompt	[] = "\r\n>>";
static BYTE const bufWaitLink	[] = "Waiting Link";
static BYTE const bufOk			[] = "\r\nOK\r\n";
static BYTE const bufStart		[] = "\r\nStart\r\n";
static BYTE const bufEnd		[] = "End\r\n";

static BYTE const bufErrFreqNotSet	[] = "\r\nError: freq not set\r\n";
static BYTE const bufErrExpectFreq	[] = "\r\nError: expected freq val\r\n";
static BYTE const bufErrExpectStep	[] = "\r\nError: expected step val\r\n";
static BYTE const bufErrInvalidFreq	[] = "\r\nError: invalid freq\r\n";
static BYTE const bufErrCmdNotFound1[] = "\r\nCommand <";
static BYTE const bufErrCmdNotFound2[] = "> not found\r\n";

//-----------------------------------------------------------------------------
//  Prototypes
//-----------------------------------------------------------------------------
static void Cmd_Off (void);
static void Cmd_On (void);
static void Cmd_Freq (void);
static void Cmd_Imp (void);
static void Cmd_Raw (void);
static void Cmd_Raw_verbose (void);
static void Cmd_Scan (BYTE bRaw);
static void PrintX100toSerial(DWORD wVal);
static void PrintSRXZToSerial(void);
static void PrintVoltagesToSerial(void);
static DWORD getFreqArg(BYTE bFreqIsStep);

//-----------------------------------------------------------------------------
//  FUNCTION NAME:	PcLink
//
//  DESCRIPTION:
//
//	PC link routines for update measurements
//
//  ARGUMENTS:
//     none.
//
//  RETURNS:
//     none.
//
//-----------------------------------------------------------------------------
void PcLink (void)
{
	char * strPtr; 						// Parameter pointer
	
	UART_CmdReset(); 					// Initialize receiver/cmd buffer
	UART_IntCntl(UART_ENABLE_RX_INT); 	// Enable RX interrupts
	UART_Start(UART_PARITY_NONE); 		// Enable UART

	M8C_EnableGInt ;

    UART_PutChar(12); 					// Clear the screen
	UART_CPutString(bufWelcome);
	UART_CPutString(bufCmdPrompt);

	DISP_CStrAtRowCol(1,0, bufWaitLink);
	
	while(TRUE)
	{
		if (KEYPAD_Get() == KBD_UP)
			break;

		if(UART_bCmdCheck()) 			// Wait for command
		{								// More than delimiter?
			if(strPtr = UART_szGetParam())
			{
				DISP_CStrAtRowCol(1,0, gBlankStr_16);
				DISP_StrAtRowCol(1,0, strPtr);
    			if(!cstrcmp((const char*)bufCmdOn,(char*)strPtr))
				{
					Cmd_On();
				}
    			else if(!cstrcmp((const char*)bufCmdOff,(char*)strPtr))
				{
					Cmd_Off();
				}
    			else if(!cstrcmp((const char*)bufCmdScan,(char*)strPtr))
    			{
					Cmd_Scan(0);
				}
    			else if(!cstrcmp((const char*)bufCmdScanRaw,(char*)strPtr))
    			{
					Cmd_Scan(1);
				}
				else if(!cstrcmp((const char*)bufCmdScanRawPlus,(char*)strPtr))
    			{
					Cmd_Scan(2);
				}	
    			else if(!cstrcmp((const char*)bufCmdFreq,(char*)strPtr))
				{
					Cmd_Freq();
				}
    			else if(!cstrcmp((const char*)bufCmdMeasImp,(char*)strPtr))
				{
					UART_PutCRLF();
					Cmd_Imp();
				}
    			else if(!cstrcmp((const char*)bufCmdMeasRaw,(char*)strPtr))
				{
					UART_PutCRLF();
					Cmd_Raw();
				}
				else
				{
					UART_CPutString(bufErrCmdNotFound1);
					UART_PutString(strPtr);
					UART_CPutString(bufErrCmdNotFound2);
				}
			}
			UART_CmdReset(); // Reset command buffer
			UART_CPutString(bufCmdPrompt);
		}
	}
	SetPowerDDS(OFF);
	UART_Stop();
	

}

//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Cmd_On
//
//  DESCRIPTION:
//
//	Process on (enable DDS) command
//
//  ARGUMENTS:
//     none.
//
//  RETURNS:
//     none.
//
//-----------------------------------------------------------------------------
static void Cmd_On (void)
{
	SetPowerDDS(ON);
	UART_CPutString(bufOk);
}

//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Cmd_Off
//
//  DESCRIPTION:
//
//	Process on command
//
//  ARGUMENTS:
//     none.
//
//  RETURNS:
//     none.
//
//-----------------------------------------------------------------------------
static void Cmd_Off (void)
{
	SetPowerDDS(OFF);
	UART_CPutString(bufOk);
}

//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Cmd_Freq
//
//  DESCRIPTION:
//
//	Process freq (set frequency) command
//
//  ARGUMENTS:
//     none.
//
//  RETURNS:
//     none.
//
//-----------------------------------------------------------------------------
static void Cmd_Freq (void)
{
	WORD dwfreqRequest;
	do
	{
		dwfreqRequest = getFreqArg(0); if(dwfreqRequest==-1) break;
		g_dwCurrHz=dwfreqRequest;
		UART_CPutString(bufOk);
	} while (FALSE);
}

//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Cmd_Imp
//
//  DESCRIPTION:
//
//	Process imp (impedance) command
//
//  ARGUMENTS:
//     none.
//
//  RETURNS:
//     none.
//
//	Response {SWR},{R},{X},{Z}
//  Example 1.05,52,10,51 
//
//-----------------------------------------------------------------------------
static void Cmd_Imp (void)
{
	MeasureCorrectCalc();
	
	// refactored code but maintains 2dp 0dp 0dp 0dp format
	PrintX100toSerial((DWORD)g_wSwr100);
	itoa(g_buffer16, g_wR10/10, 10); UART_PutString(g_buffer16); UART_PutChar(',');
	itoa(g_buffer16, g_wX10/10, 10); UART_PutString(g_buffer16); UART_PutChar(',');
	itoa(g_buffer16, g_wZ10/10, 10); UART_PutString(g_buffer16); 
	
	UART_PutCRLF();
}

//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Cmd_Raw
//
//  DESCRIPTION:
//
//	Process raw (raw measurement data) command
//
//  ARGUMENTS:
//	  none.
//
//  RETURNS:
//     none.
//
// 	Response {Vf},{Vr},{Vz},{Va}
//  Example 257300,165500,31800,214500 
// 
//-----------------------------------------------------------------------------
static void Cmd_Raw (void)
{
	MeasureCorrectCalc();
	PrintVoltagesToSerial();			// corrected voltages

	UART_PutCRLF();
}

//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Cmd_Raw_plus
//
//  DESCRIPTION:
//
//	Process raw_plus (raw measurement data verbose) command
//
//  ARGUMENTS:
//     	none
//
//  RETURNS:
//     none.
//
//  Response  	Vf,Vr,Vz,Va,SWR,R,X,|Z| for uncorrected bridge
//				Vf,Vr,Vz,Va,SWR,R,X,|Z| for corrected bridge
//
//-----------------------------------------------------------------------------
static void Cmd_Raw_plus(void)
{
	
	ultoa(g_buffer16,g_dwCurrHz/1000,10); UART_PutString(g_buffer16);  UART_PutChar(',')	;
	MeasureBridgeRatios();
	// Print out UNCORRECTED ,Vf,Vr,Vz,Va,SWR,R,X,|Z| (Integer x4, 2dp x4)	
	PrintVoltagesToSerial(); UART_PutChar(',');
	Do_SZRX_Calcs(); 	
	PrintSRXZToSerial();
	
	CorrectBridgeRatios();
	// Print out CORRECTED ,Vf,Vr,Vz,Va,SWR,R,X,|Z|	(Integer x4, 2dp x4)
	PrintVoltagesToSerial(); UART_PutChar(',');
	Do_SZRX_Calcs(); 	
	PrintSRXZToSerial();
	
	UART_PutCRLF();

}

//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Cmd_Raw_plus
//
//  DESCRIPTION:
//
//	Process raw_plus (raw measurement data verbose) command
//
//  ARGUMENTS:
//     	none
//
//  RETURNS:
//     none.
//
//  Response  	Vf,Vr,Vz,Va,SWR,R,X,|Z| for uncorrected bridge
//				Vf,Vr,Vz,Va,SWR,R,X,|Z| for corrected bridge
//
//-----------------------------------------------------------------------------
static void Cmd_TimeFreq(void)
{
	#define TimeSlots 50	// number of delay times to investigate
	#define DeltaTime 1 	// step in delay times to investigate
	BYTE bCnt;
	
	g_measureDelay=0;
	ultoa(g_buffer16,g_dwCurrHz/1000,10); UART_PutString(g_buffer16);  UART_PutChar(',');
	for(bCnt=0;bCnt<TimeSlots;bCnt++)
	{
		g_measureDelay+=DeltaTime;
		utoa(g_buffer16,DDSOutputVoltage(),10); UART_PutString(g_buffer16);  UART_PutChar(',');
	}
	
	UART_PutCRLF();

}


//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Cmd_Scan
//
//  DESCRIPTION:
//
//	Process scan command
//
//  ARGUMENTS:
//     none.
//
//  RETURNS:
//     none.
//
//-----------------------------------------------------------------------------
static void Cmd_Scan (BYTE bScanMode)
{
	DWORD dwEndFreq;
	DWORD dwStepFreq;


	do
	{
		// Get start, end and step frequencies
		g_dwCurrHz 	= getFreqArg(0); 	if(g_dwCurrHz==-1) break;
		dwEndFreq	= getFreqArg(0); 	if(dwEndFreq==-1) break;
		dwStepFreq	= getFreqArg(1); 	if(dwStepFreq==-1) break;										
		UART_CPutString(bufStart);
		UART_PutCRLF();
		
		SetPowerDDS(ON); 	// DDS will have been off, so turn on
		// now step through frequencies calling MeasureBridgeRatios via Cmd_x functions
		do
		{
//			Cmd_TimeFreq();
			
			if (bScanMode == 2) Cmd_Raw_plus();
			if (bScanMode == 1) Cmd_Raw();
			if (bScanMode == 0) Cmd_Imp();

			g_dwCurrHz += dwStepFreq;
		} while (g_dwCurrHz<=dwEndFreq);
		
		UART_CPutString(bufEnd);
		
	} while (FALSE);

	BUZZER_Morse_End();
}

static DWORD getFreqArg(BYTE bFreqIsStep)
{
	char * strPtr; 						// Parameter pointer
	
	strPtr = UART_szGetParam();
	
	if (strPtr==NULL)
	{
		UART_CPutString((bFreqIsStep)? bufErrExpectStep:bufErrExpectFreq);
		return -1;
	}
	if( (bFreqIsStep==0) && (atol(strPtr)>FREQ_MAX_Hz || atol(strPtr)<FREQ_MIN_Hz) )
	{
		UART_CPutString(bufErrInvalidFreq);
		return -1;
	}
	return atol(strPtr);
}


//-----------------------------------------------------------------------------
//  FUNCTION NAME:	PrintSRXZToSerial(void)
//
//  DESCRIPTION: 	Convert the 4 calc results to decimal string and send
//  to serial with comma separators
//
//  ARGUMENTS:
//		none
//
//  RETURNS:
//     none.
//
//-----------------------------------------------------------------------------
static void PrintSRXZToSerial(void)
{
	size_t len;
	BYTE i;
	
	PrintX100toSerial((DWORD)g_wSwr100);	//2dp format
	PrintX100toSerial((DWORD)g_wR10 * 10); 	//2dp format but 1dp precision
	PrintX100toSerial((DWORD)g_wX10 * 10); 	//2dp format but 1dp precision
	PrintX100toSerial((DWORD)g_wZ10 * 10); 	//2dp format but 1dp precision
}

//-----------------------------------------------------------------------------
//  FUNCTION NAME:	PrintX100toSerial(WORD wVal)
//
//  DESCRIPTION: 	Given a number x100, prints to serial with 2dp and trailing comma
//
//  ARGUMENTS:
//		WORD wVal	Number x100 to print
//
//  RETURNS:
//     none.
//
//-----------------------------------------------------------------------------
static void PrintX100toSerial(DWORD dwVal)
{
	size_t len;
	BYTE i;
	ultoa(g_buffer16, dwVal , 10); len=strlen(g_buffer16);
	if(len > 16) {
		UART_CPutString("***.**");
	} else {
		if(len > 2) {
		    for (i=0;i<len-2;i++) UART_PutChar( g_buffer16[i] );
		} else {
	    	UART_PutChar( '0' );
	    }
		UART_PutChar( '.' );
		if(len > 1) {
		    UART_PutChar( g_buffer16[len-2] );
		} else {
	    	UART_PutChar( '0' );
	    }
		UART_PutChar( g_buffer16[len-1] );
	}
	UART_PutChar(',');
}



//-----------------------------------------------------------------------------
//  FUNCTION NAME:	PrintVoltagesToSerial(void)
//
//  DESCRIPTION: Convert the four bridge voltages to string and print
//  to serial with comma separators
//
//  ARGUMENTS:
//		none
//
//  RETURNS:
//     	none
//
//-----------------------------------------------------------------------------
static void PrintVoltagesToSerial(void) {

	utoa(g_buffer16, 4*PRECISION, 10);			UART_PutString(g_buffer16); UART_CPutString(gThousandStr); UART_PutChar(',');
	utoa(g_buffer16, 4*g_xBridge.wVrVf, 10);	UART_PutString(g_buffer16); UART_CPutString(gThousandStr); UART_PutChar(',');
	utoa(g_buffer16, g_xBridge.wVzVa, 10);		UART_PutString(g_buffer16); UART_CPutString(gThousandStr); UART_PutChar(',');
	utoa(g_buffer16, PRECISION, 10);			UART_PutString(g_buffer16); UART_CPutString(gThousandStr); 
}
