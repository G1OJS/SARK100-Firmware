//*****************************************************************************/
//  This file is a part of the "SARK100 SWR Analyzer firmware"
//
//  Copyright © 2010 Melchor Varela - EA4FRB.  All rights reserved.
//  Melchor Varela, Madrid, Spain.
//  melchor.varela@gmail.com
//
//  Modified in 2024 by Alan Robinson G1OJS Hampshire England G1OJS@yahoo.com 
//
//  "SARK100 SWR Analyzer firmware" is free software: you can redistribute it
//  and/or modify it under the terms of the GNU General Public License as
//  published by the Free Software Foundation, either version 3 of the License,
//  or (at your option) any later version.
//
//  "SARK100 SWR Analyzer firmware" is distributed in the hope that it will be
//  useful,  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with "SARK100 SWR Analyzer firmware".  If not,
//  see <http://www.gnu.org/licenses/>.
//*****************************************************************************/
//*****************************************************************************/
//
//	PROJECT:	SARK100 SWR Analyzer
// 	FILE NAME: 	DISPLAY.H
// 	AUTHOR:		Melchor Varela
//
// 	DESCRIPTION
//
//	Display utility functions
//
// 	HISTORY
//
//	NAME   	DATE		REMARKS
//
//	MVM	   		DEC 2009	Creation
//
//  G1OJSv1.0	DEC 2024	Align with c file
//
//*****************************************************************************/
#ifndef __DISPLAY_H__
#define __DISPLAY_H__

#include "Lcd.h"

//-----------------------------------------------------------------------------
//  Defines
//-----------------------------------------------------------------------------
#define LCD_CLEAR			1
#define LCD_OFF				0x08
#define LCD_ON				0x0c
#define LCD_ON_CURSOR		0x0e
#define LCD_ON_BLINK		0x0d

//-----------------------------------------------------------------------------
//  Public functions
//-----------------------------------------------------------------------------

// functions to display outputs using specific screen layouts
void DISP_Frequency (void);
void DISP_SRXZ (void);
void DISP_Capacitance (void);
void DISP_Inductance (void);
void DISP_Power(WORD vVz);
void DISP_CableLength(WORD wHWkHz);

// low level functions
void DISP_Setup (void);
void DISP_Clear (void);
void DISP_HideCursor(void);
void DISP_CStr(const char * sRomString);
void DISP_Str(char * sString);
void DISP_CStrAtRowCol(BYTE bRow, BYTE bCol, const char * sRomString);
void DISP_StrAtRowCol(BYTE bRow, BYTE bCol, char * sString);


//*****************************************************************************
#endif











