//*****************************************************************************/
//  This file is a part of the "SARK100 SWR Analyzer firmware"
//
//  Copyright © 2010 Melchor Varela - EA4FRB.  All rights reserved.
//  Melchor Varela, Madrid, Spain.
//  melchor.varela@gmail.com
//
//  Modified in 2025 by Alan Robinson G1OJS Hampshire England G1OJS@yahoo.com 
//
//  "SARK100 SWR Analyzer firmware" is free software: you can redistribute it
//  and/or modify it under the terms of the GNU General Public License as
//  published by the Free Software Foundation, either version 3 of the License,
//  or (at your option) any later version.
//
//  "SARK100 SWR Analyzer firmware" is distributed in the hope that it will be
//  useful,  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with "SARK100 SWR Analyzer firmware".  If not,
//  see <http://www.gnu.org/licenses/>.
//*****************************************************************************/
//*****************************************************************************/
//
//	PROJECT:	SARK100 SWR Analyzer
// 	FILE NAME: 	MEASURE.C
// 	AUTHOR:		EA4FRB - Melchor Varela
//
// 	DESCRIPTION
//
//	Measure reflectometer voltages
//
// 	HISTORY
//
//	NAME   		DATE		REMARKS
//
//	MVM	   		DEC 2009	Creation
//
//*****************************************************************************/
#include "measure.h"

#include "PSoCAPI.h"
#include "glb_data.h"
#include "dds.h"
#include "util.h"

// Port settings
#define VfPort AMUX4_ADC_PORT0_1
#define VrPort AMUX4_ADC_PORT0_3
#define VzPort AMUX4_ADC_PORT0_5
#define VaPort AMUX4_ADC_PORT0_7

//-----------------------------------------------------------------------------
//  Prototypes
//-----------------------------------------------------------------------------
static WORD Read_ADC (BYTE VxPort);
//-----------------------------------------------------------------------------
//  FUNCTION NAME:	MeasureBridgeRatios
//  DESCRIPTION: Read all bridge voltages and set global ratios Vr/Vf and Vz/Va
//  NOTES:
//    - WORD with wUNITY=1000 can encode ratios from 0.001 to 65.535 
//	    which represents impedance from zero via 0.05 to 3276.75 ohms and 
//	    VSWR from 1.00:1 via 1.002:1 in 2% steps to ~8000:1 where Vr=3999 and Vf=4000 
//    - 3k ohms can be seen on open circuit at lower frequencies, so we need to 
//      cap the ratio 1000*Vz/Va at WORD_MAX, which is done in wDivide(WORD w1, WORD w2)
//    - Vr can sometimes slightly exceed Vf due to measurement error, but
//      this is capped after correction in CorrectBridgeRatios and the raw (uncorrected)
//      ratio is only ever seen if verbose pcLink is used in which case assume expert user 
//      and don't hide the measurement errors, but still use wDivide for WORD_MAX safety
//  ARGUMENTS: None
//  RETURNS: Nothing, but sets global variables:
//     g_xBridge.wVzVa (wUNITY x "Vz/Va")
//     g_xBridge.wVrVf (wUNITY x "Vr/Vf")
//-----------------------------------------------------------------------------
void MeasureBridgeRatios ( void )
{
	DDS_Set(g_dwCurrHz);  // DDS is off by default, so turn it on to correct freq
	Delay_64ths(1);	  // Bridge capacitor settling time
	g_wBridgeRatios[MODZ] = wDivide(Read_ADC(VzPort),Read_ADC(VaPort));
	g_wBridgeRatios[MODGAMMA] = wDivide(Read_ADC(VrPort),Read_ADC(VfPort));
	DDS_Set(0); // Turn DDS off (this function isn't called from VFO mode)
}
//-----------------------------------------------------------------------------
//  FUNCTION NAME:	BridgeVf
//  DESCRIPTION: 	Turn on DDS and measure Vf for DDS output health
//					Note - reading Vf with DDS off would serve no purpose
//  ARGUMENTS: 		None
//  RETURNS: 		WORD = Vf
//-----------------------------------------------------------------------------
WORD BridgeVf(void)
{	
	WORD wVal;
	DDS_Set(g_dwCurrHz);  
	wVal=Read_ADC(VfPort);
	DDS_Set(0);
	return wVal;
}
//-----------------------------------------------------------------------------
//  FUNCTION NAME:	BridgeVz
//  DESCRIPTION: 	Read Vz without turning DDS on or off.
//					This is called from both SIG and VFO mode, so leave the DDS
//					settings alone. 
//  ARGUMENTS: 		None
//  RETURNS: 		WORD = Vz
//-----------------------------------------------------------------------------
WORD BridgeVz(void)
{						
	return Read_ADC(VzPort);
}
//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Read_ADC
//  DESCRIPTION:	Set the specified port and read the ADC
//  ARGUMENTS:		BYTE VxPort - which port (see #defines in above)
//  RETURNS: 		Measured value
//-----------------------------------------------------------------------------
static WORD Read_ADC (BYTE VxPort)
{
	WORD wVal;
	AMUX4_ADC_InputSelect(VxPort);					// Select the input port needed to be read
	if(VxPort==VrPort) PGA_ADC_SetGain(PGA_ADC_G5_33);
	ADCINC12_GetSamples(1);               	    	// Ask for 1 sample
    while(ADCINC12_fIsDataAvailable() == 0);    	// Wait until next reading ready  
	wVal=(WORD)ADCINC12_iGetData()+2048;			// Take the reading
    ADCINC12_ClearFlag();                       	// Clear ADC flag  
	if(VxPort==VrPort) PGA_ADC_SetGain(PGA_ADC_G2_67);
  	
	return wVal; 	// Return the reading
}




