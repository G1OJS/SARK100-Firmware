//*****************************************************************************/
//  This file is a part of the "SARK100 SWR Analyzer firmware"
//
//  Copyright © 2010 Melchor Varela - EA4FRB.  All rights reserved.
//  Melchor Varela, Madrid, Spain.
//  melchor.varela@gmail.com
//
//  Modified in 2025 by Alan Robinson G1OJS Hampshire England G1OJS@yahoo.com 
//
//  "SARK100 SWR Analyzer firmware" is free software: you can redistribute it
//  and/or modify it under the terms of the GNU General Public License as
//  published by the Free Software Foundation, either version 3 of the License,
//  or (at your option) any later version.
//
//  "SARK100 SWR Analyzer firmware" is distributed in the hope that it will be
//  useful,  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with "SARK100 SWR Analyzer firmware".  If not,
//  see <http://www.gnu.org/licenses/>.
//*****************************************************************************/
//*****************************************************************************/
//
//	PROJECT:	SARK100 SWR Analyzer
// 	FILE NAME: 	UTIL.C
// 	AUTHOR:		EA4FRB - Melchor Varela
//
// 	DESCRIPTION
//
//	Utility functions
//
// 	HISTORY
//
//	NAME   		DATE		REMARKS
//
//	MVM	   		DEC 2009	Creation
//
//	G1OJSv1.0	DEC 2024	Add ultoSpecial
//
//*****************************************************************************/
#include "util.h"

#include <m8c.h>        		// Part specific constants and macros
#include "PSoCAPI.h"    		// PSoC API definitions for all User Modules
#include "psocgpioint.h"
#include "glb_data.h"
#include "string.h"
#include "Display.h"
#include "Dds.h"
#include "msg_generic.h"
#include "keypad.h"
#include "buzzer.h"
//-----------------------------------------------------------------------------
//  FUNCTION NAME: 	debug_IntToLCD
//  DESCRIPTION: 	Clear lcd and write the two arguments to the display
//  ARGUMENTS:  	two integers to display
//  RETURNS:  		Nothing
//-----------------------------------------------------------------------------
void debug_IntToLCD(int iVal1, int iVal2)
{
	DISP_Clear();
	itoa(g_buffer16,iVal1,10); DISP_StrAtRowCol(0, 0, g_buffer16);
	itoa(g_buffer16,iVal2,10); DISP_StrAtRowCol(1, 0, g_buffer16);
	Delay_64ths(TIME_FLASH_MSG);
}

void Set_DDS(DWORD dwFreq) {DDS_Set(dwFreq);}

//-----------------------------------------------------------------------------
//  FUNCTION NAME: 	Delay_64ths
//  DESCRIPTION: 	Implements a blocking delay of b64ths/64 seconds
//  ARGUMENTS:  	BYTE b64ths: 1= 16ms, 255= 3984ms
//  RETURNS:  		Nothing
//-----------------------------------------------------------------------------
void Delay_64ths(BYTE b64ths)			
{
	g_bSixtyFourthSecondCounter = b64ths;
	M8C_Sleep;
	while(1){ if (g_bSixtyFourthSecondCounter ==0) break; }
}
//-----------------------------------------------------------------------------
//  FUNCTION NAME: 	wDivide(WORD num, WORD denom)
//  DESCRIPTION: 	Returns (num*wUNITY)/denom capped at WORD_MAX
//					Note that the capping logic also excludes divide by zero
//  ARGUMENTS:  	WORD num, WORD denom
//  RETURNS:  		(WORD)((num*wUNITY)/denom)
//-----------------------------------------------------------------------------
WORD wDivide(WORD num, WORD denom)
{
	return (WORD)((DWORD)wUNITY*num >= (DWORD)WORD_MAX*denom)? WORD_MAX:((WORD)(((DWORD)wUNITY*num)/denom));
}
//-----------------------------------------------------------------------------
//  FUNCTION NAME: 	ultoSpecial(DWORD dwVal, BYTE maxLen)
//  DESCRIPTION: 	Given a DWORD dwVal that is 10 times a represented value:
//					dwVal = 0 to 100 results in 0.0 to 9.9
//					dwVal = 100 upwards results in 10, 11, 12 etc until
//					the resulting string has length > maxLen, then the string is 
//  				replaced with "*" x maxLen
//  ARGUMENTS:		DWORD dwVal, BYTE maxLen
//  RETURNS:		Updates g_buffer16 with the result
//-----------------------------------------------------------------------------
void ultoSpecial(DWORD dwVal, BYTE maxLen)
{
	BYTE ii;
	BYTE len;

	if(dwVal<10){
    	ultoa(g_buffer16, dwVal, 10);
		len=strlen(g_buffer16);
		memmove(g_buffer16+2, g_buffer16, 2);
        g_buffer16[1]='.';
        g_buffer16[0]='0';
		g_buffer16[len+2]='\0';	
    } else if(dwVal<100){
        ultoa(g_buffer16, dwVal, 10);
		len=strlen(g_buffer16);
        memmove(g_buffer16+1, g_buffer16, 2);
        g_buffer16[1]='.';
		g_buffer16[len+1]='\0'; 
    } else {
        ultoa(g_buffer16, dwVal/10, 10);
    }
	
	if (strlen(g_buffer16) > maxLen){			
		for(ii=0; ii<maxLen; ii++) g_buffer16[ii]='*';	// fill with * to indicate overrange
		g_buffer16[maxLen]='\0';						// NUL terminate
    }
}
//-----------------------------------------------------------------------------
//  FUNCTION NAME:	SetPowerDigitalAndAnalogue
//  DESCRIPTION:	Turn on LCD, Backlight and 30MHz osc, ADC, ADC's PGAs
//					DDS, DDS's PGAs, Set DDS Gain, Set ADC PGA Gain
//					OR: if isON is false, turn all of that off
//  ARGUMENTS:		POWER_STATE pwrState
//  RETURNS:		Nothing
//-----------------------------------------------------------------------------
void SetPowerDigitalAndAnalogue(POWER_STATE pwrState)
{
    if(pwrState==PWRON)
	{
	  	LCD_Init(); LCD_Control(LCD_ON);

      	SetPowerBackLightAndOsc(PWRON);
	 	Delay_64ths(1);
	  	SetPowerBackLightAndOsc(PWROFF);
	  	Delay_64ths(1);
	  	SetPowerBackLightAndOsc(PWRON);
	  	Delay_64ths(1);
	
 	  	ADCINC12_Start(ADCINC12_HIGHPOWER); 
	  	PGA_ADC_Start(PGA_ADC_HIGHPOWER);
		PGA_ADC_SetGain(PGA_ADC_G2_67);
		DDS_Init();
		PGA_DDS_1_Start(PGA_DDS_1_HIGHPOWER);	
		PGA_DDS_2_Start(PGA_DDS_2_HIGHPOWER);
		SetDDSGain();
	} else {
   	  	SetPowerBackLightAndOsc(PWROFF);
	  	Set_DDS(0);
		PGA_DDS_1_Stop();
		PGA_DDS_2_Stop();		
	  	ADCINC12_Stop(); 
		PGA_ADC_Stop();
	  	LCD_Init(); LCD_Control(LCD_OFF);
	}
}
//-----------------------------------------------------------------------------
//  FUNCTION NAME:	SetDDSGain
//  DESCRIPTION:	Set the gain of both PGAs controlling the DDS output
//					to the setting specified by g_bDDS_GainStep and the DDS PGA
//					gain settings table
//  ARGUMENTS:		Nothing
//  RETURNS:		Nothing
//-----------------------------------------------------------------------------
void SetDDSGain(void)
{
	PGA_DDS_1_SetGain(g_xGainDds[g_bDDS_GainStep].bGain1);
	PGA_DDS_2_SetGain(g_xGainDds[g_bDDS_GainStep].bGain2);
}
//-----------------------------------------------------------------------------
//  FUNCTION NAME:	SetPowerBackLightAndOsc
//  DESCRIPTION:	Assert XO_EN which powers the backlight and 30MHz osc
//					OR: if isON is false, off
//  ARGUMENTS:		POWER_STATE pwrState
//  RETURNS:		Nothing
//-----------------------------------------------------------------------------
void SetPowerBackLightAndOsc(POWER_STATE pwrState)
{
    if(pwrState==PWRON) {
		Port_2_Data_SHADE |= XO_EN_MASK;
		XO_EN_Data_ADDR |= XO_EN_MASK;
	}  else  {
		XO_EN_Data_ADDR &= ~XO_EN_MASK;
		Port_2_Data_SHADE &= ~XO_EN_MASK;
	}
}


// function to display confirmStr in second row and then wait for confirm key or timeout
// Returns 1 if confirmed else 0
BYTE getUserConfirmation(void)
{
	DISP_CStrAtRowCol(1, 0, gConfirmStr);
	return (KEYPAD_WaitKey(TIME_WAIT_KEY_S) == KBD_DWN);
}

