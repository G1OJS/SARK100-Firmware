//*****************************************************************************/
//  This file is a part of the "SARK100 SWR Analyzer firmware"
//
//  Copyright © 2010 Melchor Varela - EA4FRB.  All rights reserved.
//  Melchor Varela, Madrid, Spain.
//  melchor.varela@gmail.com
//
//  Modified in 2025 by Alan Robinson G1OJS Hampshire England G1OJS@yahoo.com 
//
//  "SARK100 SWR Analyzer firmware" is free software: you can redistribute it
//  and/or modify it under the terms of the GNU General Public License as
//  published by the Free Software Foundation, either version 3 of the License,
//  or (at your option) any later version.
//
//  "SARK100 SWR Analyzer firmware" is distributed in the hope that it will be
//  useful,  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with "SARK100 SWR Analyzer firmware".  If not,
//  see <http://www.gnu.org/licenses/>.
//*****************************************************************************/
//*****************************************************************************/
//
//	PROJECT:	SARK100 SWR Analyzer
// 	FILE NAME: 	GLB_DATA.C
// 	AUTHOR:		EA4FRB - Melchor Varela
//
// 	DESCRIPTION
//
//	Global constants and variables
//
// 	HISTORY
//
//	NAME   	DATE		REMARKS
//
//	MVM	   	DEC 2009	Creation
//
//  G1OJSv1.0	DEC 2024	Align data with refactoring and functional changes
//
//*****************************************************************************
//
//*****************************************************************************
// 	IMAGECRAFT COMPILER TYPE DEFINITIONS
// 	From page 17 of the ImageCraft C Compiler Guide, Document # 001-44476 Rev *A
//
//	Type				Bytes		Range
//	[unsigned] char			1		0 .. 255
//      signed char			1		-128 .. 127
//
//	unsigned int			2		0 .. 65535
//	[signed] int			2		-32786 .. 32767
//
//	unsigned int|short		2		0 .. 65535
//	[signed] int|short		2		-32786 .. 32767
//
//	unsigned long			4		0 .. 4,294,967,295
//	[signed] long			4		-2,147,483,648 .. 2,147,483,647
//
//	float | double			4		1.175e-38 .. 3.40e+38
//
//	enum					1		if enum < 256
//							2		if enum >= 256
//
//	BOOL  = unsigned char   1		0 .. 255
//	BYTE  = unsigned char	1		0 .. 255
//	CHAR  = signed char		1		-128 .. 127
//	WORD  = unsigned int	2		0 .. 65535
//	INT   = signed int		2		-32786 .. 32767
//	DWORD = unsigned long	4		0 .. 4,294,967,295
//	LONG  = signed long		4		-2,147,483,648 .. 2,147,483,647
//
//*****************************************************************************
//
//
//
#include "glb_data.h"
#include "PSoCAPI.h"

//-----------------------------------------------------------------------------
//  Public data:
//-----------------------------------------------------------------------------
										// Timer variables managed by Sleep_Timer
volatile BYTE g_bIdleCounter = 0;
volatile BYTE g_bMeasureCounter = 0;
volatile BYTE g_bDebounceCounter = 0;
volatile BYTE g_bSpeedKeyCounter = 0;
volatile BYTE g_bSixtyFourthSecondCounter = 0;

BYTE g_bSpeedKeysOn = 0;

BYTE g_buffer16[16];					// global generic string buffer

BYTE g_bIsCalibrated=FALSE;				// TRUE if calibrated
BYTE g_bDDS_GainStep=8;					// Default DDS gain step
BYTE g_bCWPitch=1;

const WORD g_wBridgeRatiosTrueArr[CAL_LOAD_MAX][2] = { 
{TRUE_RATIO_LOW, TRUE_MODGAMMA_LOW},
{TRUE_RATIO_MATCH, 0},
{TRUE_RATIO_HIGH,TRUE_MODGAMMA_HIGH},
{TRUE_RATIO_HIGH2,TRUE_MODGAMMA_HIGH2}
};
	
signed char g_scCalTable[CAL_FREQS_MAX][CAL_LOAD_MAX][2] = {0}; 

WORD g_wBridgeRatios[2];					// Measured bridge ratios			
CONFIG_DATA g_xConf;					// Configuration data

WORD g_wSwr100;							// SWV x 100
WORD g_wZ10;							// |Z|_ohms x 10 
WORD g_wX10;							// X_ohms x 10
WORD g_wR10;							// R_ohms x 10
WORD g_wL10;							// L_uH x 10
WORD g_wC10;							// C_pF x 10
BYTE g_bSgnX = '?';						// sign of reactance
BYTE g_bMode = MODE_IMP;				// current measurement mode
BYTE g_bVFOConfig=0;					// flag for VFO config keys

const BYTE g_bVF[VF_MAX] = {99,81,66};
const BYTE g_bCWPitches[CWPitch_MAX]	= {6,10,12,20,24};
const BYTE g_bUserIdle[USER_IDLE_MAX]	= {0,30,60,90};
const WORD g_wBandBoundaries[BAND_MAX+1]= {10,20,50,60,80, 110,130,170,190,230,260,280,310,400,490,600};
const WORD g_wBandInitialFreq[BAND_MAX] = {18,37,53,71,110,110,141,181,211,249,270,282,330,450,503};
BYTE g_bBandIndex;
DWORD g_dwCurrHz;

// PGA DDS gain settings table
const GAIN_DDS g_xGainDds[GAIN_SETTINGS_MAX] =
{
   {PGA_DDS_1_G0_68,PGA_DDS_2_G0_68},  // 0.68x0.68=0.46 Iset = 0.015 amplified Vout = 0.190pp = -10.5 dBm
   {PGA_DDS_1_G1_46,PGA_DDS_2_G0_31},  // 1.46x0.31=0.45 Iset = 0.021 amplified Vout = 0.273pp = -7.3 dBm
   {PGA_DDS_1_G1_46,PGA_DDS_2_G0_31},  // 1.46x0.31=0.45 Iset = 0.021 amplified Vout = 0.273pp = -7.3 dBm
   {PGA_DDS_1_G1_78,PGA_DDS_2_G0_25},  // 1.78x0.25=0.45 Iset = 0.026 amplified Vout = 0.338pp = -5.4 dBm
   {PGA_DDS_1_G0_43,PGA_DDS_2_G1_00},  // 0.43x1.00=0.43 Iset = 0.036 amplified Vout = 0.466pp = -2.7 dBm
   {PGA_DDS_1_G0_56,PGA_DDS_2_G0_75},  // 0.56x0.75=0.42 Iset = 0.043 amplified Vout = 0.551pp = -1.2 dBm
   {PGA_DDS_1_G0_50,PGA_DDS_2_G0_81},  // 0.50x0.81=0.41 Iset = 0.053 amplified Vout = 0.679pp = 0.6 dBm
   {PGA_DDS_1_G1_06,PGA_DDS_2_G0_37},  // 1.06x0.37=0.39 Iset = 0.062 amplified Vout = 0.789pp = 1.9 dBm
   {PGA_DDS_1_G1_00,PGA_DDS_2_G0_37},  // 1.00x0.37=0.37 Iset = 0.076 amplified Vout = 0.978pp = 3.8 dBm
   {PGA_DDS_1_G0_56,PGA_DDS_2_G0_62},  // 0.56x0.62=0.35 Iset = 0.092 amplified Vout = 1.173pp = 5.4 dBm
   {PGA_DDS_1_G1_78,PGA_DDS_2_G0_18},  // 1.78x0.18=0.32 Iset = 0.109 amplified Vout = 1.401pp = 6.9 dBm
   {PGA_DDS_1_G1_60,PGA_DDS_2_G0_18},  // 1.60x0.18=0.29 Iset = 0.131 amplified Vout = 1.678pp = 8.5 dBm
   {PGA_DDS_1_G0_50,PGA_DDS_2_G0_50},  // 0.50x0.50=0.25 Iset = 0.156 amplified Vout = 2.002pp = 10.0 dBm
   {PGA_DDS_1_G0_81,PGA_DDS_2_G0_25},  // 0.81x0.25=0.20 Iset = 0.188 amplified Vout = 2.407pp = 11.6 dBm
   {PGA_DDS_1_G1_23,PGA_DDS_2_G0_12},  // 1.23x0.12=0.15 Iset = 0.225 amplified Vout = 2.876pp = 13.2 dBm
   {PGA_DDS_1_G1_33,PGA_DDS_2_G0_06},  // 1.33x0.06=0.08 Iset = 0.270 amplified Vout = 3.454pp = 14.7 dBm
   {PGA_DDS_1_G0_43,PGA_DDS_2_G0_06}   // 0.43x0.06=0.03 Iset = 0.306 amplified Vout = 3.915pp = 15.8 dBm
};

// all increment control data
BYTE g_bIncDigitSelect = FALSE;
BYTE g_bIncDigit=5;
const INCREMENT_CONTROL g_xIncCtrl[MAX_INCREMENT] =
{
	{15, 1},
	{14, 10},
	{13, 100},		// skip decimal point 
	{11, 1000},
	{10, 10000},
	{9,  100000},
	{8,  1000000},
	{7,  10000000}
};


