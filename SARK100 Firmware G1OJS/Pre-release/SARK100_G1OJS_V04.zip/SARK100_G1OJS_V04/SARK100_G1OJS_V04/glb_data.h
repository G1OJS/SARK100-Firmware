//*****************************************************************************/
//  This file is a part of the "SARK100 SWR Analyzer firmware"
//
//  Copyright © 2010 Melchor Varela - EA4FRB.  All rights reserved.
//  Melchor Varela, Madrid, Spain.
//  melchor.varela@gmail.com
//
//  Modified in 2024 by Alan Robinson G1OJS Hampshire England G1OJS@yahoo.com 
//
//  "SARK100 SWR Analyzer firmware" is free software: you can redistribute it
//  and/or modify it under the terms of the GNU General Public License as
//  published by the Free Software Foundation, either version 3 of the License,
//  or (at your option) any later version.
//
//  "SARK100 SWR Analyzer firmware" is distributed in the hope that it will be
//  useful,  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with "SARK100 SWR Analyzer firmware".  If not,
//  see <http://www.gnu.org/licenses/>.
//*****************************************************************************/
//*****************************************************************************/
//
//	PROJECT:	SARK100 SWR Analyzer
// 	FILE NAME: 	GLB_DATA.H
// 	AUTHOR:		EA4FRB - Melchor Varela
//
// 	DESCRIPTION
//
//	Global constants and variables
//
// 	HISTORY
//
//	NAME   		DATE		REMARKS
//
//	MVM	   		DEC 2009	Creation
//
//  G1OJSv1.0	DEC 2024	Align data with refactoring and functional changes
//
//*****************************************************************************/
#ifndef __GLB_DATA_H__
#define __GLB_DATA_H__

#include <stdlib.h>
#include <m8c.h>

#include "measure.h"

//-----------------------------------------------------------------------------
//  Version string
//-----------------------------------------------------------------------------
#define VERSION_STR			"V04"
#define PRODUCT_NAME_STR	"SARK100"

//-----------------------------------------------------------------------------
//  Defines
//-----------------------------------------------------------------------------

#define	wUNITY				1000		// General use multiplier for storing float in WORD

#define WORD_MAX			65535		// largest number available in WORD
#define VR_OVER_VF_MAX		996			// largest value of wUNITYxVr/Vf that gives SWRx100 storable in WORD 996 corresponds to VSWR=499.

#define FREQ_MIN_Hz			1000000
#define FREQ_MAX_Hz			60000000

#define SWR_BW_THRESH		200			//SWR threshold (SWRx100) for swr BW and match freq scanning
#define TIME_WAIT_KEY_S		30			// Time to wait for key when dialog, units of seconds
#define TIME_DELAY_TEXT		3			// Temporary screen texts cancellable by keypress: units of 1 sec
#define TIME_FLASH_MSG		64			// Time to display flash (not important) messages, units 1/64 seconds up to 255
#define	MEASURE_PERIOD		32			// Measurements sample period, units (1/16 sec)
#define BAND_FREQ_ToHz		100000		// Frequency multiplier for frequency tables
#define DIZZLING_OFFSET_PERCENT	10		// Percent change to apply to frequency when dizzling
#define CWPitch_MAX			5			// Number of CW Pitch settings
#define USER_IDLE_MAX 		4			// Number of idle timeout settings
#define GAIN_SETTINGS_MAX	17			// Number of gain settings for DDS PGAs 
#define BAND_MAX 			15			// Number of bands
#define BAND_ATPWRON		8			// initial band

#define VF_MAX 3						// Number of velocity factors for line length display

#define KEY_DEBOUNCE_TIME			4		// Units of 1/16 sec
#define SPEED_KEY_DET_TIME_S		2		// Units of seconds
#define SPEED_KEY_CLICKRATE_64ths	4		// Units of 1/64th s

typedef enum {PWROFF, PWRON} POWER_STATE;

typedef enum {MODZ,  MODGAMMA} RATIO_TYPE;	

typedef enum {							// Configuration menu
	CONFIG_PCLINK = 0,
	CONFIG_Idle,
	CONFIG_CWPitch,
	CONFIG_CableLength,
	CONFIG_CALIB,
	CONFIG_SW_LOAD,
	
	CONFIG_MAX
} CONFIG_DEFS;

typedef enum {							// Mode menu
	MODE_IMP = 0,
	MODE_CAP,
	MODE_IND,
	MODE_SIG,
	MODE_VFO,

	MODE_MAX
} MODE_DEFS;

typedef struct							// PGA's DDS gain settings
{
	BYTE bGain1;
	BYTE bGain2;
} GAIN_DDS;

typedef struct							// Configuration data stored in EEPROM
{
	BYTE bUserIdle;
	BYTE bCWPitch;
} CONFIG_DATA;
										// Cursor-based frequency increment data
#define MAX_INCREMENT		8
typedef struct
{
	BYTE bCol;
	DWORD dwInc;
} INCREMENT_CONTROL;

//-----------------------------------------------------------------------------
// Calibration definitions
//-----------------------------------------------------------------------------
#define CAL_START_Hz			999990		// start cal freqs, offset to avoid whole MHz (especially odd ones) as these are bad for calibration repeatability
#define CAL_FREQ_STEP_Hz		1999990		// Frequency interval between calibration freqs
#define CAL_FREQS_MAX			31			// Number of calibration frequencies (must satisfy (CAL_FREQS_MAX-1)* CAL_FREQ_STEP_Hz >= FREQ_MAX_Hz-CAL_START_Hz)
										
// Calibration with 10R, 50R, 220R, 560R loads:
#define TRUE_RATIO_LOW			200			// Vz/Va expected at low cal point, x1000
#define TRUE_RATIO_MATCH		1000		// Vz/Va expected at match cal point, x1000
#define TRUE_RATIO_HIGH			4400		// Vz/Va expected at high cal point, x1000
#define TRUE_RATIO_HIGH2		11200		// Vz/Va expected at high2 cal point, x1000
#define TRUE_MODGAMMA_LOW		667			// |Gamma| = Vr/Vf expected at low cal point, x1000
#define TRUE_MODGAMMA_HIGH		630			// |Gamma| = Vr/Vf expected at high cal point, x1000
#define TRUE_MODGAMMA_HIGH2		836			// |Gamma| = Vr/Vf expected at high2 cal point, x1000

typedef enum {							// Calibration load indexes
	CAL_LOAD_LOW,
	CAL_LOAD_MATCH,
	CAL_LOAD_HIGH,
	CAL_LOAD_HIGH2,
	
	CAL_LOAD_MAX
} CAL_LOAD_DEFS;

//-----------------------------------------------------------------------------
//  Public data:
//-----------------------------------------------------------------------------
extern volatile BYTE g_bIdleCounter;
extern volatile BYTE g_bMeasureCounter;
extern volatile BYTE g_bDebounceCounter;
extern volatile BYTE g_bSpeedKeyCounter;
extern volatile BYTE g_bSixtyFourthSecondCounter;

extern BYTE g_buffer16[16];
extern const BYTE g_bCWPitches[CWPitch_MAX];
extern const BYTE g_bUserIdle[USER_IDLE_MAX];

extern const BYTE g_bVF[VF_MAX];

extern BYTE g_bVFOConfig;
extern BYTE g_bSpeedKeysOn;

extern BYTE g_bIsCalibrated;
extern CONFIG_DATA g_xConf;

extern BYTE g_bDDS_GainStep;
extern const GAIN_DDS g_xGainDds[GAIN_SETTINGS_MAX];

extern const WORD g_wBandBoundaries[BAND_MAX+1];
extern const WORD g_wBandInitialFreq[BAND_MAX];
extern BYTE g_bIncDigitSelect;
extern BYTE g_bIncDigit;
extern const INCREMENT_CONTROL g_xIncCtrl[MAX_INCREMENT];

extern const WORD g_wCalFreqs[CAL_FREQS_MAX];
extern signed char g_scCalTable[CAL_FREQS_MAX][CAL_LOAD_MAX][2];

extern WORD g_wBridgeRatios[2];
extern const WORD g_wBridgeRatiosTrueArr[CAL_LOAD_MAX][2];
extern WORD g_wBridgeRatiosArr[CAL_LOAD_MAX][2];

extern BYTE g_bBandIndex;
extern DWORD g_dwCurrHz;
extern BYTE g_bMode;
extern WORD g_wSwr100;
extern WORD g_wZ10;
extern WORD g_wX10;
extern WORD g_wR10;
extern WORD g_wL10;
extern WORD g_wC10;
extern BYTE g_bSgnX;

//-----------------------------------------------------------------------------
#endif