//*****************************************************************************/
//  This file is a part of the "SARK100 SWR Analyzer firmware"
//
//  Copyright © 2010 Melchor Varela - EA4FRB.  All rights reserved.
//  Melchor Varela, Madrid, Spain.
//  melchor.varela@gmail.com
//
//  Modified in 2025 by Alan Robinson G1OJS Hampshire England G1OJS@yahoo.com 
//
//  "SARK100 SWR Analyzer firmware" is free software: you can redistribute it
//  and/or modify it under the terms of the GNU General Public License as
//  published by the Free Software Foundation, either version 3 of the License,
//  or (at your option) any later version.
//
//  "SARK100 SWR Analyzer firmware" is distributed in the hope that it will be
//  useful,  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with "SARK100 SWR Analyzer firmware".  If not,
//  see <http://www.gnu.org/licenses/>.
//*****************************************************************************/
//*****************************************************************************/
//
//	PROJECT:	SARK100 SWR Analyzer
// 	FILE NAME: 	MAIN.C
// 	AUTHOR:		EA4FRB - Melchor Varela
//
// 	DESCRIPTION
//
//	Main program logic
//
// 	HISTORY
//
//	NAME   		DATE		REMARKS
//
//	MVM	   		DEC 2009	Creation
//
//  G1OJSv04	FEB 2025	Rewrite
//
//*****************************************************************************/
#include <stdlib.h>
#include <m8c.h>
#include "Util.h"
#include "Display.h"
#include "glb_data.h"
#include "msg_generic.h"
#include "storage.h"
#include "keypad.h"
#include "buzzer.h"
#include "calibrate_reflectometer.h"
#include "pclink.h"
//-----------------------------------------------------------------------------
//  Defines
//-----------------------------------------------------------------------------
typedef enum {SCANPARAM_SWR, SCANPARAM_MODZ} SCAN_SCANPARAM;
typedef enum {SCANSTART_BANDEDGE, SCANSTART_CURRFREQ} SCAN_STARTAT;
typedef enum {SCANSTOP_BANDEDGE, SCANSTOP_GLOBALLIMIT} SCAN_STOPAT;
typedef enum {SCANDIRECTION_UP, SCANDIRECTION_DOWN} SCAN_DIRECTION;
typedef enum {SCANRETURNON_BELOWTHRESH,SCANRETURNON_ABOVETHRESH,SCANRETURNON_FIRSTMINIMUM,SCANRETURNON_BESTMINIMUM} SCAN_RETURNON;
typedef enum {UP,DOWN} DIRECTION;

//-----------------------------------------------------------------------------
//  Prototypes
//-----------------------------------------------------------------------------
static void Do_VSWR_Scan (void);
static void Do_LineLength_Scan (void);
static void Do_Config_Menu (void);
static void Do_DizzlingMeasureCorrectCalc(void);
static void Load_Firmware(void);
static void Config_ByteSettingItem(const char **sSettingStrings, BYTE *bSetting, BYTE bMaxValue);
static BYTE ScanFreqs(SCAN_SCANPARAM xScanParam, SCAN_STARTAT xScanStartAt, SCAN_STOPAT xScanStopAt, SCAN_DIRECTION xScanDirection, SCAN_RETURNON xScanReturnOn, DWORD dwStepHz);
static void CycleBand(void);
static void ChangeCurrHz(DIRECTION xDir);
static void cycleParameter(BYTE *bSetting, BYTE bMaxValue, DIRECTION xDir);
static void handleKeypress(BYTE bKey);
static void PowerSave(void);

//-----------------------------------------------------------------------------
//  MAIN
//-----------------------------------------------------------------------------
void main(void)
{
	BYTE bKey = 0;

	M8C_ClearWDTAndSleep;		
	M8C_EnableIntMask(INT_MSK0, INT_MSK0_SLEEP);
	M8C_EnableGInt;					
	DISP_Setup();						// Initialise display
	
	SetPowerDigitalAndAnalogue(PWRON);
	
	// Display welcome screen
	DISP_CStrAtRowCol(0,0, g_welcome1Str);
	DISP_CStrAtRowCol(1,0, g_welcome2Str);
	Delay_64ths(TIME_FLASH_MSG);

	STR_Restore();					// Load cal and config data from EEPROM, with warning message if not calibrated
	SetDDSGain();					// it was set at power on but now STR_Restore() has given us a new setting
	
	//set initial band (scope to store band initial freqs in EEPROM - make g_wBandInitialFreq var not const)
	g_bBandIndex = BAND_ATPWRON;
	g_dwCurrHz=BAND_FREQ_ToHz * g_wBandInitialFreq[g_bBandIndex];	// current frequency in Hz

	// Check Vf level
	if (BridgeVf()<500)	{
		BUZZER_Morse_Err();
		DISP_CStrAtRowCol(0,0, gErrorAdjustVfStr);
		DISP_CStrAtRowCol(1,0, gPressAnyKeyStr);
		KEYPAD_WaitKey(TIME_WAIT_KEY_S);	// Important, so wait for key press
	}
	
	// clear screen and start main loop
	DISP_Clear();
	g_bIdleCounter = g_bUserIdle[g_xConf.bUserIdle];			// Initial set Idle counter
	do {
		if((g_bMode==MODE_SIG) || (g_bMode==MODE_VFO)) {
			DISP_Power(BridgeVz());	
		} else {
			Do_DizzlingMeasureCorrectCalc();
			if(g_bMode==MODE_IMP) {DISP_SRXZ();}
			else if(g_bMode==MODE_CAP) {DISP_Capacitance();}
			else if(g_bMode==MODE_IND) {DISP_Inductance();}
		}
		if(g_bMode!=MODE_SIG) DISP_Frequency();							

		// wait here until key pressed or measurement timer expires
		g_bMeasureCounter = MEASURE_PERIOD;		
		do {	
			if ((g_bIdleCounter==0) && (g_bUserIdle[g_xConf.bUserIdle] != 0)) PowerSave();
			if (g_bMeasureCounter==0) break;	
			bKey = KEYPAD_Get();
		} while(!bKey);

		if (bKey) handleKeypress(bKey);
		
	} while (TRUE);

}

static void handleKeypress(BYTE bKey){

	g_bIdleCounter = g_bUserIdle[g_xConf.bUserIdle];

	if(bKey == KBD_CONFIG)  {
		if (g_bIncDigitSelect) 	 		{g_bIncDigitSelect=0; }			// Config acts as an escape key for inc control digit select
		else if (g_bMode == MODE_VFO) 	{g_bVFOConfig=~g_bVFOConfig;}	// If in VFO mode, config key toggles power setting & monitor options
		else {Do_Config_Menu();}
	}
	
	if(bKey == KBD_SCAN) Do_VSWR_Scan(); 
	
	if(bKey == KBD_MODE)    {
		DISP_Clear();
		cycleParameter(&g_bMode, MODE_MAX, UP); 			// cycle to next MODE
		if (g_bMode == MODE_VFO) Set_DDS(g_dwCurrHz);		// if going into VFO mode, turn on DDS
	}
			
	if((bKey == KBD_UP_DWN) && (g_bMode != MODE_SIG)) g_bIncDigitSelect = ~g_bIncDigitSelect;    // Toggle between cursor or frequency change modes
	if((bKey == KBD_BAND) && (g_bMode != MODE_SIG)) CycleBand(); 

	if((bKey==KBD_UP) && (g_bMode != MODE_SIG)){								
		if (g_bIncDigitSelect) {cycleParameter(&g_bIncDigit, MAX_INCREMENT, UP);} 		// Move frequency cursor left & cycle back to right
		else if (g_bVFOConfig) { cycleParameter(&g_bDDS_GainStep, GAIN_SETTINGS_MAX, UP); SetDDSGain();}	// increase DDS level
		else ChangeCurrHz(UP); 
	}
	if((bKey==KBD_DWN) && (g_bMode != MODE_SIG)){								
		if (g_bIncDigitSelect) {cycleParameter(&g_bIncDigit, MAX_INCREMENT, DOWN); }  	// Move frequency cursor right & cycle back to left
		else if (g_bVFOConfig) {cycleParameter(&g_bDDS_GainStep, GAIN_SETTINGS_MAX, DOWN); SetDDSGain(); }	// decrease DDS level
		else ChangeCurrHz(DOWN); 
	}

	// speedkeys: if not SIG mode, enter and stay in the loop below until key released
	// note - could also use g_bSpeedKeyCounter in place of g_bSpeedKeysOn (opposite logic) & delete that
	if((g_bSpeedKeysOn) || (g_bMode != MODE_SIG)){ 
		DISP_Clear();
		while (g_bSpeedKeysOn && bKey){
			bKey = KEYPAD_Get();
			if( bKey == KBD_UP	) { ChangeCurrHz(UP);}
			if( bKey == KBD_DWN ) { ChangeCurrHz(DOWN); }
		}
	}

}

static void PowerSave(void){
// code waits in KEYPAD_SysSuspendAndWakeFromPress until that happens key pressed	
	SetPowerDigitalAndAnalogue(PWROFF);
	KEYPAD_SysSuspendAndWakeFromPress();
	SetPowerDigitalAndAnalogue(PWRON);
	g_bIdleCounter = g_bUserIdle[g_xConf.bUserIdle];
}

static void CycleBand(void){
	g_bBandIndex = (g_bBandIndex+1) % BAND_MAX; 
	g_dwCurrHz = g_wBandInitialFreq[g_bBandIndex] * BAND_FREQ_ToHz ;
	if(!g_bBandIndex) BUZZER_Beep();
	// In VFO mode we don't call Do_DizzlingMeasureCorrectCalc, so we need to set frequency here
	if(g_bMode==MODE_VFO) Set_DDS(g_dwCurrHz);
}

static void ChangeCurrHz(DIRECTION xDir){
	DWORD dwNewHz = (xDir == UP)? (g_dwCurrHz + g_xIncCtrl[g_bIncDigit].dwInc):(g_dwCurrHz - g_xIncCtrl[g_bIncDigit].dwInc);
	if(    (dwNewHz < g_wBandBoundaries[g_bBandIndex] * BAND_FREQ_ToHz ) 
		|| (dwNewHz > g_wBandBoundaries[g_bBandIndex+1] * BAND_FREQ_ToHz ) ) return;	
	g_dwCurrHz = dwNewHz;
	// In VFO mode we don't call Do_DizzlingMeasureCorrectCalc, so we need to set frequency here
	if(g_bMode==MODE_VFO) Set_DDS(g_dwCurrHz);
	DISP_Frequency();
}

//Function to increment a setting until it reaches its max value and then return it to zero
//If bUpDown is 1, cycles down to zero and back to max value
static void cycleParameter(BYTE *bSetting, BYTE bMaxValue, DIRECTION xDir)
{
	if(xDir == DOWN) {
		if (--*bSetting<=0) *bSetting = bMaxValue; 
	} else {
		if (++*bSetting>=bMaxValue) *bSetting = 0; 
	}
}

//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Do_DizzlingMeasureCorrectCalc
//  DESCRIPTION:  	Briefly step up in frequency & measure reactance, then return
//					to current frequency and measure again (both measurements also
//					give full set of VSWR, |Z|, R and X). If reactance increased 
//					with frequency, set sign of reactance to +ve else -ve, except
//					if the change is small, leave sign of reactance as it is.
//  ARGUMENTS:		none
//  RETURNS:		Nothing
//-----------------------------------------------------------------------------
static void Do_DizzlingMeasureCorrectCalc(void)
{
	DWORD dwDizzlingMemoryHz 	= g_dwCurrHz;
	WORD wX10_DizzledReactance;
	g_dwCurrHz = g_dwCurrHz*(100+DIZZLING_OFFSET_PERCENT) / 100;	// change to dizzled frequency
	MeasureCorrectCalc();					// find reactance (incl full set) at dizzling frequency
	wX10_DizzledReactance 	= g_wX10;
	g_dwCurrHz=dwDizzlingMemoryHz;			// change back to non-dizzled frequency
	MeasureCorrectCalc();					// measure full set at non-dizzled frequency
	if ( (int)(wX10_DizzledReactance - g_wX10) > 5 || (g_wX10==0) ) 
		{g_bSgnX = '+';}
	else if ( (int)(g_wX10-wX10_DizzledReactance) > 5) 
		{g_bSgnX = '-';}
}
//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Do_VSWR_Scan
//  DESCRIPTION:  	Scan within band limits to find minimum VSWR that is also below SWR_BW_THRESH
//					If found, scan up and down (including beyond band limits) to
//					find SWR bandwidth at SWR_BW_THRESH
//  ARGUMENTS:		none
//  RETURNS:		Nothing
//-----------------------------------------------------------------------------
static void Do_VSWR_Scan (void)
{
	WORD wScanStepkHz=250;
	DWORD dwMinHz;
	DWORD dwHzLow;
	DWORD dwHzHigh;

	// STEP 1: scan the whole band for best minimum & repeat at smaller step if necessary
	do{	
		if(ScanFreqs(SCANPARAM_SWR, SCANSTART_BANDEDGE, SCANSTOP_BANDEDGE, 
			SCANDIRECTION_UP, SCANRETURNON_BESTMINIMUM, 1000*(DWORD)wScanStepkHz)) {return;};
		// no match found - give opportunity to scan again at a finer step
		BUZZER_Beep();
		DISP_CStrAtRowCol(0, 0, gBlankStr_16); DISP_CStrAtRowCol(0, 0, gErrNoMatchingStr);
   		DISP_CStrAtRowCol(1, 0, gErrNoMatchContinueStr);
		if (KEYPAD_WaitKey(TIME_WAIT_KEY_S) != KBD_DWN) {return;}
		wScanStepkHz /=4;
	} while (1);
	
	// if code arrives here, a match was found, so:
	// STEP 2: search downwards and upwards from the global minimum to find the bandwidth,
	// display the bandwidth and return with global variables set to display full measurement results at match frequency

	BUZZER_Beep(); // match found
	dwMinHz=g_dwCurrHz;							// remember best match freq and scan down to SWR>threshold
	ScanFreqs(SCANPARAM_SWR, SCANSTART_CURRFREQ, SCANSTOP_BANDEDGE, 
		SCANDIRECTION_DOWN, SCANRETURNON_ABOVETHRESH, 1000*(DWORD)wScanStepkHz);
	dwHzLow=g_dwCurrHz;
	g_dwCurrHz=dwMinHz;							// set freq to match freq and scan up to SWR>threshold
	ScanFreqs(SCANPARAM_SWR, SCANSTART_CURRFREQ, SCANSTOP_BANDEDGE, 
		SCANDIRECTION_UP, SCANRETURNON_ABOVETHRESH,  1000*(DWORD)wScanStepkHz);
	dwHzHigh=g_dwCurrHz;
	
	// Set g_dwCurrHz to min swr freq, measure and display results (live SWR and Frequency plus BW in bottom row) and wait for keypress
	g_dwCurrHz=dwMinHz;
	DISP_Frequency(); 
	MeasureCorrectCalc();
	DISP_SRXZ(); DISP_CStrAtRowCol(1, 0, gBlankStr_16); DISP_CStrAtRowCol(1, 0, gBandWidthStr);
	ultoa(g_buffer16, dwHzHigh /1000 - dwHzLow /1000, 10);
	DISP_StrAtRowCol(1, 4, g_buffer16);
	
	KEYPAD_WaitKey(TIME_WAIT_KEY_S);

}

//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Do_LineLength_Scan
//  DESCRIPTION:  	Scanning routine
//  ARGUMENTS:		none
//  RETURNS:		Nothing
//-----------------------------------------------------------------------------
static void Do_LineLength_Scan (void)
{
	WORD wScanStepkHz=250;
	BYTE bMinimaFound=0;
	WORD wGapkHz;
	WORD wHWkHz;
	WORD wLastMinkHz;

	DISP_Clear();
	g_dwCurrHz=FREQ_MIN_Hz;
	do{	
		if(!ScanFreqs(SCANPARAM_MODZ, SCANSTART_CURRFREQ, SCANSTOP_GLOBALLIMIT, 
			SCANDIRECTION_UP, SCANRETURNON_FIRSTMINIMUM, 1000*(DWORD)wScanStepkHz)) {break;}
		if(bMinimaFound==0){		// first minimum |Z| - assume this is the first length = quarter wavelength frequency
			wHWkHz=(DWORD)2*g_dwCurrHz/1000;
			bMinimaFound=1;
		} else {
			wGapkHz=g_dwCurrHz/1000-wLastMinkHz;
			if(wGapkHz > wHWkHz/10) {			// another half wave, so average those
				wHWkHz = wHWkHz/2 + wGapkHz/2;
			}
		}	
		wLastMinkHz=g_dwCurrHz/1000;
		BUZZ_Morse_Dit();
		g_dwCurrHz += 1000*(DWORD)wScanStepkHz;		// advance one step
	} while (g_dwCurrHz <= FREQ_MAX_Hz);
	
	if(bMinimaFound) {
		BUZZER_Morse_End();
		DISP_Clear();
		DISP_CableLength(wHWkHz);	
	} else {BUZZER_Morse_Err();}
}	


//-----------------------------------------------------------------------------
//  FUNCTION NAME:	ScanFreqs
//  DESCRIPTION:  	Scan up or down in frequency and stop as specified by 
//					arguments leaving final frequency and measurement in global measurement variables
//  ARGUMENTS:		SCAN_SCANPARAM 	= SCANPARAM_SWR | SCANPARAM_MODZ -> parameter to trigger return TRUE 
//					SCAN_STARTAT 	= SCANSTART_BANDEDGE | SCANSTART_CURRFREQ	-> frequency to start at
//					SCAN_STOPAT 	= SCANSTOP_BANDEDGE | SCANSTOP_GLOBALLIMIT	-> trigger to stop and return FALSE
//					SCAN_DIRECTION	= SCANDIRECTION_UP | SCANDIRECTION_DOWN		-> which way to scan
//					SCAN_RETURNON 	= SCANRETURNON_BELOWTHRESH | SCANRETURNON_ABOVETHRESH -> condition to trigger return TRUE
//										| SCANRETURNON_FIRSTMINIMUM |SCANRETURNON_BESTMINIMUM
//					DWORD dwStepHz	-> scan step in Hz
//  RETURNS:		TRUE if SCAN_RETURNON condition met, false if SCAN_STOPAT condition met
//-----------------------------------------------------------------------------
static BYTE ScanFreqs(SCAN_SCANPARAM xScanParam, SCAN_STARTAT xScanStartAt, SCAN_STOPAT xScanStopAt, SCAN_DIRECTION xScanDirection, SCAN_RETURNON xScanReturnOn, DWORD dwStepHz)
{
		DWORD dwScanStopHz;
		WORD wThresh = (xScanParam==SCANPARAM_SWR)? SWR_BW_THRESH:100;
		WORD wParam;
		WORD wLastParam=0;
		WORD wBestParam =0;
		DWORD dwBestParam_Hz;
		BYTE bLastChangeWasDown = 0;
		
		if(xScanStartAt == SCANSTART_BANDEDGE) g_dwCurrHz =  BAND_FREQ_ToHz * ((xScanDirection == SCANDIRECTION_UP)? g_wBandBoundaries[g_bBandIndex]:g_wBandBoundaries[g_bBandIndex+1]);
		if(xScanDirection == SCANDIRECTION_DOWN) dwScanStopHz = (xScanStopAt == SCANSTOP_BANDEDGE)? (BAND_FREQ_ToHz * g_wBandBoundaries[g_bBandIndex]):FREQ_MIN_Hz; 
		if(xScanDirection == SCANDIRECTION_UP) dwScanStopHz = (xScanStopAt == SCANSTOP_BANDEDGE)? (BAND_FREQ_ToHz * g_wBandBoundaries[g_bBandIndex+1]):FREQ_MAX_Hz ;
	
		do
		{	
			MeasureCorrectCalc();
			wParam = (xScanParam == SCANPARAM_SWR)? g_wSwr100:g_wZ10;
			DISP_Frequency(); 
			DISP_SRXZ();
			if ( (xScanReturnOn == SCANRETURNON_FIRSTMINIMUM) && (bLastChangeWasDown) && (wParam > wLastParam) ) {
				// last change was down and this change was up so reverse one step and return true
				if (xScanParam == SCANPARAM_SWR) {g_wSwr100 = wLastParam;} else {g_wZ10 = wLastParam;} 
				if (xScanDirection == SCANDIRECTION_DOWN) {g_dwCurrHz += dwStepHz;} else {g_dwCurrHz -= dwStepHz;}	
				return TRUE;
			}
			if( (xScanReturnOn == SCANRETURNON_BELOWTHRESH) && wParam <= wThresh) return TRUE;
			if( (xScanReturnOn == SCANRETURNON_ABOVETHRESH) && wParam >= wThresh) return TRUE;
			
			bLastChangeWasDown = (wLastParam >  wParam)? 1:0;
			if(wParam < wBestParam) {
				wBestParam = wParam;
				dwBestParam_Hz=g_dwCurrHz;
			}
			wLastParam=wParam;
			
			if (xScanDirection == SCANDIRECTION_DOWN) {g_dwCurrHz -= dwStepHz;} else {g_dwCurrHz += dwStepHz;}
						
			if( (xScanDirection == SCANDIRECTION_DOWN) && (g_dwCurrHz < dwScanStopHz)) {break;} 
				else if ( (xScanDirection == SCANDIRECTION_UP) && (g_dwCurrHz > dwScanStopHz))	{break;}			
		} while (1);

		//code reaches this point only on a stop trigger (band edge or global edge)
		if(SCANRETURNON_BESTMINIMUM && wBestParam >0){
			g_dwCurrHz=dwBestParam_Hz;
			if(xScanParam == SCANPARAM_SWR) {g_wSwr100=wBestParam;} else {g_wZ10=wBestParam;}		
			return TRUE;
		}
		
		// scan hit a stop trigger without finding a FIRSTMINIMUM or BEST MINIMUM
		return FALSE;
}
//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Do_Config_Menu
//
//  DESCRIPTION: 	Configuration routine
//
//  ARGUMENTS: 		none.
//
//  RETURNS: 		none.
//-----------------------------------------------------------------------------
static void Do_Config_Menu (void)
{
	BYTE bMenu = 0;
	BYTE bKey;

	DISP_Clear(); DISP_HideCursor();
	
	do  {	
		DISP_CStrAtRowCol(0, 0, gBlankStr_16);
		DISP_CStrAtRowCol(0, 0, gConfigStr[bMenu]);
		bKey = KEYPAD_WaitKey(TIME_WAIT_KEY_S);
		if (bKey==KBD_UP) 		break;
		if (bKey==KBD_CONFIG) 	cycleParameter(&bMenu, CONFIG_MAX, UP);	
		if (bKey==KBD_DWN) {
			if (bMenu==CONFIG_PCLINK) 		{ PcLink(); break; }
			if (bMenu==CONFIG_Idle) 		{ Config_ByteSettingItem(gIdleStr, &g_xConf.bUserIdle, USER_IDLE_MAX); break;}
			if (bMenu==CONFIG_CWPitch) 		{ Config_ByteSettingItem(gCWPitchStr, &g_xConf.bCWPitch, CWPitch_MAX); break;}
			if (bMenu==CONFIG_CableLength)	{ Do_LineLength_Scan(); break;}	
			if (bMenu==CONFIG_CALIB) 		{ Calibrate_Reflectometer();	break;	}	
			if (bMenu==CONFIG_SW_LOAD) 		{ Load_Firmware(); break; }
		}
	} while (TRUE);
	
	DISP_Clear();
}

//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Config_ByteSettingItem
//
//  DESCRIPTION:	On keypress 'config' steps through the values of a parameter
//					defined by a BYTE setting. At any point, pressing UP cancels 
//					the operation, pressing down confirms saving the displayed value.
//  ARGUMENTS:
//      const char **sSettingStrings, pointer to the array of pointers to the setting 
//									  strings for the parameter from glb_data.h
//		BYTE *bSetting,	pointer to the parameter to be set
//		BYTE bMaxValue, maximum value at which the value returns to zero
//
//  RETURNS: none.
//-----------------------------------------------------------------------------
static void Config_ByteSettingItem(const char **sSettingStrings, BYTE *bSetting, BYTE bMaxValue)
{
	BYTE bCurrValue = *bSetting;
	BYTE bKey;
	DISP_CStrAtRowCol(1, 0, sSettingStrings[bCurrValue]);
	do {
		DISP_CStrAtRowCol(1, 0, sSettingStrings[bCurrValue]);
		bKey = KEYPAD_WaitKey(TIME_WAIT_KEY_S);
		if (bKey==KBD_CONFIG) 	cycleParameter(&bCurrValue, bMaxValue, 0);
		if (bKey==KBD_UP) 		break;
		if (bKey==KBD_DWN){
			*bSetting = bCurrValue;
			STR_SaveConfig();
			DISP_CStrAtRowCol(1, 8, gValueSavedStr);
			Delay_64ths(TIME_FLASH_MSG);
			return;
		}
	} while(TRUE);
	
	DISP_CStrAtRowCol(1, 0, gNothingChangedStr);
	Delay_64ths(TIME_FLASH_MSG);
}

// Function to handle the load firmware branch of the config menu
static void Load_Firmware(void)
{
	if(getUserConfirmation()) {
		DISP_Clear(); DISP_CStrAtRowCol(0, 0, gSwLoadingStr);
		M8C_DisableGInt;
		asm ("ljmp 0x0000"); 	// Perform Software Reset
	}
}
