//*****************************************************************************/
//  This file is a part of the "SARK100 SWR Analyzer firmware"
//
//	Copyright © 2025 Alan Robinson G1OJS Hampshire England G1OJS@yahoo.com with 
//  acknowledgement & thanks to Melchor Varela © 2010, EA4FRB Madrid, Spain 
//	(melchor.varela@gmail.com) for the overall software and ideas.
//  
//  "SARK100 SWR Analyzer firmware" is free software: you can redistribute it
//  and/or modify it under the terms of the GNU General Public License as
//  published by the Free Software Foundation, either version 3 of the License,
//  or (at your option) any later version.
//
//  "SARK100 SWR Analyzer firmware" is distributed in the hope that it will be
//  useful,  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with "SARK100 SWR Analyzer firmware".  If not,
//  see <http://www.gnu.org/licenses/>.
//*****************************************************************************/
//*****************************************************************************/
//
//	PROJECT:	SARK100 SWR Analyzer
// 	FILE NAME: 	scans.c
// 	AUTHOR:		G1OJS - Alan Robinson
// 	DESCRIPTION	Scanning functions
// 	HISTORY
//	NAME   		DATE		REMARKS	
//	AJR			FEB 2025	G1OJS  - creation 
//*****************************************************************************/

#include <stdlib.h>
#include <m8c.h>
#include "scans.h"
#include "morse.h"
#include "control.h"
#include "screens.h"
#include "glb_data.h"
#include "msg_generic.h"
#include "keypad.h"
#include "bridge.h"
#include "correctionmodel.h"

void MeasureCorrectCalc(void);

//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Do_VSWR_Scan
//  DESCRIPTION:  	Scan within band limits to find minimum VSWR that is also below SWR_BW_THRESH
//					If found, scan up and down (including beyond band limits) to
//					find SWR bandwidth at SWR_BW_THRESH
//  ARGUMENTS:		none
//  RETURNS:		Nothing
//-----------------------------------------------------------------------------
void Do_VSWR_Scan (void)
{
	#define useFast FALSE
	#define initStepkHz 101

	DWORD dwEntryFreqHz=g_dwCurrHz;
	WORD wScanStepkHz = initStepkHz;
	DWORD dwMinHz;
	DWORD dwHzLow;
	DWORD dwHzHigh;
	BYTE bMinFound;

	// STEP 1: scan the whole band for best minimum & repeat at smaller step if necessary
	do{	
		bMinFound = ScanFreqs(SCANPARAM_SWR, SCANSTART_BANDEDGE, SCANFALSEIF_BANDEDGE, 
			SCANDIRECTION_UP, SCANTRUEIF_LOWESTMINIMUM, useFast, 1000*(DWORD)wScanStepkHz);
		// remove this if so that there is always an opportunity to refine the freq? Change message obvs
		if(bMinFound && (g_wSwr100 < SWR_BW_THRESH)) {break;};
		// no match found - give opportunity to scan again at a finer step
		Morse_Dah();
		Screen_CStrAtRowCol(0, 0, gBlankStr_16); Screen_CStrAtRowCol(0, 0, gErrNoMatchingStr);
   		Screen_CStrAtRowCol(1, 0, gErrNoMatchContinueStr);

		if (KEYPAD_WaitKey(TIME_WAIT_KEY_S) != KBD_DWN) {g_dwCurrHz = dwEntryFreqHz; return;}
		wScanStepkHz /=4;
	} while (1);
	// if code arrives here, a match was found, so:
	Morse_Dah(); 
	dwMinHz=g_dwCurrHz;	// remember best match freq 
	
	// STEP 2: search downwards and upwards from the global minimum to find the bandwidth,
	// display the bandwidth and return with global variables set to display full measurement results at match frequency
	(void)ScanFreqs(SCANPARAM_SWR, SCANSTART_CURRFREQ, SCANFALSEIF_BANDEDGE, 
			SCANDIRECTION_DOWN, SCANTRUEIF_ABOVETHRESH, FALSE, 1000*(DWORD)wScanStepkHz); 
	dwHzLow=g_dwCurrHz;
	
	g_dwCurrHz=dwMinHz;							// set freq to match freq and scan up to SWR>threshold or band edge
	(void)ScanFreqs(SCANPARAM_SWR, SCANSTART_CURRFREQ, SCANFALSEIF_BANDEDGE, 
			SCANDIRECTION_UP, SCANTRUEIF_ABOVETHRESH,  FALSE, 1000*(DWORD)wScanStepkHz);
	dwHzHigh=g_dwCurrHz;
	
	// if g_dwCurrHz <> band edge, reduce step and refine threshold crossing frequency

	
	// Set g_dwCurrHz to min swr freq, measure and display results (live SWR and Frequency plus BW in bottom row) and wait for keypress
	g_dwCurrHz=dwMinHz;
	Screen_Frequency(); 
	MeasureCorrectCalc();
	Screen_SRXZ(); 
	
	Screen_HideCursor();
	Screen_CStrAtRowCol(1, 0, gBlankStr_16);
	utoa(g_buffer16, dwHzLow /1000, 10); Screen_StrAtRowCol(1, 0, g_buffer16);
	utoa(g_buffer16, dwHzHigh /1000, 10); Screen_StrAtRowCol(1, 8, g_buffer16);
	
	KEYPAD_WaitKey(TIME_WAIT_KEY_S);
	
	g_dwCurrHz = dwEntryFreqHz;

}

//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Do_LineLength_Scan
//  DESCRIPTION:  	Scanning routine
//  ARGUMENTS:		none
//  RETURNS:		Nothing
//-----------------------------------------------------------------------------
void Do_LineLength_Scan (void)
{
	#define GOFAST TRUE
	#define STEPKHZ 233
	
	WORD 	wLastMinFreqkHz;
	DWORD 	dwEntryFreqHz=g_dwCurrHz;
	BYTE 	bMinCount;

//	UART_CmdReset(); 					// Initialize receiver/cmd buffer
//	UART_IntCntl(UART_ENABLE_RX_INT); 	// Enable RX interrupts
//	UART_Start(UART_PARITY_NONE); 		// Enable UART


	do { // this loop gives opportunity to repeat the whole process without going through menus again

		Screen_HideCursor();
  		Screen_Clear();
		Screen_CStrAtRowCol(0, 0, gModZMinimaStr);

//		UART_PutCRLF();
		// scan upwards from device min freq and stop on each minimum and record frequency
		g_dwCurrHz=FREQ_MIN_Hz;
		bMinCount=0;
		do {	
			if ( 	 ScanFreqs(SCANPARAM_MODZ, SCANSTART_CURRFREQ, SCANFALSEIF_GLOBALLIMIT, SCANDIRECTION_UP, SCANTRUEIF_FIRSTMINIMUM, GOFAST, (DWORD)1000*STEPKHZ)
				&& 	(Read_ADC(VzPort) < Read_ADC(VaPort))   ) // looking for minima below 50 ohms (not wobbles on peaks)
			{
				Morse_Dit();
				bMinCount += (bMinCount==0)? 1:2;		// count 1,3,5,7 ... from start at 0
				wLastMinFreqkHz=g_dwCurrHz/1000;
				utoa(g_buffer16, wLastMinFreqkHz, 10);
				Screen_StrAtRowCol(0, 10, g_buffer16);
//			utoa(g_buffer16, g_dwCurrHz/1000, 10);	UART_PutString(g_buffer16); UART_PutCRLF();
			}
			g_dwCurrHz += (DWORD)1000*STEPKHZ;		// advance one step (is this necessary?)
		} while (g_dwCurrHz <= FREQ_MAX_Hz) ;

//		UART_PutCRLF();UART_PutCRLF();

		Screen_CableLength( ((DWORD)75000*(DWORD)g_bVF[g_xConf.bVF]*(DWORD)bMinCount) / wLastMinFreqkHz);
		
		// opportunity to repeat the whole process without going through menus again (press any key but UP)
		if( KEYPAD_WaitKey(TIME_WAIT_KEY_S) == KBD_UP ) break;		
	} while (TRUE);
	g_dwCurrHz = dwEntryFreqHz;
	
}	


//-----------------------------------------------------------------------------
//  FUNCTION NAME:	ScanFreqs
//  DESCRIPTION:  	Scan up or down in frequency and stop as specified by 
//					arguments leaving final frequency and measurement in global measurement variables
//					In all cases, a full measurement and calculation is done prior to return.
//					The final frequency is that of the condition that triggered the return: (lowest) minimum or the band edge or global limit
//					Currently, searching for maxima is not coded.
//  ARGUMENTS:		SCAN_SCANPARAM 	= SCANPARAM_SWR | SCANPARAM_MODZ -> parameter to trigger return TRUE 
//					SCAN_STARTAT 	= SCANSTART_BANDEDGE | SCANSTART_CURRFREQ	-> frequency to start at
//					SCAN_FALSEIF 	= SCANFALSEIF_BANDEDGE | SCANFALSEIF_GLOBALLIMIT	-> trigger to stop and return FALSE
//					SCAN_DIRECTION	= SCANDIRECTION_UP | SCANDIRECTION_DOWN		-> which way to scan
//					SCAN_TRUEIF 	= SCANTRUEIF_BELOWTHRESH | SCANTRUEIF_ABOVETHRESH -> condition to trigger return TRUE if SCAN_SCANPARAM == SCANPARAM_SWR
//									  SCANTRUEIF_FIRSTMINIMUM |SCANTRUEIF_LOWESTMINIMUM -> condition to trigger return TRUE
//					BYTE bFast		-> if set, uses Vr as proxy for SWR and Vz as proxy for |Z|
//									   and doesn't update display whilst scanning. This requires one bridge voltage rather than
//									   four, and the increase in speed is approx 3:1 at the expense of using the uncalibrated proxy.
//					DWORD dwStepHz	-> scan step in Hz
//  RETURNS:		TRUE if SCAN_TRUEIF condition met, false if SCAN_FALSEIF condition met

//-----------------------------------------------------------------------------
BYTE ScanFreqs(SCAN_SCANPARAM xScanParam, SCAN_STARTAT xScanStartAt, SCAN_FALSEIF xScanFalseIf, SCAN_DIRECTION xScanDirection, SCAN_TRUEIF xScanTrueIf, BYTE bFast, DWORD dwStepHz) 
{
		DWORD dwScanStopFalseHz;
		WORD wParam;
		WORD wLastParam=0;
		WORD wBestParam = WORD_MAX;
		DWORD dwBestParam_Hz;
		BYTE bLastChangeWasDown = 0;
		
		if(xScanStartAt == SCANSTART_BANDEDGE) g_dwCurrHz =  BAND_FREQ_ToHz * ((xScanDirection == SCANDIRECTION_UP)? g_wBandBoundaries[g_bBandIndex]:g_wBandBoundaries[g_bBandIndex+1]);
		if(xScanDirection == SCANDIRECTION_DOWN) dwScanStopFalseHz = (xScanFalseIf == SCANFALSEIF_BANDEDGE)? (BAND_FREQ_ToHz * g_wBandBoundaries[g_bBandIndex]):FREQ_MIN_Hz; 
		if(xScanDirection == SCANDIRECTION_UP) dwScanStopFalseHz = (xScanFalseIf == SCANFALSEIF_BANDEDGE)? (BAND_FREQ_ToHz * g_wBandBoundaries[g_bBandIndex+1]):FREQ_MAX_Hz ;	

		if( (xScanTrueIf == SCANTRUEIF_BELOWTHRESH) || (xScanTrueIf == SCANTRUEIF_ABOVETHRESH) ) bFast=FALSE;

		do {	
			if (bFast) {
				Set_DDS(g_dwCurrHz);
				wParam = (xScanParam == SCANPARAM_SWR)? Read_ADC(VrPort): Read_ADC(VzPort);	
			} else {
				MeasureCorrectCalc();
				wParam = (xScanParam == SCANPARAM_SWR)? g_wSwr100:g_wZ10;
				Screen_Frequency(); 
				Screen_SRXZ();
			}
					
			if ( (xScanTrueIf == SCANTRUEIF_FIRSTMINIMUM) && (bLastChangeWasDown) && (wParam > wLastParam) ) {
				// last change was down and this change was up so reverse one step, measure and return true
				//if (xScanDirection == SCANDIRECTION_DOWN) {g_dwCurrHz += dwStepHz;} else {g_dwCurrHz -= dwStepHz;}	
				g_dwCurrHz += (xScanDirection == SCANDIRECTION_UP)? (-(long)dwStepHz):dwStepHz;
				MeasureCorrectCalc();
				return TRUE;
			}
			if (xScanParam == SCANPARAM_SWR){
				if( (xScanTrueIf == SCANTRUEIF_BELOWTHRESH) && wParam <= SWR_BW_THRESH) {MeasureCorrectCalc(); return TRUE;}
				if( (xScanTrueIf == SCANTRUEIF_ABOVETHRESH) && wParam >= SWR_BW_THRESH) {MeasureCorrectCalc(); return TRUE;}
			}
			
			bLastChangeWasDown = (wParam <= wLastParam);
			wLastParam=wParam;
			
			if(wParam < wBestParam) {
				wBestParam = wParam;
				dwBestParam_Hz=g_dwCurrHz;
			}
			
			g_dwCurrHz += (xScanDirection == SCANDIRECTION_DOWN)? (-(long)dwStepHz):dwStepHz;
			if( (g_dwCurrHz < dwScanStopFalseHz) && (xScanDirection == SCANDIRECTION_DOWN) ) { break; } 
			if( (g_dwCurrHz > dwScanStopFalseHz) && (xScanDirection == SCANDIRECTION_UP) ) { break; } 

		} while (1);

		// code reaches this point only on a band edge or global edge, so only best minimum can be a true return.
		// if (and only if) there was a minimum (and hence a lowest minimum), wBestParam < WORD_MAX
		if( (xScanTrueIf == SCANTRUEIF_LOWESTMINIMUM) && (wBestParam < WORD_MAX)){
			g_dwCurrHz=dwBestParam_Hz;
			if (bFast) MeasureCorrectCalc();		// if using proxy, do a true measurement at the min point
			if(xScanParam == SCANPARAM_SWR) {g_wSwr100=wBestParam;} else {g_wZ10=wBestParam;}		
			return TRUE;
		}
		
		// finally, return false at the stop frequency with a measurement first		
		g_dwCurrHz = dwScanStopFalseHz;
		MeasureCorrectCalc();
		return FALSE;

}