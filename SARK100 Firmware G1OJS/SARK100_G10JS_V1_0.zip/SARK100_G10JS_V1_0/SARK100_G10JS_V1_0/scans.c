//*****************************************************************************/
//  This file is a part of the "SARK100 SWR Analyzer firmware"
//
//	Copyright © 2025 Alan Robinson G1OJS Hampshire England G1OJS@yahoo.com with 
//  acknowledgement & thanks to Melchor Varela © 2010, EA4FRB Madrid, Spain 
//	(melchor.varela@gmail.com) for the overall software and ideas.
//  
//  "SARK100 SWR Analyzer firmware" is free software: you can redistribute it
//  and/or modify it under the terms of the GNU General Public License as
//  published by the Free Software Foundation, either version 3 of the License,
//  or (at your option) any later version.
//
//  "SARK100 SWR Analyzer firmware" is distributed in the hope that it will be
//  useful,  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with "SARK100 SWR Analyzer firmware".  If not,
//  see <http://www.gnu.org/licenses/>.
//*****************************************************************************/
//*****************************************************************************/
//
//	PROJECT:	SARK100 SWR Analyzer
// 	FILE NAME: 	scans.c
// 	AUTHOR:		G1OJS - Alan Robinson
// 	DESCRIPTION	Scanning functions
// 	HISTORY
//	NAME   		DATE		REMARKS	
//	AJR			FEB 2025	G1OJS  - creation 
//*****************************************************************************/

#include <stdlib.h>
#include <m8c.h>
#include "scans.h"
#include "morse.h"
#include "control.h"
#include "screens.h"
#include "glb_data.h"
#include "msg_generic.h"
#include "keypad.h"
#include "bridge.h"
#include "dds.h"
#include "correctionmodel.h"

void MeasureCorrectCalc(void);

// TODO - the latest function here is Do_LineLength_Scan which used to call ScanFreqs
// but now has a better (more memory-efficient, more robust to noise tbc) minimum
// detection algorithm
// Next step is to use this algorithm in VSWR scanning, and factor it into a 
// mindetect function if that makes sense to do
// 


//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Do_VSWR_Scan
//  DESCRIPTION:  	Scan within band limits to find minimum VSWR that is also below SWR_BW_THRESH
//					If found, scan up and down (including beyond band limits) to
//					find SWR bandwidth at SWR_BW_THRESH
//  ARGUMENTS:		none
//  RETURNS:		Nothing
//-----------------------------------------------------------------------------
void Do_VSWR_Scan (void)
{
	#define initStepkHz 101

	DWORD dwEntryFreqHz=g_dwCurrHz;
	WORD wScanStepkHz = initStepkHz;
	DWORD dwMinHz;
	DWORD dwHzLow;
	DWORD dwHzHigh;
	BYTE bMinFound;

	// STEP 1: scan the whole band for best minimum & repeat at smaller step if necessary
	do{	
		bMinFound = ScanFreqs(SCANPARAM_SWR, SCANSTART_BANDEDGE, SCANFALSEIF_BANDEDGE, 
			SCANDIRECTION_UP, SCANTRUEIF_LOWESTMINIMUM, 1000*(DWORD)wScanStepkHz);
		// remove this 'if' so that there is always an opportunity to refine the freq? Change message obvs
		if(bMinFound && (g_wSwr100 < SWR_BW_THRESH)) {break;};
		// no match found - give opportunity to scan again at a finer step
		Morse_Dah();
		Screen_CStrAtRowCol(0, 0, gBlankStr_16); Screen_CStrAtRowCol(0, 0, gErrNoMatchingStr);
   		Screen_CStrAtRowCol(1, 0, gErrNoMatchContinueStr);

		if (KEYPAD_WaitKey(TIME_WAIT_KEY_S) != KBD_DWN) {g_dwCurrHz = dwEntryFreqHz; return;}
		wScanStepkHz /=4;
	} while (1);
	// if code arrives here, a match was found, so:
	Morse_Dah(); 
	dwMinHz=g_dwCurrHz;	// remember best match freq 
	
	// STEP 2: search downwards and upwards from the global minimum to find the bandwidth,
	// display the bandwidth and return with global variables set to display full measurement results at match frequency
	(void)ScanFreqs(SCANPARAM_SWR, SCANSTART_CURRFREQ, SCANFALSEIF_BANDEDGE, 
			SCANDIRECTION_DOWN, SCANTRUEIF_ABOVE_SWR_THRESH, 1000*(DWORD)wScanStepkHz); 
	dwHzLow=g_dwCurrHz;
	
	g_dwCurrHz=dwMinHz;							// set freq to match freq and scan up to SWR>threshold or band edge
	(void)ScanFreqs(SCANPARAM_SWR, SCANSTART_CURRFREQ, SCANFALSEIF_BANDEDGE, 
			SCANDIRECTION_UP, SCANTRUEIF_ABOVE_SWR_THRESH, 1000*(DWORD)wScanStepkHz);
	dwHzHigh=g_dwCurrHz;
	
	// TO DO: if g_dwCurrHz <> band edge, reduce step and refine threshold crossing frequency

	
	// Set g_dwCurrHz to min swr freq, measure and display results (live SWR and Frequency plus BW in bottom row) and wait for keypress
	g_dwCurrHz=dwMinHz;
	Screen_Frequency(); 
	MeasureCorrectCalc();
	Screen_SRXZ(); 
	
	Screen_HideCursor();
	Screen_CStrAtRowCol(1, 0, gBlankStr_16);
	utoa(g_buffer16, dwHzLow /1000, 10); Screen_StrAtRowCol(1, 0, g_buffer16);
	utoa(g_buffer16, dwHzHigh /1000, 10); Screen_StrAtRowCol(1, 8, g_buffer16);
	
	KEYPAD_WaitKey(TIME_WAIT_KEY_S);
	
	g_dwCurrHz = dwEntryFreqHz;

}

//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Do_LineLength_Scan
//  DESCRIPTION:  	Scanning routine
//  ARGUMENTS:		none
//  RETURNS:		Nothing
//-----------------------------------------------------------------------------
void Do_LineLength_Scan (void)
{
	#define STEPKHZ 233
	#define HISTLEN 7
	#define HISTPAT 120
	
	WORD 	wFirstMinFreqkHz;  //test
	WORD 	wLastMinFreqkHz;
	WORD	wParam;
	WORD	wParamPrev;
	BYTE 	bDeltaHist;
	DWORD 	dwEntryFreqHz=g_dwCurrHz;
	BYTE 	bMinCount;

	do { // this loop gives opportunity to repeat the whole process without going through menus again

		Screen_HideCursor();
  		Screen_Clear();
		Screen_CStrAtRowCol(0, 0, gMinimaStr);

		// scan upwards from device min freq and stop on each minimum of *either* Vz or Va and record frequency
		g_dwCurrHz=FREQ_MIN_Hz;
		bMinCount=0;
		wParamPrev=0;
		bDeltaHist=0;
		do {
			Set_DDS(g_dwCurrHz);
			#define min(a, b)  ((a<b)? a:b)
			wParam=min(Read_ADC_DDSUNCHANGED(VaPort), Read_ADC_DDSUNCHANGED(VzPort));
			bDeltaHist <<= 1;
			bDeltaHist |= (wParamPrev >= wParam);
			bDeltaHist &= (1 << HISTLEN) - 1;  
			wParamPrev = wParam;
			
			if(bDeltaHist == HISTPAT)	{
				Morse_Dit();
				wLastMinFreqkHz=g_dwCurrHz/1000 - STEPKHZ*(HISTLEN/2);
				if(bMinCount == 0) wFirstMinFreqkHz = wLastMinFreqkHz;
				bMinCount++;
				utoa(g_buffer16, wLastMinFreqkHz, 10);
				Screen_StrAtRowCol(0, 11, g_buffer16);
			}
			g_dwCurrHz += (DWORD)1000*STEPKHZ;		// advance one step (is this necessary?)
		} while (g_dwCurrHz <= FREQ_MAX_Hz) ;
		
		Screen_CableLength(    ( (DWORD)75000*(DWORD)g_bVF[g_xConf.bVF]*(DWORD)bMinCount ) / ( wLastMinFreqkHz - wFirstMinFreqkHz )      );
		
		// opportunity to repeat the whole process without going through menus again (press any key but UP)
		if( KEYPAD_WaitKey(TIME_WAIT_KEY_S) == KBD_UP ) break;		
	} while (TRUE);
	g_dwCurrHz = dwEntryFreqHz;
}	


//-----------------------------------------------------------------------------
//  FUNCTION NAME:	ScanFreqs
//  DESCRIPTION:  	Scan up or down in frequency and stop as specified by 
//					arguments leaving final frequency and measurement in global measurement variables
//					In all cases, a full measurement and calculation is done prior to return.
//					The final frequency is that of the condition that triggered the return: (lowest) minimum or the band edge or global limit
//					Currently, searching for maxima is not coded.
//  ARGUMENTS:		SCAN_SCANPARAM 	= SCANPARAM_SWR | SCANPARAM_MODZ | SCANPARAM_Vruc | SCANPARAM_Vzuc | SCANPARAM_Vauc | SCANPARAM_VzucORVauc
//										-> parameter to trigger return TRUE 
//										NOTE: scanning on a single voltage gives a speed increase of approx 3:1 at the expense of using 
//										the uncalibrated proxy
//					SCAN_STARTAT 	= SCANSTART_BANDEDGE | SCANSTART_CURRFREQ	-> frequency to start at
//					SCAN_FALSEIF 	= SCANFALSEIF_BANDEDGE | SCANFALSEIF_GLOBALLIMIT	-> trigger to stop and return FALSE
//					SCAN_DIRECTION	= SCANDIRECTION_UP | SCANDIRECTION_DOWN		-> which way to scan
//					SCAN_TRUEIF 	= SCANTRUEIF_BELOW_SWR_THRESH | SCANTRUEIF_ABOVE_SWR_THRESH -> condition to trigger return TRUE if SCAN_SCANPARAM == SCANPARAM_SWR
//									  SCANTRUEIF_FIRSTMINIMUM |SCANTRUEIF_LOWESTMINIMUM -> condition to trigger return TRUE
//					BYTE bFast		-> if set, uses Vr as proxy for SWR and Vz as proxy for |Z|
//									   and doesn't update display whilst scanning. This requires one bridge voltage rather than
//									   four, and the .
//					DWORD dwStepHz	-> scan step in Hz
//  RETURNS:		TRUE if SCAN_TRUEIF condition met, false if SCAN_FALSEIF condition met

//-----------------------------------------------------------------------------
BYTE ScanFreqs(SCAN_SCANPARAM xScanParam, SCAN_STARTAT xScanStartAt, SCAN_FALSEIF xScanFalseIf, SCAN_DIRECTION xScanDirection, SCAN_TRUEIF xScanTrueIf, DWORD dwStepHz) 
{
		DWORD dwScanStopFalseHz;
		WORD wParam;
		WORD wLastParam=0;
		WORD wBestParam = WORD_MAX;
		DWORD dwBestParam_Hz;
		BYTE bLastChangeWasDown = 0;
		
		if(xScanStartAt == SCANSTART_BANDEDGE) g_dwCurrHz =  BAND_FREQ_ToHz * ((xScanDirection == SCANDIRECTION_UP)? g_wBandBoundaries[g_bBandIndex]:g_wBandBoundaries[g_bBandIndex+1]);
		if(xScanDirection == SCANDIRECTION_DOWN) dwScanStopFalseHz = (xScanFalseIf == SCANFALSEIF_BANDEDGE)? (BAND_FREQ_ToHz * g_wBandBoundaries[g_bBandIndex]):FREQ_MIN_Hz; 
		if(xScanDirection == SCANDIRECTION_UP) dwScanStopFalseHz = (xScanFalseIf == SCANFALSEIF_BANDEDGE)? (BAND_FREQ_ToHz * g_wBandBoundaries[g_bBandIndex+1]):FREQ_MAX_Hz ;	
		
		// TODO - SCANTRUEIF_BELOW_SWR_THRESH and SCANTRUEIF_ABOVE_SWR_THRESH only have effect if xScanParam == SCANPARAM_SWR
		// Need error trapping in case future development calls this with one of these as the trigger and xScanParam != SCANPARAM_SWR
		// At the moment, the measures will simply not trigger and no alert will be passed
		
		do {	
			if ((xScanParam == SCANPARAM_SWR) || (xScanParam == SCANPARAM_MODZ)) {
				MeasureCorrectCalc();
				wParam = (xScanParam == SCANPARAM_SWR)? g_wSwr100:g_wZ10;
				Screen_Frequency(); 
				Screen_SRXZ();
			} else {
				Set_DDS(g_dwCurrHz);			
				if (xScanParam == SCANPARAM_Vruc) wParam = Read_ADC_DDSUNCHANGED(VrPort);
				if (xScanParam == SCANPARAM_Vzuc) wParam = Read_ADC_DDSUNCHANGED(VzPort);
				if (xScanParam == SCANPARAM_Vauc) wParam = Read_ADC_DDSUNCHANGED(VaPort);
				#define min(a, b)  ((a<b)? a:b)
				if (xScanParam == SCANPARAM_VzucORVauc) wParam = min(Read_ADC_DDSUNCHANGED(VaPort), Read_ADC_DDSUNCHANGED(VzPort));
			}
	
			if ( (xScanTrueIf == SCANTRUEIF_FIRSTMINIMUM) && (bLastChangeWasDown) && (wParam > wLastParam) ) {
				// last change was down and this change was up so reverse one step, measure and return true
				//if (xScanDirection == SCANDIRECTION_DOWN) {g_dwCurrHz += dwStepHz;} else {g_dwCurrHz -= dwStepHz;}	
				g_dwCurrHz += (xScanDirection == SCANDIRECTION_UP)? (-(long)dwStepHz):dwStepHz;
				MeasureCorrectCalc();
				return TRUE;
			}
			if (xScanParam == SCANPARAM_SWR){
				if( (xScanTrueIf == SCANTRUEIF_BELOW_SWR_THRESH) && wParam <= SWR_BW_THRESH) {MeasureCorrectCalc(); return TRUE;}
				if( (xScanTrueIf == SCANTRUEIF_ABOVE_SWR_THRESH) && wParam >= SWR_BW_THRESH) {MeasureCorrectCalc(); return TRUE;}
			}
			
			bLastChangeWasDown = (wParam <= wLastParam);
			wLastParam=wParam;
			
			if(wParam < wBestParam) {
				wBestParam = wParam;
				dwBestParam_Hz=g_dwCurrHz;
			}
			
			g_dwCurrHz += (xScanDirection == SCANDIRECTION_DOWN)? (-(long)dwStepHz):dwStepHz;
			if( (g_dwCurrHz < dwScanStopFalseHz) && (xScanDirection == SCANDIRECTION_DOWN) ) { break; } 
			if( (g_dwCurrHz > dwScanStopFalseHz) && (xScanDirection == SCANDIRECTION_UP) ) { break; } 

		} while (1);

		// code reaches this point only on a band edge or global edge, so only best minimum can be a true return.
		// if (and only if) there was a minimum (and hence a lowest minimum), wBestParam < WORD_MAX
		if( (xScanTrueIf == SCANTRUEIF_LOWESTMINIMUM) && (wBestParam < WORD_MAX)){
			g_dwCurrHz=dwBestParam_Hz;
			// if using a proxy, do a true measurement at the min point
			// TODO - for future development, consider SCANPARAM_VzucORVauc as a proxy or not?
			if (! (xScanParam == SCANPARAM_SWR) || (xScanParam == SCANPARAM_MODZ)) MeasureCorrectCalc();
			if(xScanParam == SCANPARAM_SWR) {g_wSwr100=wBestParam;} else {g_wZ10=wBestParam;}		
			return TRUE;
		}
		
		// finally, return false at the stop frequency with a measurement first		
		g_dwCurrHz = dwScanStopFalseHz;
		MeasureCorrectCalc();
		return FALSE;

}