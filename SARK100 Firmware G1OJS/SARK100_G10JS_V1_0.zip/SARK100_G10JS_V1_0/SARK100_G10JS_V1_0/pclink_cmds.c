//*****************************************************************************/
//  This file is a part of the "SARK100 SWR Analyzer firmware"
//
//	Copyright © 2025 Alan Robinson G1OJS Hampshire England G1OJS@yahoo.com with 
//  acknowledgement & thanks to Melchor Varela © 2010, EA4FRB Madrid, Spain 
//	(melchor.varela@gmail.com) for the overall software and ideas.
//  
//  "SARK100 SWR Analyzer firmware" is free software: you can redistribute it
//  and/or modify it under the terms of the GNU General Public License as
//  published by the Free Software Foundation, either version 3 of the License,
//  or (at your option) any later version.
//
//  "SARK100 SWR Analyzer firmware" is distributed in the hope that it will be
//  useful,  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with "SARK100 SWR Analyzer firmware".  If not,
//  see <http://www.gnu.org/licenses/>.
//*****************************************************************************/
//*****************************************************************************/
//
//	PROJECT:	SARK100 SWR Analyzer
// 	FILE NAME: 	pclink_cmds.c
// 	AUTHOR:		G1OJS - Alan Robinson
// 	DESCRIPTION	Refactored (to save memory) commands from original pclink plus new commands
// 	HISTORY
//	NAME   		DATE		REMARKS	
//	AJR			FEB 2025	G1OJS  - creation 
//*****************************************************************************/
#include "pclink_cmds.h"
#include <stdlib.h>
#include "control.h"
#include "UART.h"
//#include "screens.h" not used currently but TODO a more informative display
#include "glb_data.h"
#include "bridge.h"
#include "derive.h"
#include "correctionmodel.h"

static BYTE const bufOk			[] = "\r\nOK\r\n";
static BYTE const bufStart		[] = "\r\nStart\r\n";
static BYTE const bufEnd		[] = "End\r\n";
static BYTE const bufErrFreqNotSet	[] = "\r\nError: freq not set\r\n";
static BYTE const bufErrExpectFreq	[] = "\r\nError: expected freq val\r\n";
static BYTE const bufErrExpectStep	[] = "\r\nError: expected step val\r\n";
static BYTE const bufErrInvalidFreq	[] = "\r\nError: invalid freq\r\n";

//-----------------------------------------------------------------------------
//  Prototypes
//-----------------------------------------------------------------------------
void MeasureCorrectCalc(void);


//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Cmd_On
//  DESCRIPTION:	Process on (enable DDS) command
//	ARGUMENTS: 		none. 
//	RETURNS: 		none.
//-----------------------------------------------------------------------------
void Cmd_On (void)
{
	Set_DDS(g_dwCurrHz);
	UART_CPutString(bufOk);
}
//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Cmd_Off
//  DESCRIPTION:	Process on command
//  ARGUMENTS: 		none.
//  RETURNS:  		none.
//-----------------------------------------------------------------------------
void Cmd_Off (void)
{
	Set_DDS(0);
	UART_CPutString(bufOk);
}
//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Cmd_Freq
//  DESCRIPTION:	Process freq (set frequency) command
//  ARGUMENTS: 		none.
//  RETURNS:		none.
//-----------------------------------------------------------------------------
void Cmd_Freq (void)
{
	WORD dwfreqRequest;
	do {
		dwfreqRequest = getFreqArg(0); if(dwfreqRequest==-1) break;
		g_dwCurrHz=dwfreqRequest;
		UART_CPutString(bufOk);
	} while (FALSE);
}
//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Cmd_Imp
//  DESCRIPTION:	Process imp (impedance) command
//  ARGUMENTS:		none.
//  RETURNS: 		none.
//		Response: corrected parameters {SWR},{R},{X},{Z}
//  	Example: 1.05,52,10,51 
//-----------------------------------------------------------------------------
void Cmd_Imp (void)
{
	MeasureCorrectCalc();
	
	// refactored code but maintains 2dp 0dp 0dp 0dp format
	// for backwards compatibility
	PrintWdToSerial(g_wSwr100, 100);	
	UART_PutChar(',');
	PrintWdToSerial(g_wR10/10, 1);
	UART_PutChar(',');
	PrintWdToSerial(g_wX10/10, 1);
	UART_PutChar(',');
	PrintWdToSerial(g_wZ10/10, 1);	
	
	UART_PutCRLF();
}
//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Cmd_Raw
//  DESCRIPTION: 	Process raw (raw measurement data) command
//					NOTE that individual voltages are no longer used in the bulk
//					of the calculations (converted to ratios just after measurement)
//					but 4 values need to be provided for compatibility with 
//					companion software that expects them via Cmd_Raw
//					Hence, measure Vf and Vr again (uncorrected) and print out
//					Vf_uncorrected, Vf_uncorrected x (Vr/Vf)_corrected, 
//					Va_uncorrected x (Vz/Va)_corrected, Va_uncorrected
//  ARGUMENTS:		none.
// 	RETURNS:	 	none.
//		Response: corrected voltages  Vf, 'Vr' = (Vr/Vf)*Vf, 
//									  'Vz'     = (Vz/Va)*Va, Va
//  	Example: 4000000,165000,31800,1000000 
//-----------------------------------------------------------------------------

void Cmd_Raw (void)
{
	BYTE const *bThousandStr = "000";
	
	WORD Vf=Read_ADC_DDSON(VfPort);
	WORD Va=Read_ADC_DDSON(VaPort);
	
	// TODO is it important to respect the original DDS condition on entry? 
	// if so, how to detect DDS on or off easily ...
	
	MeasureBridgeRatios();
	
	// Print out UNCORRECTED voltages 	
	PrintWdToSerial(Vf ,1);  UART_CPutString(bThousandStr);
	UART_PutChar(',');
	PrintWdToSerial(  ((DWORD)Vf*(DWORD)g_wBridgeRatios[MODGAMMA]) / wUNITY ,1); UART_CPutString(bThousandStr);
	UART_PutChar(',');
	PrintWdToSerial(  ((DWORD)Va*(DWORD)g_wBridgeRatios[MODZ])     / wUNITY ,1); UART_CPutString(bThousandStr);
	UART_PutChar(',');
	PrintWdToSerial(Va ,1);  UART_CPutString(bThousandStr);

	UART_PutCRLF();
}
//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Cmd_Raw_plus
//  DESCRIPTION:	Process raw_plus (raw measurement data verbose) command
//  ARGUMENTS:		none
//  RETURNS: 		none.
//  Response  		Uncorrected voltages, SWR,R,X,|Z| for uncorrected bridge,
//					SWR,R,X,|Z| for corrected bridge
//-----------------------------------------------------------------------------
void Cmd_Raw_plus(void)
{
	BYTE bCorr;

	// Print out frequency in kHz
	PrintWdToSerial(g_dwCurrHz/1000 ,1); UART_PutChar(',');
	
	// Print out UNCORRECTED voltages 	
	PrintWdToSerial(Read_ADC_DDSON(VfPort) ,1); 
	UART_PutChar(',');
	PrintWdToSerial(Read_ADC_DDSON(VrPort) ,1); 
	UART_PutChar(',');
	PrintWdToSerial(Read_ADC_DDSON(VzPort) ,1); 
	UART_PutChar(',');
	PrintWdToSerial(Read_ADC_DDSON(VaPort) ,1); 
	UART_PutChar(',');

	// Print out UNCORRECTED and then CORRECTED SWR,R,X,|Z| 
	// Ommit final comma
	MeasureBridgeRatios();
	for(bCorr=0;bCorr<2;bCorr++){
		if(bCorr) CorrectBridgeRatios();
		Do_SZRX_Calcs(); 	
		PrintWdToSerial(g_wSwr100, 100);	
		UART_PutChar(',');
		PrintWdToSerial(g_wR10, 10);	
		UART_PutChar(',');
		PrintWdToSerial(g_wX10, 10);	
		UART_PutChar(',');
		PrintWdToSerial(g_wZ10, 10);	
		if(!bCorr) UART_PutChar(',');
	}
	
	UART_PutCRLF();	
}
//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Cmd_Scan
//  DESCRIPTION:	Scan through frequencies specified and call appropriate 
//					Cmd routine to display requested outputs
//  ARGUMENTS:    	BYTE bScanMode 0:Impedance params, 1:Raw voltages, 2:Verbose voltages
//  RETURNS:		none.
//-----------------------------------------------------------------------------
void Cmd_Scan (BYTE bScanMode)
{
	DWORD dwEndFreq;
	DWORD dwStepFreq;
	do
	{
		// Get start, end and step frequencies
		g_dwCurrHz 	= getFreqArg(0); 	if(g_dwCurrHz==-1) break;
		dwEndFreq	= getFreqArg(0); 	if(dwEndFreq==-1) break;
		dwStepFreq	= getFreqArg(1); 	if(dwStepFreq==-1) break;										
		UART_CPutString(bufStart);
		// DDS is off by default and turned off after each full measurement
		// but if it's been off a long time smoothing caps are completely discharged, so
		// turn on before first measure and delay for caps to charge
		Set_DDS(g_dwCurrHz);
		Delay_64ths(4);
		// now step through frequencies calling MeasureBridgeRatios via Cmd_x functions
		do
		{
			if (bScanMode == 2) Cmd_Raw_plus();
			if (bScanMode == 1) Cmd_Raw();
			if (bScanMode == 0) Cmd_Imp();
			g_dwCurrHz += dwStepFreq;
		} while (g_dwCurrHz<=dwEndFreq);
		UART_CPutString(bufEnd);
	} while (FALSE);

	Morse_End();
}
//-----------------------------------------------------------------------------
//  FUNCTION NAME:	getFreqArg
//  DESCRIPTION: 	Get frequency argument from command line
//  ARGUMENTS:		bFreqIsStep (true = don't check vs minimum freq)
// 	RETURNS: 		DWORD freq in Hz, -1 if invalid
//-----------------------------------------------------------------------------
DWORD getFreqArg(BYTE bFreqIsStep)
{
	char * strPtr; 						// Parameter pointer
	strPtr = UART_szGetParam();
	if (strPtr==NULL) {					// missing argument
		UART_CPutString((bFreqIsStep)? bufErrExpectStep:bufErrExpectFreq);
		return -1;
	}
	if( (bFreqIsStep==0) && (atol(strPtr)>FREQ_MAX_Hz || atol(strPtr)<FREQ_MIN_Hz) ) {	// bad frequency
		UART_CPutString(bufErrInvalidFreq);
		return -1;
	}
	return atol(strPtr);	// good frequency
}
//-----------------------------------------------------------------------------
//  FUNCTION NAME:	PrintWORDtoSerial(DWORD dwVal)
//  DESCRIPTION: 	Given a number dwVal x wDivisor, prints to serial with appropriate 
//					decimal point 
//  ARGUMENTS:		WORD wVal	Number x100 to print
//  RETURNS: 		none.
//-----------------------------------------------------------------------------
void PrintWdToSerial(WORD wVal, WORD wDivisor)
{
	utoa(g_buffer16, wVal/wDivisor , 10); 
	UART_PutString(g_buffer16);
	if(wDivisor>1){
		UART_PutChar('.');
		utoa(g_buffer16, wVal % wDivisor , 10);
	  	UART_PutString(g_buffer16);
	}
}
