//*****************************************************************************/
//  This file is a part of the "SARK100 SWR Analyzer firmware"
//
//  Copyright © 2010 Melchor Varela - EA4FRB.  All rights reserved.
//  Melchor Varela, Madrid, Spain.
//  melchor.varela@gmail.com
//
//  Modified in 2024 by Alan Robinson G1OJS Hampshire England G1OJS@yahoo.com 
//
//  "SARK100 SWR Analyzer firmware" is free software: you can redistribute it
//  and/or modify it under the terms of the GNU General Public License as
//  published by the Free Software Foundation, either version 3 of the License,
//  or (at your option) any later version.
//
//  "SARK100 SWR Analyzer firmware" is distributed in the hope that it will be
//  useful,  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with "SARK100 SWR Analyzer firmware".  If not,
//  see <http://www.gnu.org/licenses/>.
//*****************************************************************************/
//*****************************************************************************/
//
//	PROJECT:	SARK100 SWR Analyzer
// 	FILE NAME: 	CALCS.C
// 	AUTHOR:		EA4FRB - Melchor Varela
//
// 	DESCRIPTION
//
//	SWR and impedance calculation routines
//
// 	HISTORY
//
//	NAME   		DATE		REMARKS
//
//	MVM	   		DEC 2009	Creation
//
//  G1OJSv1.0	DEC 2024	Revise for memory saving and overflow prevention
//
//*****************************************************************************/

#include <m8c.h>        // part specific constants and macros
#include <math.h>

#include "PSoCAPI.h"
#include "psocgpioint.h"
#include "glb_data.h"
#include "calibrate_reflectometer.h"

//-----------------------------------------------------------------------------
//  Prototypes
//-----------------------------------------------------------------------------
static WORD Calc_Sqrt (DWORD dwN);

//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Calculate_Swr
//
//  DESCRIPTION:
//
//	Calculates SWR based on VF and VR values
//	Notice that wVf value is x2 because it is measured at the bridge input, and
//	wVr is also x2 because the PGA gain is set to double, so both compensates and
//	it is not needed further calculation
//
//	Calculates SWR based on VF and VR values
//
//	SWR = (Vf+Vr/Vf-Vr)*100
//
//	Calculates resistance
//
//                 (2500 + Z^2) * SWR
//      (R x 10) = ------------------
//                  5 * (SWR^2 + 1)
//
//      OR with scaled quantities:
//
//                         (250000 + (Z x 10)^2 ) 
//      (R x 10) =  -------------------------------------
//                   5*(SWR x 100)  +  50000/(SWR x 100)
//
//  Calculates X
//           X = SQRT ( Z^2 - R^2 )
//
//  ARGUMENTS:
//     None
//
//  RETURNS:
//     None
//
//-----------------------------------------------------------------------------
			
void Do_SZRX_Calcs (void)
{
	DWORD dwDenominator;
	DWORD dwNumerator;
	
	if (g_bSgnX=='*') g_bSgnX='?';

    if(g_xBridgeMeasure.Va == 0 || g_xBridgeMeasure.Vr >= g_xBridgeMeasure.Vf)
	{
		g_bSgnX='*';
	}
	else
	{
		// Get SWRx100 from Vf and Vr
		
		dwNumerator = 100*(g_xBridgeMeasure.Vf + g_xBridgeMeasure.Vr); // safe for Vf=4010 & Vr=1
		dwDenominator = g_xBridgeMeasure.Vf - g_xBridgeMeasure.Vr;
		g_wSwr100 = (dwNumerator/dwDenominator);
	
		// Get |Z| from Vz and Va
		g_wZ10 = (500 * g_xBridgeMeasure.Vz) / g_xBridgeMeasure.Va; // safe for Vz=4010 & Va=1
		
		// Get R from |Z| and SWRx100
		dwNumerator 	= 250000+ (DWORD)g_wZ10*g_wZ10;			// DWORD safe to >~ 6000 ohms 
		dwDenominator 	= 5*g_wSwr100 + 50000/g_wSwr100;		// safe for any real-life VSWR
   		g_wR10 = dwNumerator/dwDenominator;
		
		// Get X from R and |Z|
		if(g_wR10 > g_wZ10) 
		{
		  	g_wR10=g_wZ10;
		  	g_wX10=0;
		}
		else
		{
			dwNumerator = (DWORD)g_wZ10*(DWORD)g_wZ10 - (DWORD)g_wR10*(DWORD)g_wR10; // DWORD safe to >~ 5000 ohms 
			g_wX10 = Calc_Sqrt(dwNumerator);
		}
		
	}
	


}

//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Calculate_L
//
//  DESCRIPTION:
//
//	Updates global g_wL10 with 10 x inductance in uH calculated at 
//  current frequency q_dwCurrentFreq Hz
//
//   	L uH 	=	10^6 * X / 2*PI*freq_kHz
//
//   	10*L uH	=	10^6 * (X*10) / 2*PI*freq_kHz
//
//				= 1000
//				  * X*10
//				  / 6282
//				  * 1000
//				  / (fHz/1000)
//
//  ARGUMENTS:
//		uses global values:
//     	g_wX10 (10* X_ohms)
//		g_wCurrentFreq (kHz)
//
//  RETURNS:
//     nothing
//
//-----------------------------------------------------------------------------
void Calculate_L (void)
{
	DWORD tmp;
	tmp 	=	1000 * (DWORD)g_wX10;
	tmp		=	tmp / 6282;
	tmp		=	tmp * 1000;
	g_wL10	=	tmp / ( g_dwCurrHz / 1000 );
	
}

//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Calculate_C
//
//  DESCRIPTION:
//
//	Updates global g_wC10 with 10 x capacitance in pF calculated at 
//  current frequency g_dwCurrHz Hz
//
//           C_pF	 =	10^9/(2*PI*freq_kHz * X_ohms)
//
//           10*C_pF =	100*10^9/(2*PI*freq_kHz * 10*X_ohms)
//
//			 		 = 	10^9 / ( ((freq_Hz/1000) * 10*X_ohms) / 100 ) 
//				   		* 1000	(10*pF, 10* ohms)				
//				   		/6282
//
//				   note 10^9 = DWORD * 0.23
//
//  ARGUMENTS:
//	    uses global values:
//     	g_wX10 (10 x ohms)
//		g_wCurrentFreq (Hz)
//     
//  note DWORD range is 0 to 4294967295 so 1Hz steps to over 4GHz 
//
//  RETURNS:
//     nothing
//
//-----------------------------------------------------------------------------
void Calculate_C (void)
{   
    DWORD tmp;
	tmp	=  	g_dwCurrHz / 1000;
	tmp =   ((DWORD)(tmp * (DWORD)g_wX10)) / 100;
	tmp = 	(DWORD)1000000000 / tmp;
	g_wC10 = (tmp*1000) / 6282;
}

//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Calc_Sqrt
//
//  DESCRIPTION:
//
//	Calculates square root fo integer number
//
//  ARGUMENTS:
//     dwN		Value to calculate
//
//  RETURNS:
//     Square root
//
//-----------------------------------------------------------------------------
static WORD Calc_Sqrt (DWORD dwN)
{

	DWORD dwRem = 0;
	DWORD dwRoot = 0;
	BYTE ii;
	
	if (dwN > 4294836225) { // Maximum DWORD value where sqrt fits in a WORD
    	return 0xFFFF; // Return maximum value for WORD
	}

	for (ii=0;ii<16;ii++)
	{
		dwRoot <<= 1;
		dwRem = ((dwRem<<2)+(dwN>>30));
		dwN <<= 2;
		dwRoot++;
		if (dwRoot<=dwRem)
		{
			dwRem -= dwRoot;
			dwRoot++;
		}
		else
		{
			dwRoot--;
		}
	}
	return (WORD)(dwRoot>>1);
}


