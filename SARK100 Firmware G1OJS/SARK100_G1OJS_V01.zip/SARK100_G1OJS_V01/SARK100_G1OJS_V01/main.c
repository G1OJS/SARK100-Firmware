//*****************************************************************************/
//  This file is a part of the "SARK100 SWR Analyzer firmware"
//
//  Copyright © 2010 Melchor Varela - EA4FRB.  All rights reserved.
//  Melchor Varela, Madrid, Spain.
//  melchor.varela@gmail.com
//
//  Modified in 2024 by Alan Robinson G1OJS Hampshire England G1OJS@yahoo.com 
//
//  "SARK100 SWR Analyzer firmware" is free software: you can redistribute it
//  and/or modify it under the terms of the GNU General Public License as
//  published by the Free Software Foundation, either version 3 of the License,
//  or (at your option) any later version.
//
//  "SARK100 SWR Analyzer firmware" is distributed in the hope that it will be
//  useful,  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with "SARK100 SWR Analyzer firmware".  If not,
//  see <http://www.gnu.org/licenses/>.
//*****************************************************************************/
//*****************************************************************************/
//
//	PROJECT:	SARK100 SWR Analyzer
// 	FILE NAME: 	MAIN.C
// 	AUTHOR:		EA4FRB - Melchor Varela
//
// 	DESCRIPTION
//
//	Main program logic
//
// 	HISTORY
//
//	NAME   		DATE		REMARKS
//
//	MVM	   		DEC 2009	Creation
//
//  G1OJSv1.0	DEC 2024	Functional changes (see release notes)
//							added comments, functions & variable names more descriptive
//							more compact code layout & compact forms
//							
//
//*****************************************************************************/
#include <stdlib.h>
#include <m8c.h>
#include "psocgpioint.h"
#include "PSoCAPI.h"    // PSoC API definitions for all User Modules
#include "Lcd.h"
#include "Util.h"
#include "Display.h"
#include "glb_data.h"
#include "msg_generic.h"
#include "dds.h"
#include "storage.h"
#include "keypad.h"
#include "buzzer.h"
#include "calcs.h"
#include "calibrate_reflectometer.h"
#include "pclink.h"

//-----------------------------------------------------------------------------
//  Defines
//-----------------------------------------------------------------------------
#define DIZZLING_OFFSET_Hz	1000000		//1Mhz
#define TIME_DELAY_TEXT		4			//Temporary screen texts: units of 1 sec
#define SWR_BW_THRESH		200			// SWR threshold for swr BW and match freq scanning

//#define DEBUG	1						// Uncomment to debug measurment results on USB

//-----------------------------------------------------------------------------
//  Prototypes
//-----------------------------------------------------------------------------
static void Mode_Scan (BYTE bBand);
static void Mode_Config (void);
//static void awaken(void);
//static void suspendOps(void);

//-----------------------------------------------------------------------------
//  Private data
//-----------------------------------------------------------------------------
#define MAX_INCREMENT		7

typedef struct
{
	BYTE bCol;
	DWORD dwIncrement;
} INCREMENT_CONTROL;

INCREMENT_CONTROL const gxIncrementControl[MAX_INCREMENT] =
{
	{15, 1},
	{14, 10},
	{13, 100},		// skip decimal point 
	{11, 1000},
	{10, 10000},
	{9, 100000},
	{8, 1000000},
};
//-----------------------------------------------------------------------------
//  FUNCTION NAME:	main
//
//  DESCRIPTION:
//
//	Main program logic
//
//  ARGUMENTS:
//     none.
//
//  RETURNS:
//     none.
//
//-----------------------------------------------------------------------------
void main(void)
{
	BYTE bLowerCalBoundary;
	BYTE bBand;
	DWORD dwSaveFreqBand[BAND_MAX];		// Stores frequency val when switching bands
	BYTE bKey = 0;
	BYTE bUserIdle;
	BYTE bDizzling=FALSE;
	WORD wDizzlingX=0;
	BYTE bIncDigitSelect = FALSE;
	BYTE bIncCtl = 5;					// Cursor position index. Default set to 100Khz

	M8C_ClearWDTAndSleep;		
	M8C_EnableIntMask(INT_MSK0, INT_MSK0_SLEEP);
	M8C_EnableGInt;						
	DISP_Setup();						// Enables display
	Port_2_Data_SHADE |= XO_EN_MASK;	
	XO_EN_Data_ADDR |= XO_EN_MASK;
	
	// Display welcome screen
	LCD_Position(0, 0);  LCD_PrCString(g_welcome1Str);
	LCD_Position(1, 0);  LCD_PrCString(g_welcome2Str);
	KEYPAD_WaitKey(TIME_DELAY_TEXT);

	STR_Restore();						// Load cal and config data from EEPROM
	if (g_bIsCalibrated == FALSE)		// If not calibrated presents warning text
	{
		BUZZ_BeepError();
		DISP_Clear();
		LCD_Position(0, 0); LCD_PrCString(gErrorUncalibratedStr);
		KEYPAD_WaitKey(TIME_DELAY_TEXT);
		DISP_Clear();
	}

    DDS_Init();
	
	for (bBand=0; bBand<BAND_MAX; bBand++)	// Set save band frequency to the center of each band
	{
		dwSaveFreqBand[bBand] = g_xBandLimits[bBand].middle * BAND_FREQ_ToHz;
	}		
	
	bBand = BAND_20M;
	g_dwCurrHz = g_xBandLimits[bBand].middle * BAND_FREQ_ToHz;	// Set current frequency				
	
	PGA_DDS_1_Start(PGA_DDS_1_HIGHPOWER);	// Set DDS gain
	PGA_DDS_2_Start(PGA_DDS_2_HIGHPOWER);
	PGA_DDS_1_SetGain(g_xGainDds[g_bDDS_GainStep].bGain1);
	PGA_DDS_2_SetGain(g_xGainDds[g_bDDS_GainStep].bGain2);	

	ADCINC12_Start(ADCINC12_HIGHPOWER);	 	// Turn on Analog section
	PGA_ADC_Start(PGA_ADC_HIGHPOWER);
	PGA_ADC_SetGain(PGA_ADC_G2_67);
										
	// Check Vf level
	DDS_Set(g_dwCurrHz);					
	Delay_Ms(100);
	Do_Measure();
	if (g_xBridgeMeasure.Vf<500)			// Vf too low, warn user
	{
		BUZZ_BeepError();
		LCD_Position(0, 0);  LCD_PrCString(gErrorAdjustVfStr);
		LCD_Position(1, 0);  LCD_PrCString(gPressAnyKeyStr);			
		KEYPAD_WaitKey(TIME_WAIT_KEY_S);	// Wait key press
		DISP_Clear();
	}
		
	g_bSgnX='?';
	g_bIdleCounter = GetUserIdle(g_xConf.bUserIdle);	// Initial set Idle counter
	do
	{													// Start main loop
		// Measure and display according to mode
		if (!((bKey==KBD_2xUP)||(bKey==KBD_2xDWN))) // Long press UP or DWN -> fast change mode -> don't measure/display -> goes faster
		{
			if (g_bSgnX=='*') g_bSgnX=' ';  // just came out of fast freq change, so disable the blanking of numbers
			if (g_bMode != MODE_SIG)
			{
				SetMeasureCalcDisplay(0); // also handles calculation and display for IMP/CAP/IND screens
			//	BUZZ_KeyClick();
				if(g_bMode == MODE_IMPD)
				{
					if (bDizzling == FALSE)
					{	bDizzling = TRUE; wDizzlingX = g_wX10; // remember current reactance
					} else {
						bDizzling = FALSE; DDS_Set(g_dwCurrHz + DIZZLING_OFFSET_Hz); 
						Do_SZRX_Calcs();
						if ( (g_wX10-wDizzlingX) > 5 || (g_wX10==0) ) 
							{g_bSgnX = '+';}
						else if ( (wDizzlingX-g_wX10) > 5) 
							{g_bSgnX = '-';}
					}
				}
				if(g_bMode == MODE_IMPN) g_bSgnX='#';
				SetMeasureCalcDisplay(2);
			}
		} 
		else		
		{	// Fast freq change - update frequency display every time
			g_bSgnX='*'; // '*' used as a flag to ultoSpecial to replace all numbers with *
			SetMeasureCalcDisplay(2); // just updates frequency display		
		}
	
		if(g_bMode == MODE_SIG) {
			Do_MeasureRfLevel();
			SetMeasureCalcDisplay(2);
		} 

		if(g_bMode != MODE_SIG)
		{	// Display cursor
			LCD_Position(0, gxIncrementControl[bIncCtl].bCol);  
			if (bIncDigitSelect) {LCD_Control(LCD_ON_BLINK);} else {LCD_Control(LCD_ON_CURSOR);}
		}
		
		g_bMeasureCounter = MEASURE_PERIOD;		// Waits for key or time for new measurement
		do
		{
			M8C_Sleep;
			bKey = KEYPAD_Get();
			if(bKey==KBD_CONFIG || 	bKey==KBD_BAND) dwSaveFreqBand[bBand]=g_dwCurrHz;	// Saves frequency
			switch ( bKey )
			{
				case KBD_CONFIG:
					DDS_Set(0);		// Disables DDS to save power
					LCD_Control(LCD_ON);
					Mode_Config();
					DISP_Clear();	//  ensures no text from previous mode hanging over
					break;
				
				case KBD_MODE:
				   	LCD_Position(0, 0); LCD_PrCString(gBlankStr_16); // clear top row of display
					LCD_Control(LCD_ON);
					if (g_bMode==MODE_SIG)
					{				// Resume from SIG mode
						PGA_DDS_1_Start(PGA_DDS_1_HIGHPOWER);
						PGA_DDS_2_Start(PGA_DDS_2_HIGHPOWER);
						DDS_Set(g_dwCurrHz);
					}
					if (++g_bMode >= MODE_MAX) g_bMode = MODE_IMPD;
							
					if (g_bMode==MODE_SIG)
					{				// Enter SIG mode
						DDS_Set(0);
						PGA_DDS_1_Stop();
						PGA_DDS_2_Stop();
					}
					DISP_Clear();	//  ensures no text from previous mode hanging over
					break;

				case KBD_BAND:
					if (g_bMode == MODE_SIG) break;
					dwSaveFreqBand[bBand] = g_dwCurrHz;	// Saves current freq
					if (++bBand >= BAND_MAX)
					{   
					    BUZZ_Beep();
						bBand = BAND_160M;
					}
					break;

				case KBD_SCAN:
					if (g_bMode == MODE_SIG) break;
					LCD_Control(LCD_ON);
					Mode_Scan(bBand);
					break;

				case KBD_UP_DWN:							// UP and DOWN pressed together
					if (g_bMode == MODE_SIG) break;
					bIncDigitSelect	=	~bIncDigitSelect;	// Toggle between cursor or frequency change modes
					break;

				case KBD_2xUP:								// UP key held down, fall through to KBD_UP
				case KBD_UP:
					if (g_bMode == MODE_SIG) break;
					if (bIncDigitSelect)
					{
						if (++bIncCtl >= MAX_INCREMENT) bIncCtl = 0; 	// Move frequency cursor & cycle back to 0
						break;
					}			
					if(g_dwCurrHz + gxIncrementControl[bIncCtl].dwIncrement <= g_xBandLimits[bBand].high * BAND_FREQ_ToHz)
						g_dwCurrHz += gxIncrementControl[bIncCtl].dwIncrement;  // Increases frequency
					break;	

				case KBD_2xDWN:								// DOWN key held down, fall through to KBD_DWN	
				case KBD_DWN:
					if (g_bMode == MODE_SIG) break;
					if (bIncDigitSelect)	
					{
						if (--bIncCtl <0) bIncCtl =  MAX_INCREMENT-1; 	// Move frequency cursor & cycle back to 0
						break;
					}
					if(g_dwCurrHz - gxIncrementControl[bIncCtl].dwIncrement >= g_xBandLimits[bBand].low * BAND_FREQ_ToHz)
						g_dwCurrHz -= gxIncrementControl[bIncCtl].dwIncrement; 	// Decreases frequency
					break;
			}
			if(bKey==KBD_CONFIG || 	bKey==KBD_BAND) g_dwCurrHz = dwSaveFreqBand[bBand];	// Restores frequency
		} while ((bKey==0) && (g_bMeasureCounter>0));
	
		// If key was pressed, reset user Idle timer
		if (bKey != 0) g_bIdleCounter = GetUserIdle(g_xConf.bUserIdle);

		// Enter and Exit Idle mode							
		if ((g_bIdleCounter==0) && (GetUserIdle(g_xConf.bUserIdle) != 0))
		{				
			DDS_Set(0);				// DDS power down
			XO_EN_Data_ADDR &= ~XO_EN_MASK;
			Port_2_Data_SHADE &= ~XO_EN_MASK;
			PGA_DDS_1_Stop();
			PGA_DDS_2_Stop();
			ADCINC12_Stop();
			PGA_ADC_Stop();
			LCD_Init();
			LCD_Control(LCD_OFF);	// Display off	

			KEYPAD_SysSuspendAndWakeFromPress();
			
			LCD_Control(LCD_ON_CURSOR);
			XO_EN_Data_ADDR |= XO_EN_MASK;
			Port_2_Data_SHADE |= XO_EN_MASK;
			Delay_Ms(10);
			XO_EN_Data_ADDR &= ~XO_EN_MASK;
			Port_2_Data_SHADE &= ~XO_EN_MASK;
			Delay_Ms(10);
			XO_EN_Data_ADDR |= XO_EN_MASK;
			Port_2_Data_SHADE |= XO_EN_MASK;
			Delay_Ms(10);
			
			DDS_Init();
			g_bIdleCounter = GetUserIdle(g_xConf.bUserIdle);
			if (g_bMode != MODE_SIG)
			{
				DDS_Set(g_dwCurrHz);
				PGA_DDS_1_Start(PGA_DDS_1_HIGHPOWER);
				PGA_DDS_2_Start(PGA_DDS_2_HIGHPOWER);
			}
			ADCINC12_Start(ADCINC12_HIGHPOWER); // Turn on Analog section
			PGA_ADC_Start(PGA_ADC_HIGHPOWER);
		}
		
	} while (TRUE);
}

//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Mode_Scan
//
//  DESCRIPTION:
//
//	Scanning routine
//
//  ARGUMENTS:
//  	bBand	Integer describing band number
//
//  RETURNS:
//     Nothing
//
//-----------------------------------------------------------------------------
static void Mode_Scan (BYTE bBand)
{

	typedef struct							// SCAN_RES definition
	{
		WORD wMinSwr100;
		WORD wMinSwrFreq_kHz;
		WORD wLowFreq_kHz;
		WORD wHighFreq_kHz;	
	} SCAN_RES;

	SCAN_RES xScanResults;
	BYTE bScanStepkHz=250;
	g_bScanning = TRUE;

	do{	// repeat the scan algorithm at smaller step if necessary
	
		BYTE bFlagLocalMinimum=0;
		BYTE bFlagFirstBeep=1;
		xScanResults.wLowFreq_kHz=(g_xBandLimits[bBand].low * BAND_FREQ_ToHz)/1000;  			// set f_low result in case we start the scan below SWR_BW_THRESH
		xScanResults.wHighFreq_kHz=(g_xBandLimits[bBand].high * BAND_FREQ_ToHz)/1000;   		// set f_low result in case we end the scan below SWR_BW_THRESH
		g_dwCurrHz = g_xBandLimits[bBand].low * BAND_FREQ_ToHz;	// set freq to lower band edge
		xScanResults.wMinSwr100 = SWR_BW_THRESH; 				// set min SWR tracker to threshold

		SetMeasureCalcDisplay(0);								// get starting SWR
		do 														// scan the whole band
		{	
    	 	SetMeasureCalcDisplay(0); // measure SWR
		
			if(bFlagFirstBeep && (g_wSwr100 <= SWR_BW_THRESH))
			{							// Beep to indicate 'looks promising'!
				BUZZ_Beep();
				bFlagFirstBeep=0;
			}
		
			// keep track of most recent local minimum SWR seen, and frequency seen at
			if(g_wSwr100 < xScanResults.wMinSwr100) 
			{ 
				xScanResults.wMinSwr100=g_wSwr100;
				xScanResults.wMinSwrFreq_kHz = g_dwCurrHz/1000;
				bFlagLocalMinimum=1; // this might be the global minimum, so the next SWR>THRESH is worth remembering
	   	  	}
		
			// if SWR now going up from below threshold, and we cross the threshold or reach the band edge, 
			// then remember freq as Fhigh and reset the local minimum flag (in case we find another, lower, local min) 
 			if( bFlagLocalMinimum
				&& (g_wSwr100 >= SWR_BW_THRESH || (g_dwCurrHz + ((DWORD)bScanStepkHz)*1000 >= g_xBandLimits[bBand].high * BAND_FREQ_ToHz) ) )
		//	if( (g_wSwr100 >= SWR_BW_THRESH || (g_dwCurrHz + ((DWORD)bScanStepkHz)*1000 >= g_xBandLimits[bBand].high * BAND_FREQ_ToHz) ) )
			{
				xScanResults.wHighFreq_kHz=g_dwCurrHz/1000;
				bFlagLocalMinimum=0;  // in case we find another minimum (we want the low -> high after it)
			}
			
			g_dwCurrHz += ((DWORD)bScanStepkHz)*1000;		// next freq
		
		} while (g_dwCurrHz < g_xBandLimits[bBand].high * BAND_FREQ_ToHz);

		if (bScanStepkHz == 1) break;
		bScanStepkHz /=4;
	
		if(xScanResults.wMinSwr100 >=SWR_BW_THRESH)			// no match found - give opportunity to scan again at a finer step
		{
			BUZZ_Beep();
			LCD_Position(0, 0); LCD_PrCString(gBlankStr_16);
			LCD_Position(0, 0); LCD_PrCString(gErrNoMatchingStr);
   			LCD_Position(1, 0); LCD_PrCString(gErrNoMatchContinueStr);
			if (KEYPAD_WaitKey(TIME_WAIT_KEY_S) != KBD_DWN) break;
		}
	
	} while (xScanResults.wMinSwr100 >= SWR_BW_THRESH);
	
	// if a match was found, search downwards from the global minimum to find the closest freq at which SWR goes above threshold
    if(xScanResults.wMinSwr100 < SWR_BW_THRESH)
	{		
		BUZZ_Beep(); // match found
		g_dwCurrHz=1000*(DWORD)xScanResults.wMinSwrFreq_kHz;		// set freq to match freq
		do 
		{												
			g_dwCurrHz -= ((DWORD)bScanStepkHz)*1000;				// next freq down
     		SetMeasureCalcDisplay(0);								// measure SWR
		} 
		while ((g_dwCurrHz > g_xBandLimits[bBand].low * BAND_FREQ_ToHz) && (g_wSwr100 < SWR_BW_THRESH)) ;
		xScanResults.wLowFreq_kHz=g_dwCurrHz/1000;
	
		// Display results & set g_dwCurrHz to min swr freq
		g_dwCurrHz=1000*((DWORD)xScanResults.wMinSwrFreq_kHz);
		SetMeasureCalcDisplay(0);
		LCD_Position(1, 0); LCD_PrCString(gBlankStr_16);
		LCD_Position(1, 0); LCD_PrCString(gBandWidthStr);
		ultoa(g_buffer16, (DWORD)xScanResults.wHighFreq_kHz - (DWORD)xScanResults.wLowFreq_kHz	, 10);
		LCD_PrString(g_buffer16);
	}

	DDS_Set(0);
	KEYPAD_WaitKey(TIME_WAIT_KEY_S);
	g_bScanning = FALSE;

}

//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Mode_Config
//
//  DESCRIPTION:
//
//	Configuration routine
//
//  ARGUMENTS:
//     none.
//
//  RETURNS:
//     none.
//
//-----------------------------------------------------------------------------
static void Mode_Config (void)
{
	BYTE bMenu = 0;
	BYTE bKey;
	BYTE bStep;
	BYTE bDDS;
	BYTE bUserIdle;
	DISP_Clear(); LCD_Position(0, 0); LCD_PrCString(gConfigStr[bMenu]);
	
	do  {		// Main configuration menu		
		

		bKey = KEYPAD_WaitKey(TIME_WAIT_KEY_S);
		if ((bKey==0) || (bKey==KBD_UP)) break;
		if (bKey==KBD_CONFIG) {if (++bMenu>=CONFIG_MAX) bMenu = 0;}
		DISP_Clear(); LCD_Position(0, 0); LCD_PrCString(gConfigStr[bMenu]);
		
		if (bKey==KBD_DWN) switch (bMenu)
			{
				case CONFIG_PCLINK:
					PcLink();
					break;

				case CONFIG_Idle:
					bUserIdle = g_xConf.bUserIdle;
					do
					{	LCD_Position(1, 0); LCD_PrCString(gIdleStr[bUserIdle]);
						bKey = KEYPAD_WaitKey(TIME_WAIT_KEY_S);
						if (bKey==KBD_CONFIG) {if (++bUserIdle>=USER_IDLE_MAX) bUserIdle = 0;}
						if (bKey==KBD_UP) break;
				 		if (bKey==KBD_DWN){
							g_xConf.bUserIdle = bUserIdle;
							STR_SaveConfig();
							LCD_Position(1, 0); LCD_PrCString(gValueSavedStr);
							KEYPAD_WaitKey(TIME_DELAY_TEXT);
							break;}
					} while(TRUE);
					break;

				case CONFIG_CALIB:
					LCD_Position(1, 0); LCD_PrCString(gConfirmStr); 
					if( KEYPAD_WaitKey(TIME_WAIT_KEY_S) == KBD_UP) break;
					Calibrate_Reflectometer();			
					M8C_DisableGInt;
					asm ("ljmp 0x0000"); // Perform Software Reset

				case CONFIG_SW_LOAD:
					LCD_Position(1, 0); LCD_PrCString(gConfirmStr);
					if( KEYPAD_WaitKey(TIME_WAIT_KEY_S) == KBD_UP) break;
					DISP_Clear(); LCD_Position(0, 0); LCD_PrCString(gSwLoadingStr);
					M8C_DisableGInt;
					asm ("ljmp 0x0000"); 	// Perform Software Reset
			}
	} while (TRUE);
}


/*
static void suspendOps(void)
{
	DDS_Set(0);				// DDS power down
	XO_EN_Data_ADDR &= ~XO_EN_MASK;
	Port_2_Data_SHADE &= ~XO_EN_MASK;
	PGA_DDS_1_Stop();
	PGA_DDS_2_Stop();
	ADCINC12_Stop();
	PGA_ADC_Stop();
	LCD_Init();
	LCD_Control(LCD_OFF);	// Display off
}

static void awaken(void)
{

 	LCD_Control(LCD_ON);
	Port_2_Data_SHADE |= XO_EN_MASK;
	XO_EN_Data_ADDR |= XO_EN_MASK;
	Delay_Ms(10);
	XO_EN_Data_ADDR &= ~XO_EN_MASK;
	Port_2_Data_SHADE &= ~XO_EN_MASK;
	Delay_Ms(10);
	XO_EN_Data_ADDR |= XO_EN_MASK;
	Port_2_Data_SHADE |= XO_EN_MASK;
	Delay_Ms(10);

	DDS_Init();
	g_bIdleCounter = GetUserIdle(g_xConf.bUserIdle);

	ADCINC12_Start(ADCINC12_HIGHPOWER);	 	
	PGA_ADC_Start(PGA_ADC_HIGHPOWER);
	PGA_ADC_SetGain(PGA_ADC_G2_67);
	
}
*/