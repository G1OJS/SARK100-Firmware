//*****************************************************************************/
//  This file is a part of the "SARK100 SWR Analyzer firmware"
//
//  Copyright © 2010 Melchor Varela - EA4FRB.  All rights reserved.
//  Melchor Varela, Madrid, Spain.
//  melchor.varela@gmail.com
//
//  Modified in 2024 by Alan Robinson G1OJS Hampshire England G1OJS@yahoo.com 
//
//  "SARK100 SWR Analyzer firmware" is free software: you can redistribute it
//  and/or modify it under the terms of the GNU General Public License as
//  published by the Free Software Foundation, either version 3 of the License,
//  or (at your option) any later version.
//
//  "SARK100 SWR Analyzer firmware" is distributed in the hope that it will be
//  useful,  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with "SARK100 SWR Analyzer firmware".  If not,
//  see <http://www.gnu.org/licenses/>.
//*****************************************************************************/
//*****************************************************************************/
//
//	PROJECT:	SARK100 SWR Analyzer
// 	FILE NAME: 	CALIBRATE_REFRECTOMETER.C
// 	AUTHOR:		EA4FRB - Melchor Varela
//
// 	DESCRIPTION
//
//	Calibration routines
//
// 	HISTORY
//
//	NAME   		DATE		REMARKS
//
//	MVM	   		DEC 2009	Creation
//
//  G1OJSv1.0	DEC 2024	New calibration routines and interpolation function
//							Refactoring incl SetMeasureCalcDisplay also used by main
//
//*****************************************************************************/

#include <m8c.h>        				// Part specific constants and macros
#include "PSoCAPI.h"
#include "Lcd.h"

#include "dds.h"
#include "util.h"
#include "glb_data.h"
#include "keypad.h"
#include "msg_generic.h"
#include "buzzer.h"
#include "storage.h"
#include "display.h"
#include "calibrate_reflectometer.h"
#include "calcs.h"


//-----------------------------------------------------------------------------
//  Typedefs
//-----------------------------------------------------------------------------
typedef struct							// Two-point calibration vector
{
	WORD wX0;
	WORD wX1;
	WORD wY0;
	WORD wY1;
} CALIB_VECTOR;

//-----------------------------------------------------------------------------
//  Defines
//-----------------------------------------------------------------------------
#define SLOPE_PRECIS_FACTR	2500		// For precision of calcs involving slope
#define VF_REFERENCE_LEVEL	3900		// Full scale value
#define SWR_274_LOAD		548			// Expected SWR at 274-ohm load
#define SWR_150_LOAD		300			// Expected SWR at 150-ohm load
#define WAIT_TIME_MEASURE	500			// Estabilizing time for measurement (ms)

//#define ReZero(wVal, wVal) (   (wVal > wZero) ? (wVal - wZero) : 0   )

//-----------------------------------------------------------------------------
//  Prototypes
//-----------------------------------------------------------------------------
static void Calc_Correct (CORRECT_DATA *pxCorr, CALIB_VECTOR *pxVect);
static WORD Correct_Measure(CORRECT_DATA *pxCorr, WORD wX);
static BOOL WaitLoadUser (const char *pszText);
static INT iInterpolate(BYTE alpha, INT iV1, INT iV2);
BYTE GetLowerCalBoundary(void);
static WORD ReZero(WORD wVal, WORD wZero);
static DWORD dwGetCalFreqHz(BYTE bLowerCalBoundary);

//-----------------------------------------------------------------------------
//  Private data
//-----------------------------------------------------------------------------
static CALIB_VECTOR xCalVz[CAL_MAX];
static CALIB_VECTOR xCalVr[CAL_MAX];
static CALIB_VECTOR xCalVa1[CAL_MAX];
static CALIB_VECTOR xCalVa2[CAL_MAX];

//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Calibrate_Reflectometer()
//
//  DESCRIPTION:
//
//	Calibration routine
//
//  ARGUMENTS:
//     none.
//
//  RETURNS:
//     none.
//
//-----------------------------------------------------------------------------
void Calibrate_Reflectometer (void)
{
	BYTE bLowerCalBoundary;
	BYTE g_bDDS_GainStep;

	do
	{
		LCD_Control(LCD_CLEAR);
		
		// Find DDS Gain step needed for reasonable Vf 
		LCD_Position(1, 0); LCD_PrCString(gSettingGainStr);
		if (!WaitLoadUser(gOpenLoadStr))
			break;
  		LCD_Position(1, 0); LCD_PrCString(gSettingGainStr);
		g_dwCurrHz=FREQ_MIN_Hz;
		DDS_Set(g_dwCurrHz);
		DISP_Frequency();
		for (g_bDDS_GainStep=0;g_bDDS_GainStep<GAIN_SETTINGS_MAX;g_bDDS_GainStep++)
		{
			PGA_DDS_1_SetGain(g_xGainDds[g_bDDS_GainStep].bGain1);
			PGA_DDS_2_SetGain(g_xGainDds[g_bDDS_GainStep].bGain2);
			Delay_Ms(100);
			Do_Measure();
			if ( (g_xBridgeMeasure.Vf >= VF_REFERENCE_LEVEL) || (g_bDDS_GainStep==(GAIN_SETTINGS_MAX-1) ) ) break;
		}

		// Get zero offset of Va from the open circuit case
		LCD_Position(1, 0); LCD_PrCString(gGettingOffsetsStr);
		for (bLowerCalBoundary=0; bLowerCalBoundary<CAL_MAX;bLowerCalBoundary++)
		{
			g_dwCurrHz=dwGetCalFreqHz(bLowerCalBoundary);
			SetMeasureCalcDisplay(1);
			g_xCalSettings[bLowerCalBoundary].wVaZero = g_xBridgeMeasure.Va;	
        }


		// Get zero offset of Vz from the short circuit case
		if (!WaitLoadUser(gShortLoadStr))
			break;
			
		LCD_Position(1, 0); LCD_PrCString(gGettingOffsetsStr);
		for (bLowerCalBoundary=0; bLowerCalBoundary<CAL_MAX;bLowerCalBoundary++)
		{
			g_dwCurrHz=dwGetCalFreqHz(bLowerCalBoundary);
			SetMeasureCalcDisplay(1);
			g_xCalSettings[bLowerCalBoundary].wVzZero = g_xBridgeMeasure.Vz;			
        }
		
		// now characterise the response of the bridge
		LCD_Control(LCD_CLEAR);
		
        // Get cal data for Vz and Va to be 1/2 Vf (using 50-ohm load)
		// Also get Vr zeros
		if (!WaitLoadUser(g50OhmLoadStr))
			break;
		LCD_Position(1, 0); LCD_PrCString(gCalibratingStr);
		for (bLowerCalBoundary=0; bLowerCalBoundary<CAL_MAX;bLowerCalBoundary++)
		{
			g_dwCurrHz=dwGetCalFreqHz(bLowerCalBoundary);
			SetMeasureCalcDisplay(1);
			xCalVz[bLowerCalBoundary].wX0 = ReZero(g_xBridgeMeasure.Vz, g_xCalSettings[bLowerCalBoundary].wVzZero);
			xCalVz[bLowerCalBoundary].wY0 = (g_xBridgeMeasure.Vf*VOLTG_RESOLUTION_FACTR) / (2*xCalVz[bLowerCalBoundary].wX0);
			xCalVa1[bLowerCalBoundary].wX0 = ReZero(g_xBridgeMeasure.Va, g_xCalSettings[bLowerCalBoundary].wVaZero);
			xCalVa1[bLowerCalBoundary].wY0 = (g_xBridgeMeasure.Vf*VOLTG_RESOLUTION_FACTR) / (2*xCalVa1[bLowerCalBoundary].wX0);
        }

        // Get cal data for Vz to be 3/4 Vf and Va to be 1/4 Vf (using 150-ohm load)
		// Get cal data for Vr --> SWR:300
		if (!WaitLoadUser(g150OhmLoadStr))
			break;
		LCD_Position(1, 0); LCD_PrCString(gCalibratingStr);
		for (bLowerCalBoundary=0; bLowerCalBoundary<CAL_MAX;bLowerCalBoundary++)
		{
			g_dwCurrHz=dwGetCalFreqHz(bLowerCalBoundary);
			SetMeasureCalcDisplay(1);
			xCalVz[bLowerCalBoundary].wX1 = ReZero(g_xBridgeMeasure.Vz, g_xCalSettings[bLowerCalBoundary].wVzZero);
			xCalVz[bLowerCalBoundary].wY1 = (g_xBridgeMeasure.Vf*VOLTG_RESOLUTION_FACTR*3)/(4*xCalVz[bLowerCalBoundary].wX1);

			xCalVa1[bLowerCalBoundary].wX1 = ReZero(g_xBridgeMeasure.Va, g_xCalSettings[bLowerCalBoundary].wVaZero);
			xCalVa1[bLowerCalBoundary].wY1 = (g_xBridgeMeasure.Vf*VOLTG_RESOLUTION_FACTR)/(4*xCalVa1[bLowerCalBoundary].wX1);
			g_xCalSettings[bLowerCalBoundary].wVaCutover=xCalVa1[bLowerCalBoundary].wX1;

			xCalVa2[bLowerCalBoundary].wX0 = xCalVa1[bLowerCalBoundary].wX1;
			xCalVa2[bLowerCalBoundary].wY0 = xCalVa1[bLowerCalBoundary].wY1;
	
			xCalVr[bLowerCalBoundary].wX0 = g_xBridgeMeasure.Vr;
			xCalVr[bLowerCalBoundary].wY0 = ((SWR_150_LOAD-100)*g_xBridgeMeasure.Vf*VOLTG_RESOLUTION_FACTR) / ((SWR_150_LOAD+100)*g_xBridgeMeasure.Vr);
        }
 		
		// Get cal data for Vr to get a SWR of 548 (using 274-ohm load)
		if (!WaitLoadUser(g274OhmLoadStr))
			break;
		LCD_Position(1, 0); LCD_PrCString(gCalibratingStr);
		for (bLowerCalBoundary=0; bLowerCalBoundary<CAL_MAX;bLowerCalBoundary++)
		{
			g_dwCurrHz=dwGetCalFreqHz(bLowerCalBoundary);
			SetMeasureCalcDisplay(1);
			xCalVa2[bLowerCalBoundary].wX1 = ReZero(g_xBridgeMeasure.Va, g_xCalSettings[bLowerCalBoundary].wVaZero);
			xCalVa2[bLowerCalBoundary].wY1 = ((DWORD)g_xBridgeMeasure.Vf*VOLTG_RESOLUTION_FACTR*25) / ((DWORD)162*xCalVa2[bLowerCalBoundary].wX1);
			
			xCalVr[bLowerCalBoundary].wX1 = g_xBridgeMeasure.Vr;
			xCalVr[bLowerCalBoundary].wY1 = ((SWR_274_LOAD-100)*g_xBridgeMeasure.Vf*VOLTG_RESOLUTION_FACTR) / ((SWR_274_LOAD+100)*g_xBridgeMeasure.Vr);
			
		}

		// Convert cal data to slope and offset								
		for (bLowerCalBoundary=0; bLowerCalBoundary<CAL_MAX-1; bLowerCalBoundary++)
		{
			Calc_Correct(&g_xCalSettings[bLowerCalBoundary].xVz, &xCalVz[bLowerCalBoundary]);
			Calc_Correct(&g_xCalSettings[bLowerCalBoundary].xVa1, &xCalVa1[bLowerCalBoundary]);
			Calc_Correct(&g_xCalSettings[bLowerCalBoundary].xVa2, &xCalVa2[bLowerCalBoundary]);
			Calc_Correct(&g_xCalSettings[bLowerCalBoundary].xVr, &xCalVr[bLowerCalBoundary]);
		}

		// Store slope and offset and gain step in EEPROM
		g_bIsCalibrated = TRUE;
		STR_SaveCalibration();
		
		// Finish, alert user
		LCD_Control(LCD_CLEAR);
		LCD_Position(0, 0);
		LCD_PrCString(gConfigDoCalStr);
		LCD_Position(1, 0);
		LCD_PrCString(gDoneRestartingStr);
		BUZZ_Beep();
		Delay_Ms(1000);
	}
	while (FALSE);

}

static DWORD dwGetCalFreqHz(BYTE bLowerCalBoundary)
{
	DWORD dwCalFreqHz=0;

//	// Set the freq at the middle of the frequency segment (g_wCalBoundaries[bLowerCalBoundary] to g_wCalBoundaries[bLowerCalBoundary+1])
//	dwCalFreqHz=( (DWORD)g_wCalBoundaries[bLowerCalBoundary]* BAND_FREQ_ToHz + (DWORD)g_wCalBoundaries[bLowerCalBoundary+1]* BAND_FREQ_ToHz ) / 2;
	dwCalFreqHz= (DWORD)g_wCalBoundaries[bLowerCalBoundary]* BAND_FREQ_ToHz;
		
	return dwCalFreqHz;
}


static WORD ReZero(WORD wVal, WORD wZero)
{
  return (wVal > wZero) ? (wVal - wZero) : 0;
}

//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Do_Correct()
//
//  DESCRIPTION:
//
//	Do the complete adjustment of the measurement based on two-point calibration data
//
//  ARGUMENTS:
//  	none
//
//  RETURNS:
//     none.
//
//-----------------------------------------------------------------------------
void Do_Correct (void)
{
	BYTE bLowerCalBoundary;
	bLowerCalBoundary=GetLowerCalBoundary(); // move this out to calling point so it's not done unnecessarily
	
    g_xBridgeMeasure.Vz = ReZero(g_xBridgeMeasure.Vz, g_xCalSetting.wVzZero);
    g_xBridgeMeasure.Va = ReZero(g_xBridgeMeasure.Va, g_xCalSetting.wVaZero);
	
	g_xBridgeMeasure.Vf *= VOLTG_RESOLUTION_FACTR;
	
	g_xBridgeMeasure.Vr *= Correct_Measure(&g_xCalSetting.xVr, g_xBridgeMeasure.Vr);
	
	g_xBridgeMeasure.Vz *= Correct_Measure(&g_xCalSetting.xVz, g_xBridgeMeasure.Vz);
	
	if(g_xBridgeMeasure.Va > g_xCalSettings[bLowerCalBoundary].wVaCutover){
		g_xBridgeMeasure.Va *= Correct_Measure(&g_xCalSetting.xVa1, g_xBridgeMeasure.Va);
	} else {
		g_xBridgeMeasure.Va *= Correct_Measure(&g_xCalSetting.xVa2, g_xBridgeMeasure.Va);
	}
}


//-----------------------------------------------------------------------------
//  FUNCTION NAME:	SetMeasureCalcDisplay(bFlag)
//
//  DESCRIPTION:
//
//	Set the DDS frequency, display it on the LCD, wait for settle and measure
//
//  ARGUMENTS:
//  	bFlag:
//		0 - do all functions
//		1 - don't correct, don't do calcs & don't update display of anything except frequency (used for calibration)
//		2 - display only (used for clearing displayed values and SIG mode display)
//
//  RETURNS:
//     none.
//
//-----------------------------------------------------------------------------
void SetMeasureCalcDisplay(BYTE bFlag)
{
	if(bFlag!=2)
	{
		DDS_Set(g_dwCurrHz);
		setBridgeCorrect();
		Delay_Ms(100);
		Do_Measure();
	}
	
	if(g_bMode!=MODE_SIG) DISP_Frequency();	
	
	if(bFlag!=1) 
	{
		if(bFlag!=2) 
		{
			Do_Correct();
			Do_SZRX_Calcs();
			if(g_bMode==MODE_CAP) Calculate_C();
			if(g_bMode==MODE_IND) Calculate_L();
		}
		if(g_bMode==MODE_IMPD || g_bMode==MODE_IMPN) DISP_SRXZ();
		if(g_bMode==MODE_CAP) DISP_Capacitance();
		if(g_bMode==MODE_IND) DISP_Inductance();
		if(g_bMode==MODE_SIG) {
			LCD_Position(0, 0);
			LCD_PrCString(gModeStr[MODE_SIG]);
			LCD_DrawBG(1, 0, 16, (g_xBridgeMeasure.Vz*80)/4000);
		}
	}	
}
//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Correct_Measure()
//
//  DESCRIPTION:
//
//	Corrects measurement: y=mx+b
//
//  ARGUMENTS:
//  	pxCorr	Correction data (slope and offset)
//		wX		Data to correct
//
//  RETURNS:
//     none.
//
//-----------------------------------------------------------------------------
static WORD Correct_Measure(CORRECT_DATA *pxCorr, WORD wX)
{
	return (((LONG)pxCorr->iSlope*(LONG)wX)/SLOPE_PRECIS_FACTR)+pxCorr->iOffset;
}

//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Calc_Correct()
//
//  DESCRIPTION:
//
//	Converts two-point calibration vector to slope and offset
//
//  ARGUMENTS:
//  	pxCorr	Correction data (slope and offset)
//		pxVect	Calibration vector
//
//  RETURNS:
//     none.
//
//-----------------------------------------------------------------------------
static void Calc_Correct (CORRECT_DATA *pxCorr, CALIB_VECTOR *pxVect)
{
	LONG lTmp;
	lTmp = (LONG)pxVect->wY1-(LONG)pxVect->wY0;
	lTmp *= (LONG)SLOPE_PRECIS_FACTR;
	pxCorr->iSlope = lTmp/((LONG)pxVect->wX1-(LONG)pxVect->wX0);
	pxCorr->iOffset = (LONG)pxVect->wY1-((LONG)((LONG)pxCorr->iSlope*pxVect->wX1)/(LONG)SLOPE_PRECIS_FACTR);
}

//-----------------------------------------------------------------------------
//  FUNCTION NAME:	WaitLoadUser()
//
//  DESCRIPTION:
//
//	Wait for load and user action
//
//  ARGUMENTS:
//  	pszText	Text in display
//
//  RETURNS:
//     FALSE user abort
//
//-----------------------------------------------------------------------------
static BOOL WaitLoadUser (const char *pszText)
{
	LCD_Position(1, 0); LCD_PrCString(gBlankStr_16);
	LCD_Position(1, 0); LCD_PrCString(pszText);
	BUZZ_Beep();
	if ( KEYPAD_WaitKey(TIME_WAIT_KEY_S) == KBD_UP )
		return FALSE;
	LCD_Position(1, 0); LCD_PrCString(gBlankStr_16);
	
	return TRUE;
}


//-----------------------------------------------------------------------------
//  FUNCTION NAME:	setBridgeCorrect(BYTE bBand, DWORD dwFreqHz)
//
//  DESCRIPTION:
//
//	set values in g_xCalSetting by interpolating based on dwFreqHz
//  between g_xCalSettings[bLowerCalBoundary].cal and g_xCalSettings[bLowerCalBoundary+1].cal
//
//  Similarly, set values for g_wVzZero based on g_wVzZeros[bCalPpoint] and g_wVzZeros[bCalPpoint+1]
//  Similarly, set values for g_wVaZero based on g_wVaZeros[bCalPpoint] and g_wVaZeros[bCalPpoint+1]
//
//  ARGUMENTS:
//  	none
//
//  RETURNS:
//     nothing
//
//-----------------------------------------------------------------------------
void setBridgeCorrect(void)
{
	BYTE alpha;
	BYTE bLowerCalBoundary;
	
	bLowerCalBoundary=GetLowerCalBoundary(); // move this out to calling point so it's not done unnecessarily
	alpha=	(  g_dwCurrHz  -  dwGetCalFreqHz(bLowerCalBoundary)  ) 
			/ (   dwGetCalFreqHz(bLowerCalBoundary+1)/256 
					-  dwGetCalFreqHz(bLowerCalBoundary)/256  );
		
	g_xCalSetting.wVzZero  = iInterpolate(alpha,g_xCalSettings[bLowerCalBoundary].wVzZero,g_xCalSettings[bLowerCalBoundary+1].wVzZero);			
	g_xCalSetting.wVaZero  = iInterpolate(alpha,g_xCalSettings[bLowerCalBoundary].wVaZero,g_xCalSettings[bLowerCalBoundary+1].wVaZero);
	
	g_xCalSetting.xVr.iSlope = iInterpolate(alpha,g_xCalSettings[bLowerCalBoundary].xVr.iSlope,g_xCalSettings[bLowerCalBoundary+1].xVr.iSlope);
	g_xCalSetting.xVz.iSlope = iInterpolate(alpha,g_xCalSettings[bLowerCalBoundary].xVz.iSlope,g_xCalSettings[bLowerCalBoundary+1].xVz.iSlope);			
	g_xCalSetting.xVa1.iSlope = iInterpolate(alpha,g_xCalSettings[bLowerCalBoundary].xVa1.iSlope,g_xCalSettings[bLowerCalBoundary+1].xVa1.iSlope);
	g_xCalSetting.xVa2.iSlope = iInterpolate(alpha,g_xCalSettings[bLowerCalBoundary].xVa2.iSlope,g_xCalSettings[bLowerCalBoundary+1].xVa2.iSlope);

	g_xCalSetting.wVaCutover = iInterpolate(alpha,g_xCalSettings[bLowerCalBoundary].wVaCutover,g_xCalSettings[bLowerCalBoundary+1].wVaCutover);

	g_xCalSetting.xVr.iOffset = iInterpolate(alpha,g_xCalSettings[bLowerCalBoundary].xVr.iOffset,g_xCalSettings[bLowerCalBoundary+1].xVr.iOffset);
	g_xCalSetting.xVz.iOffset = iInterpolate(alpha,g_xCalSettings[bLowerCalBoundary].xVz.iOffset,g_xCalSettings[bLowerCalBoundary+1].xVz.iOffset);			
	g_xCalSetting.xVa1.iOffset = iInterpolate(alpha,g_xCalSettings[bLowerCalBoundary].xVa1.iOffset,g_xCalSettings[bLowerCalBoundary+1].xVa1.iOffset);
	g_xCalSetting.xVa2.iOffset = iInterpolate(alpha,g_xCalSettings[bLowerCalBoundary].xVa2.iOffset,g_xCalSettings[bLowerCalBoundary+1].xVa2.iOffset);

//	ultoa(g_buffer16, g_dwCurrHz , 10);  	UART_PutString(g_buffer16); UART_PutChar(',');
//	ultoa(g_buffer16, dwGetCalFreqHz(bLowerCalBoundary), 10);  UART_PutString(g_buffer16);UART_PutChar(',');
//	ultoa(g_buffer16, dwGetCalFreqHz(bLowerCalBoundary+1), 10);  UART_PutString(g_buffer16);UART_PutChar(',');
//	utoa(g_buffer16, alpha , 10);  	UART_PutString(g_buffer16); UART_PutChar(',');
	
//	itoa(g_buffer16, g_xCalSettings[bLowerCalBoundary].xVa1.iSlope , 10);  	UART_PutString(g_buffer16); UART_PutChar(',');
//	itoa(g_buffer16, g_xCalSettings[bLowerCalBoundary+1].xVa1.iSlope , 10);  	UART_PutString(g_buffer16); UART_PutChar(',');
//	itoa(g_buffer16, g_xCalSetting.xVa1.iSlope , 10);  	UART_PutString(g_buffer16); UART_PutChar(',');
//	UART_PutCRLF();

}


//-----------------------------------------------------------------------------
//  FUNCTION NAME:	iInterpolate(BYTE alpha, WORD wV1, WORD wV2)
//
//  DESCRIPTION:
//
//  Linear interpolation
//
//  ARGUMENTS:
//
//
//  RETURNS:
//     
//
//-----------------------------------------------------------------------------
static INT iInterpolate(BYTE alpha, INT iV1, INT iV2)
{
	return (INT)(((long long)iV1 * (255 - alpha) + (long long)iV2 * alpha + 128) / 255);

}



