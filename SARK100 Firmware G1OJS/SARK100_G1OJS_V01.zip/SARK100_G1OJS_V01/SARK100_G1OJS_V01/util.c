//*****************************************************************************/
//  This file is a part of the "SARK100 SWR Analyzer firmware"
//
//  Copyright © 2010 Melchor Varela - EA4FRB.  All rights reserved.
//  Melchor Varela, Madrid, Spain.
//  melchor.varela@gmail.com
//
//  Modified in 2024 by Alan Robinson G1OJS Hampshire England G1OJS@yahoo.com 
//
//  "SARK100 SWR Analyzer firmware" is free software: you can redistribute it
//  and/or modify it under the terms of the GNU General Public License as
//  published by the Free Software Foundation, either version 3 of the License,
//  or (at your option) any later version.
//
//  "SARK100 SWR Analyzer firmware" is distributed in the hope that it will be
//  useful,  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with "SARK100 SWR Analyzer firmware".  If not,
//  see <http://www.gnu.org/licenses/>.
//*****************************************************************************/
//*****************************************************************************/
//
//	PROJECT:	SARK100 SWR Analyzer
// 	FILE NAME: 	UTIL.C
// 	AUTHOR:		EA4FRB - Melchor Varela
//
// 	DESCRIPTION
//
//	Utility functions
//
// 	HISTORY
//
//	NAME   		DATE		REMARKS
//
//	MVM	   		DEC 2009	Creation
//
//	G1OJSv1.0	DEC 2024	Add ultoSpecial and GetLowerCalBoundary
//
//*****************************************************************************/

#include <m8c.h>        		// Part specific constants and macros
#include "PSoCAPI.h"    		// PSoC API definitions for all User Modules
#include "psocgpioint.h"
#include "glb_data.h"
#include "calibrate_reflectometer.h"
#include "util.h"
#include "string.h"

//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Delay_Ms
//
//  DESCRIPTION:
//
//	Wait for a number of ms
//
//  ARGUMENTS:
//     ms	Milliseconds
//
//  RETURNS:
//     none.
//
//-----------------------------------------------------------------------------
void Delay_Ms(WORD ms)
{
	Timer16_Delay_WritePeriod((ms * 33)+1);
	Timer16_Delay_Start();

	while (Timer16_Delay_wReadTimer()!=0)
	{;}
	Timer16_Delay_Stop();
}


//-----------------------------------------------------------------------------
//  FUNCTION NAME: BcdToHex
//
//  DESCRIPTION:
//
//	Converts bcd coded byte to hexadecimal.
//
//  ARGUMENTS:
//    bcd = bcd value.
//
//  RETURNS:
//    Hexadecimal representation of bcd value.
//
//-----------------------------------------------------------------------------
BYTE BcdToHex ( BYTE bcd )
{
	return ((BYTE)((bcd&0xf0)>>4)*10)+(BYTE)(bcd&0x0f);
}

//-----------------------------------------------------------------------------
//  FUNCTION NAME: HexToBcd
//
//  DESCRIPTION:
//
//	Converts hexadecimal number to bcd.
//
//  ARGUMENTS:
//    hex = hexadecimal representation of bcd value.
//
//  RETURNS:
//    bcd value.
//
//-----------------------------------------------------------------------------
BYTE HexToBcd ( BYTE hex )
{
	return ((BYTE)(hex/10)<<4) | (BYTE)(hex%10);
}
//-----------------------------------------------------------------------------
//  FUNCTION NAME:	GetUserIdle
//
//  DESCRIPTION:
//
//	Gets the user Idle timeout from index
//
//  ARGUMENTS:
//		bUserIdle	User Idle index val
//
//  RETURNS:
//     Idle time in seconds
//
//-----------------------------------------------------------------------------
BYTE GetUserIdle (BYTE bUserIdle)
{
	switch (bUserIdle)
	{
		case USER_IDLE_NONE:
			return 0;
		default:
		case USER_IDLE_30S:
			return 30;
		case USER_IDLE_60S:
			return 60;
		case USER_IDLE_90S:
			return 90;
	}
}

//-----------------------------------------------------------------------------
//  FUNCTION NAME:	GetBand
//
//  DESCRIPTION:
//
//	Get band index for a given frequency
//
//  ARGUMENTS:
//     dwFreqHz		Frequency in Hz
//
//  RETURNS:
//     bBand
//
//-----------------------------------------------------------------------------
BYTE GetBand (DWORD dwFreqHz)
{
	BYTE bBand;

	for (bBand=0; bBand<BAND_MAX; bBand++)
	{
		if (dwFreqHz >= (g_xBandLimits[bBand].low*BAND_FREQ_ToHz) &&
			dwFreqHz < (g_xBandLimits[bBand].high*BAND_FREQ_ToHz))
			break;
	}
	if (bBand>=BAND_MAX)
	{
		if (dwFreqHz>FREQ_MAX_Hz)
			return -1;
		if (dwFreqHz<FREQ_MIN_Hz)
			return -1;
		bBand=BAND_MAX-1;
	}
	return bBand;
}

//-----------------------------------------------------------------------------
//  FUNCTION NAME:	GetLowerCalBoundary
//
//  DESCRIPTION:
//
//	Get the lower calibration point to use for the frequency g_dwCurrHz
//  (interpolation is always between bLowerCalBoundary and bLowerCalBoundary+1)
//
//  ARGUMENTS:
//    none
//
//  RETURNS:
//     bLowerCalBoundary
//
//-----------------------------------------------------------------------------
BYTE GetLowerCalBoundary (void)
{
	// bLowerCalBoundary is in the range (0 .. CAL_MAX - 2)
	// bLowerCalBoundary +1  is in the range (1 .. CAL_MAX - 1)

	BYTE bLowerCalBoundary = CAL_MAX-2;
	for (bLowerCalBoundary=0; bLowerCalBoundary < (CAL_MAX-2) ; bLowerCalBoundary++)
	{
		if (g_dwCurrHz < g_wCalBoundaries[bLowerCalBoundary+1]*BAND_FREQ_ToHz) break;
	}

	return bLowerCalBoundary;
}
//-----------------------------------------------------------------------------
//  FUNCTION NAME: ultoSpecial(DWORD dwVal, BYTE maxLen)
//
//  DESCRIPTION: 	Given a DWORD dwVal that is 10 times a represented value:
//					dwVal = 0 to 100 results in 0.0 to 9.9
//					dwVal = 100 upwards results in 10, 11, 12 etc until
//					the resulting string has length > maxLen, then the string is 
//  				replaced with "*" x maxLen
//
//	USED BY DISPLAY
//
//  ARGUMENTS:
//		DWORD dwVal, BYTE maxLen
//
//  RETURNS:
//    Updates g_buffer16 with the result
//
//-----------------------------------------------------------------------------
void ultoSpecial(DWORD dwVal, BYTE maxLen)
{
	BYTE ii;
	BYTE len;

	if(dwVal<10){
    	ultoa(g_buffer16, dwVal, 10);
		len=strlen(g_buffer16);
		memmove(g_buffer16+2, g_buffer16, 2);
        g_buffer16[1]='.';
        g_buffer16[0]='0';
		g_buffer16[len+2]='\0';	
    } else if(dwVal<100){
        ultoa(g_buffer16, dwVal, 10);
		len=strlen(g_buffer16);
        memmove(g_buffer16+1, g_buffer16, 2);
        g_buffer16[1]='.';
		g_buffer16[len+1]='\0'; 
    } else {
        ultoa(g_buffer16, dwVal/10, 10);
    }

    if(strlen(g_buffer16)>maxLen || g_bSgnX=='*' ) {
		for(ii=0; ii<maxLen; ii++) g_buffer16[ii]='*';	// fill with * to indicate overrange
		g_buffer16[maxLen]='\0';						// NUL terminate
    }
}
