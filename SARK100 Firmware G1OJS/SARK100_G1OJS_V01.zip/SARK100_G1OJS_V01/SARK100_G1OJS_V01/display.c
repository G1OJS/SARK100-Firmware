//*****************************************************************************/
//  This file is a part of the "SARK100 SWR Analyzer firmware"
//
//  Copyright © 2010 Melchor Varela - EA4FRB.  All rights reserved.
//  Melchor Varela, Madrid, Spain.
//  melchor.varela@gmail.com
//
//  Modified in 2024 by Alan Robinson G1OJS Hampshire England G1OJS@yahoo.com 
//
//  "SARK100 SWR Analyzer firmware" is free software: you can redistribute it
//  and/or modify it under the terms of the GNU General Public License as
//  published by the Free Software Foundation, either version 3 of the License,
//  or (at your option) any later version.
//
//  "SARK100 SWR Analyzer firmware" is distributed in the hope that it will be
//  useful,  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with "SARK100 SWR Analyzer firmware".  If not,
//  see <http://www.gnu.org/licenses/>.
//*****************************************************************************/
//*****************************************************************************/
//
//	PROJECT:	SARK100 SWR Analyzer
// 	FILE NAME: 	DISPLAY.C
// 	AUTHOR:		Melchor Varela
//
// 	DESCRIPTION
//
//	Display utility functions
//
// 	HISTORY
//
//	NAME   		DATE		REMARKS
//
//	MVM	   		DEC 2009	Creation
//
//  G1OJSv1.0	DEC 2024	New screen layouts
//
//*****************************************************************************/
#include <stdlib.h>
#include <string.h>
#include "m8c.h"
#include "Lcd.h"
#include "Util.h"
#include "Display.h"
#include "Msg_generic.h"
#include "glb_data.h"

//-----------------------------------------------------------------------------
//  FUNCTION NAME: DISP_Setup
//
//  DESCRIPTION:
//
//	Setup display controller and create icons from bitmap data.
//
//  ARGUMENTS:
//	  none.
//
//  RETURNS:
//    none.
//
//-----------------------------------------------------------------------------
void DISP_Setup ( void )
{
	LCD_Start();
	LCD_InitBG(LCD_SOLID_BG);
}


//-----------------------------------------------------------------------------
//  FUNCTION NAME: DISP_Frequency
//
//  DESCRIPTION:
//
//	Display VFO frequency g_dwCurrHz in the current cursor position
//
//  ARGUMENTS:
//    none
//
//  RETURNS:
//    none.
//
//-----------------------------------------------------------------------------

void DISP_Frequency ( void )
{

	// 0123456789012345
	//        56295.350
	ultoa(g_buffer16, g_dwCurrHz/1000, 10);
	LCD_Position(0,7); LCD_WriteData(' ');
	LCD_Position(0, 12-strlen(g_buffer16));	
	LCD_PrString(g_buffer16);
	LCD_Position(0, 12); LCD_WriteData('.');
	ultoa(g_buffer16, g_dwCurrHz %1000, 10);
	LCD_Position(0, 13); LCD_WriteData('0');
	LCD_Position(0, 14); LCD_WriteData('0');
	LCD_Position(0, 16-strlen(g_buffer16)); LCD_PrString(g_buffer16);
	
}


//-----------------------------------------------------------------------------
//  FUNCTION NAME: DISP_SRXZ()
//
//  DESCRIPTION:
//
//	Display current impedance
//
//  ARGUMENTS:
//	  uses global char g_bSgnX		Sign of reactance
//
//  RETURNS:
//    none.
//
//-----------------------------------------------------------------------------
void DISP_SRXZ (void)
{

	// SWR0.0 51000.000
	// R999 X-j999 Z999
	// 0123456789012345
	
	if(g_wSwr100 > DISP_OVERRANGE_SWR) g_bSgnX='*';
	if(g_wR10 > DISP_OVERRANGE) g_bSgnX='*';
	if(g_wX10 > DISP_OVERRANGE) g_bSgnX='*';
//	if(g_wZ10 > DISP_OVERRANGE) g_bSgnX='*';
	
	// SWR top left
	LCD_Position(0,0);
	LCD_PrCString(gBlankStr_7);
	ultoSpecial((DWORD)g_wSwr100/10, 3);
	LCD_Position(0,0);
	LCD_PrCString("SWR");
	LCD_Position(0, 6-strlen(g_buffer16));
	LCD_PrString(g_buffer16);

	// clear bottom row
	LCD_Position(1, 0);
	LCD_PrCString(gBlankStr_16);

	// R bottom left
	LCD_Position(1, 0);
	LCD_WriteData('R');
	ultoSpecial((DWORD)g_wR10, 3);
	LCD_Position(1, 4-strlen(g_buffer16));
  	LCD_PrString(g_buffer16);

	// X bottom middle
	LCD_Position(1, 5);
	LCD_WriteData('X');	
	ultoSpecial((DWORD)g_wX10, 3);
	LCD_Position(1, 11-(strlen(g_buffer16)+2));
	LCD_WriteData(g_bSgnX);	
	LCD_WriteData('j');	
	LCD_PrString(g_buffer16);

	// Z bottom right
	LCD_Position(1, 12);
	LCD_WriteData('Z');
	ultoSpecial((DWORD)g_wZ10, 3);
	LCD_Position(1, 16-strlen(g_buffer16));
	LCD_PrString(g_buffer16);

}


//-----------------------------------------------------------------------------
//  FUNCTION NAME: DISP_Capacitance
//
//  DESCRIPTION:
//
//	Display capacitance
//
//  ARGUMENTS:
//		uses global values:
//		WORD g_wC10		10 x (Capacitance in pF)
//		WORD g_wR10		10 x (R in ohms)
//
//  RETURNS:
//    none.
//
//-----------------------------------------------------------------------------
void DISP_Capacitance (void)
{

	if(g_wX10 > DISP_OVERRANGE) g_bSgnX='*';

	LCD_Position(0, 0);
	LCD_PrCString(gModeStr[MODE_CAP]);

	// clear bottom row
	LCD_Position(1, 0);
	LCD_PrCString(gBlankStr_16);
	
	ultoSpecial(g_wC10,4);
	LCD_Position(1, 0);
	LCD_PrString(g_buffer16);
	LCD_PrCString("pF R=");
	ultoSpecial(g_wR10,4);
	LCD_PrString(g_buffer16);
	LCD_PrCString("\xf4");
}

//-----------------------------------------------------------------------------
//  FUNCTION NAME: DISP_Inductance
//
//  DESCRIPTION:
//
//	Display inductance
//
//  ARGUMENTS:
//		uses global values:
//		WORD g_wL10	10 x (Inductance in uH)
//		WORD g_wR10	10 x (R in ohms) 
//
//  RETURNS:
//    none
//
//-----------------------------------------------------------------------------
void DISP_Inductance ( void )
{

	if(g_wX10 > DISP_OVERRANGE) g_bSgnX='*';

	LCD_Position(0, 0);
	LCD_PrCString(gModeStr[MODE_IND]);

	// clear bottom row
	LCD_Position(1, 0);
	LCD_PrCString(gBlankStr_16);
	
	ultoSpecial(g_wL10,4);
	LCD_Position(1, 0);
	LCD_PrString(g_buffer16);
	LCD_PrCString("uH R=");
	ultoSpecial(g_wR10,4);
	LCD_PrString(g_buffer16);
	LCD_PrCString("\xf4");
}

//-----------------------------------------------------------------------------
//  FUNCTION NAME: DISP_Clear
//
//  DESCRIPTION:
//
//	Clears the screen
//
//  ARGUMENTS:
//
//
//  RETURNS:
//    none.
//
//-----------------------------------------------------------------------------
void DISP_Clear (void)
{
	LCD_Control(LCD_CLEAR);
}


