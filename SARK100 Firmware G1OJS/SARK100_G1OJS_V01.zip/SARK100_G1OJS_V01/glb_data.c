//*****************************************************************************/
//  This file is a part of the "SARK100 SWR Analyzer firmware"
//
//  Copyright © 2010 Melchor Varela - EA4FRB.  All rights reserved.
//  Melchor Varela, Madrid, Spain.
//  melchor.varela@gmail.com
//
//  Modified in 2024 by Alan Robinson G1OJS Hampshire England G1OJS@yahoo.com 
//
//  "SARK100 SWR Analyzer firmware" is free software: you can redistribute it
//  and/or modify it under the terms of the GNU General Public License as
//  published by the Free Software Foundation, either version 3 of the License,
//  or (at your option) any later version.
//
//  "SARK100 SWR Analyzer firmware" is distributed in the hope that it will be
//  useful,  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with "SARK100 SWR Analyzer firmware".  If not,
//  see <http://www.gnu.org/licenses/>.
//*****************************************************************************/
//*****************************************************************************/
//
//	PROJECT:	SARK100 SWR Analyzer
// 	FILE NAME: 	GLB_DATA.C
// 	AUTHOR:		EA4FRB - Melchor Varela
//
// 	DESCRIPTION
//
//	Global constants and variables
//
// 	HISTORY
//
//	NAME   	DATE		REMARKS
//
//	MVM	   	DEC 2009	Creation
//
//  G1OJSv1.0	DEC 2024	Align data with refactoring and functional changes
//
//*****************************************************************************/
#include <stdlib.h>
#include <m8c.h>

#include "glb_data.h"
#include "PSoCAPI.h"

//-----------------------------------------------------------------------------
//  Public data:
//-----------------------------------------------------------------------------
										// Timer variables managed by Sleep_Timer
volatile BYTE g_bIdleCounter = 0;
volatile BYTE g_bMeasureCounter = 0;
volatile BYTE g_bDebounceCounter = 0;
volatile BYTE g_bSpeedKeyCounter = 0;

BYTE g_buffer16[16];					// global generic string buffer

BYTE g_bScanning = FALSE;				// TRUE while scanning
BYTE g_bIsCalibrated;					// TRUE if calibrated
BYTE g_bDDS_GainStep;

BRIDGE_CORRECT g_xCalSettings[CAL_MAX]; // Correction values for each cal point
BRIDGE_CORRECT g_xCalSetting;			// Current correction values
BRIDGE_VOLTAGES g_xBridgeMeasure;		// Measured bridge voltages
CONFIG_DATA g_xConf;					// Configuration data

DWORD g_dwCurrHz;						// current frequency in Hz
WORD g_wSwr100;							// SWV x 100
WORD g_wZ10;							// |Z|_ohms x 10 
WORD g_wX10;							// X_ohms x 10
WORD g_wR10;							// R_ohms x 10
WORD g_wL10;							// L_uH x 10
WORD g_wC10;							// C_pF x 10
BYTE g_bSgnX = ' ';						// sign of reactance +/-/' '
BYTE g_bMode;							// current measurement mode

										// Band limits definition table
										
BAND_LIMITS const g_xBandLimits[BAND_MAX] =
{
	{10,18,20},		//160m
	{20,37,50},		//80m
	{50,53,60},		//60m
	{60,71,80},		//40m
	{80,101,110},	//30m
	{110,120,130},	//25m
	{130,141,170},	//20m
	{170,181,190},	//17m
	{190,210,230},	//15m
	{230,249,260},	//12m
	{260,270,280},	//11m
	{280,290,310},	//10m
	{310,355,400},	//8m
	{400,445,490},	//7m
	{490,510,530}	//6m
};


const WORD g_wCalBoundaries[CAL_MAX] =
{10,39,146,268,437,519,549,583,596,601};

// VzZero,VaZero,VaCutover, Vr{iSlope, iOffset},Vz{iSlope, iOffset},Va1{iSlope, iOffset},Va2{iSlope, iOffset}: 
const BRIDGE_CORRECT g_xDefaultCalSettings[CAL_MAX] = 
{   
{ 40,57,706, {-84, 1184}, {-99, 1161}, {-269, 1249}, {-499, 1314} },
{ 47,6,756, {-173, 1247}, {-143, 1198}, {-87, 1117}, {-69, 1112} },
{ 137,81,642, {-187, 1258}, {-264, 1341}, {-295, 1290}, {-470, 1335} },
{ 259,204,481, {-247, 1307}, {-557, 1617}, {-946, 1684}, {-1273, 1747} },
{ 268,215,459, {-262, 1307}, {-596, 1641}, {-992, 1707}, {-1172, 1740} },
{ 318,292,298, {-347, 1344}, {-1163, 1958}, {-2971, 2369}, {-3189, 2395} },
{ 320,291,248, {-445, 1403}, {-1596, 2147}, {-4171, 2638}, {-4217, 2643} },
{ 305,274,218, {-622, 1504}, {-1931, 2253}, {-4814, 2741}, {-1873, 2485} },
{ 267,239,167, {-979, 1619}, {-2790, 2423}, {-6424, 2903}, {7243, 1990} },
{ 243,220,139, {-1389, 1742}, {-3581, 2566}, {-8376, 3109}, {22123, 1413} }
};


										// PGA DDS gain settings table
GAIN_DDS const g_xGainDds[GAIN_SETTINGS_MAX] =
{
  {PGA_DDS_2_G0_62,PGA_DDS_2_G0_43}, // 0.62 x 0.43 = 0.2666
  {PGA_DDS_2_G0_68,PGA_DDS_2_G0_37}, // 0.68 x 0.37 = 0.2516
  {PGA_DDS_2_G0_56,PGA_DDS_2_G0_43}, // 0.56 x 0.43 = 0.2408
  {PGA_DDS_2_G0_62,PGA_DDS_2_G0_37}, // 0.62 x 0.37 = 0.2294
  {PGA_DDS_2_G0_43,PGA_DDS_2_G0_50}, // 0.43 x 0.5 = 0.215
  {PGA_DDS_2_G0_56,PGA_DDS_2_G0_37}, // 0.56 x 0.37 = 0.2072
  {PGA_DDS_2_G0_62,PGA_DDS_2_G0_31}, // 0.62 x 0.31 = 0.1922
  {PGA_DDS_2_G0_43,PGA_DDS_2_G0_43}, // 0.43 x 0.43 = 0.1849
  {PGA_DDS_2_G0_56,PGA_DDS_2_G0_31}, // 0.56 x 0.31 = 0.1736
  {PGA_DDS_2_G0_68,PGA_DDS_2_G0_25}, // 0.68 x 0.25 = 0.17
  {PGA_DDS_2_G0_50,PGA_DDS_2_G0_31}, // 0.5 x 0.31 = 0.155
  {PGA_DDS_2_G0_43,PGA_DDS_2_G0_31}, // 0.43 x 0.31 = 0.1333
  {PGA_DDS_2_G0_50,PGA_DDS_2_G0_25}, // 0.5 x 0.25 = 0.125
  {PGA_DDS_2_G0_62,PGA_DDS_2_G0_18}, // 0.62 x 0.18 = 0.1116
  {PGA_DDS_2_G0_56,PGA_DDS_2_G0_18}, // 0.56 x 0.18 = 0.1008
  {PGA_DDS_2_G0_50,PGA_DDS_2_G0_18}, // 0.5 x 0.18 = 0.09
  {PGA_DDS_2_G0_43,PGA_DDS_2_G0_18}, // 0.43 x 0.18 = 0.0774
};




