//*****************************************************************************/
//  This file is a part of the "SARK100 SWR Analyzer firmware"
//
//  Copyright © 2010 Melchor Varela - EA4FRB.  All rights reserved.
//  Melchor Varela, Madrid, Spain.
//  melchor.varela@gmail.com
//
//  Modified in 2024 by Alan Robinson G1OJS Hampshire England G1OJS@yahoo.com 
//
//  "SARK100 SWR Analyzer firmware" is free software: you can redistribute it
//  and/or modify it under the terms of the GNU General Public License as
//  published by the Free Software Foundation, either version 3 of the License,
//  or (at your option) any later version.
//
//  "SARK100 SWR Analyzer firmware" is distributed in the hope that it will be
//  useful,  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with "SARK100 SWR Analyzer firmware".  If not,
//  see <http://www.gnu.org/licenses/>.
//*****************************************************************************/
//*****************************************************************************/
//
//	PROJECT:	SARK100 SWR Analyzer
// 	FILE NAME: 	GLB_DATA.H
// 	AUTHOR:		EA4FRB - Melchor Varela
//
// 	DESCRIPTION
//
//	Global constants and variables
//
// 	HISTORY
//
//	NAME   		DATE		REMARKS
//
//	MVM	   		DEC 2009	Creation
//
//  G1OJSv1.0	DEC 2024	Align data with refactoring and functional changes
//
//*****************************************************************************/
#ifndef __GLB_DATA_H__
#define __GLB_DATA_H__

#include <stdlib.h>
#include <m8c.h>

#include "measure.h"

//-----------------------------------------------------------------------------
//  Version string
//-----------------------------------------------------------------------------
#define VERSION_STR			"V02"
#define PRODUCT_NAME_STR	"SARK100"

//-----------------------------------------------------------------------------
//  Defines
//-----------------------------------------------------------------------------

#define	PRECISION			1000		// Correction factor used for calibration
#define WORD_MAX			65535		// largest number available in WORD
#define VR_OVER_VF_MAX		996			// largest value of PRECISIONxVr/Vf that gives SWRx100 storable in WORD 996 corresponds to VSWR=499.

#define FREQ_MIN_Hz			1000000
#define FREQ_MAX_Hz			60000000

#define GAIN_SETTINGS_MAX	17			// Number of gain settings for DDS PGAs 
#define TIME_WAIT_KEY_S		30			// Time to wait for key when dialog, units of seconds
#define	MEASURE_PERIOD		16			// Measurements sample period, units (1/8 sec ??)
#define BAND_FREQ_ToHz		100000		// Frequency multiplier for frequency tables


typedef enum {							// Configuration menu
	CONFIG_PCLINK = 0,
	CONFIG_Idle,
	CONFIG_CALIB,
	CONFIG_SW_LOAD,
	
	CONFIG_MAX
} CONFIG_DEFS;

typedef enum {							// Mode menu
	MODE_IMPD = 0,
	MODE_IMPN,
	MODE_CAP,
	MODE_IND,
	MODE_SIG,

	MODE_MAX
} MODE_DEFS;

typedef enum {							// User Idle timeout values
	USER_IDLE_NONE,
	USER_IDLE_30S,
	USER_IDLE_60S,
	USER_IDLE_90S,

	USER_IDLE_MAX
} USER_IDLE_DEFS;

typedef enum {							// Band values
	BAND_160M,
	BAND_80M,
	BAND_60M,
	BAND_40M,
	BAND_30M,
	BAND_25M,
	BAND_20M,
	BAND_17M,
	BAND_15M,
	BAND_12M,
	BAND_11M,
	BAND_10M,
	BAND_8M,
	BAND_7M,
	BAND_6M,
	
	BAND_MAX
} BAND_DEFS;

typedef struct							// Band limits definition
{
	WORD low;
	WORD middle;
	WORD high;
} BAND_LIMITS;

typedef struct							// PGA's DDS gain settings
{
	BYTE bGain1;
	BYTE bGain2;
} GAIN_DDS;

typedef struct							// Configuration data stored in EEPROM
{
	BYTE bUserIdle;
} CONFIG_DATA;


#define CAL_START_Hz			999666		// start cal freqs at a -ve offset to avoid whole MHz (especially odd ones) as these are bad for calibration repeatability
#define CAL_FREQ_STEP_Hz		4000000		// Frequency interval between calibration freqs
#define CAL_FREQS_MAX			16			// Number of calibration frequencies (must satisfy (CAL_FREQS_MAX-1)* CAL_FREQ_STEP_Hz >= FREQ_MAX_Hz-CAL_START_Hz)
										
// Calibration with 10R, 50R, 220R, 560R loads:
#define TRUE_RATIO_LOW			200			// Vz/Va expected at low cal point, x1000
#define TRUE_RATIO_MATCH		1000		// Vz/Va expected at match cal point, x1000
#define TRUE_RATIO_HIGH			4400		// Vz/Va expected at high cal point, x1000
#define TRUE_RATIO_HIGH2		11200		// Vz/Va expected at high2 cal point, x1000
#define TRUE_MODGAMMA_LOW		667			// |Gamma| = Vr/Vf expected at low cal point, x1000
#define TRUE_MODGAMMA_HIGH		630			// |Gamma| = Vr/Vf expected at high cal point, x1000
#define TRUE_MODGAMMA_HIGH2		836			// |Gamma| = Vr/Vf expected at high2 cal point, x1000


typedef enum {							// Calibration load indexes
	CAL_LOAD_LOW,
	CAL_LOAD_MATCH,
	CAL_LOAD_HIGH,
	CAL_LOAD_HIGH2,
	
	CAL_LOAD_MAX
} CAL_LOAD_DEFS;

typedef struct							// Ratios measured during calibration (x PRECISION)
{
	WORD wVzVa[CAL_LOAD_MAX];
	WORD wVrVf[CAL_LOAD_MAX]; 
} CAL_SETTINGS;

//-----------------------------------------------------------------------------
//  Public data:
//-----------------------------------------------------------------------------
extern volatile BYTE g_bIdleCounter;
extern volatile BYTE g_bMeasureCounter;
extern volatile BYTE g_bDebounceCounter;
extern volatile BYTE g_bSpeedKeyCounter;

extern BYTE g_buffer16[16];
extern const BAND_LIMITS g_xBandLimits[BAND_MAX];

extern BYTE g_bIsCalibrated;
extern CONFIG_DATA g_xConf;

extern BYTE g_bDDS_GainStep;
extern const GAIN_DDS g_xGainDds[GAIN_SETTINGS_MAX];

extern const WORD g_wCalFreqs[CAL_FREQS_MAX];
extern CAL_SETTINGS g_xwRatiosAtCalFreqs[CAL_FREQS_MAX];

extern BRIDGE_RATIOS g_xBridge;
extern DWORD g_dwCurrHz;
extern BYTE g_bMode;
extern WORD g_wSwr100;
extern WORD g_wZ10;
extern WORD g_wX10;
extern WORD g_wR10;
extern WORD g_wL10;
extern WORD g_wC10;
extern BYTE g_bSgnX;

//-----------------------------------------------------------------------------
#endif