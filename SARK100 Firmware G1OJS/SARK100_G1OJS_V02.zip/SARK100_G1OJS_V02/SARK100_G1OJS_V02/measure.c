//*****************************************************************************/
//  This file is a part of the "SARK100 SWR Analyzer firmware"
//
//  Copyright © 2010 Melchor Varela - EA4FRB.  All rights reserved.
//  Melchor Varela, Madrid, Spain.
//  melchor.varela@gmail.com
//
//  "SARK100 SWR Analyzer firmware" is free software: you can redistribute it
//  and/or modify it under the terms of the GNU General Public License as
//  published by the Free Software Foundation, either version 3 of the License,
//  or (at your option) any later version.
//
//  "SARK100 SWR Analyzer firmware" is distributed in the hope that it will be
//  useful,  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with "SARK100 SWR Analyzer firmware".  If not,
//  see <http://www.gnu.org/licenses/>.
//*****************************************************************************/
//*****************************************************************************/
//
//	PROJECT:	SARK100 SWR Analyzer
// 	FILE NAME: 	MEASURE.C
// 	AUTHOR:		EA4FRB - Melchor Varela
//
// 	DESCRIPTION
//
//	Measure reflectometer voltages
//
// 	HISTORY
//
//	NAME   		DATE		REMARKS
//
//	MVM	   		DEC 2009	Creation
//
//*****************************************************************************/

#include <m8c.h>        				// Part specific constants and macros
#include <math.h>

#include "PSoCAPI.h"
#include "psocgpioint.h"
#include "util.h"
#include "measure.h"
#include "glb_data.h"
#include "dds.h"

//-----------------------------------------------------------------------------
//  Prototypes
//-----------------------------------------------------------------------------
//static DWORD MeasureInput(void);
static WORD Get_CDS_Sample (void);
static int Read_ADC (void);

//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Do_Measure
//
//  DESCRIPTION:
//
//	Measure reflectometer voltages.
//
//  ARGUMENTS:
//
//  RETURNS: Nothing, but sets global variables:
//     g_xBridge.wVzVa (PRECISION x "Vz/Va")
//     g_xBridge.wVrVf (PRECISION x "Vr/Vf")
//
//-----------------------------------------------------------------------------
void Do_Measure ( void )
{
	DWORD num;
	DWORD denom;
		
	// Read Vz
	AMUX4_ADC_InputSelect(AMUX4_ADC_PORT0_5);
	num = Get_CDS_Sample();
	
	// Read Va
	AMUX4_ADC_InputSelect(AMUX4_ADC_PORT0_7);
	denom = Get_CDS_Sample();
		
	// WORD with PRECISION=1000 goes to 50*65.535=3276.75 ohms and down to 0.05 ohms
	// 3k ohms can be seen on open circuit at lower frequencies, so we need to cap at WORD_MAX
	// which occurs if num*PRECISION >= WORD_MAX*denom
	//	g_xBridge.wVzVa = ((DWORD)PRECISION*num >= (DWORD)WORD_MAX*denom)? WORD_MAX:((WORD)(((DWORD)PRECISION*num)/denom));
	g_xBridge.wVzVa = wDivide(num,denom);
	
	// Read Vr
	PGA_ADC_SetGain(PGA_ADC_G5_33);		// Gain is set to double because dynamic range is half
	Delay_Ms(1);
	AMUX4_ADC_InputSelect(AMUX4_ADC_PORT0_3);
	num = Get_CDS_Sample();
	PGA_ADC_SetGain(PGA_ADC_G2_67);		// Restores gain
	
	// Read Vf
	AMUX4_ADC_InputSelect(AMUX4_ADC_PORT0_1);
	denom = Get_CDS_Sample();

	// Vr can sometimes slightly exceed Vf due to measurement error, but
	// this is capped after correction in Do_Correct and the raw (uncorrected) ratio is only ever seen if verbose pcLink is used
	// in which case assume expert user & don't hide the measurement errors. However, use the wDivide function for WORD_MAX safety
	//g_xBridge.wVrVf = (WORD) (((DWORD)PRECISION*num)/denom);
	g_xBridge.wVrVf = wDivide(num,denom);
	
}

//-----------------------------------------------------------------------------
//  FUNCTION NAME:	MeasureDDSOutput
//
//  DESCRIPTION: Measure Vf for initial check of DDS output health
//
//  ARGUMENTS: None
//
//  RETURNS: WORD = Vf
//
//-----------------------------------------------------------------------------
WORD MeasureDDSOutput(void)
{			
	AMUX4_ADC_InputSelect(AMUX4_ADC_PORT0_1);	// Read Vf
	return Get_CDS_Sample();
}

//-----------------------------------------------------------------------------
//  FUNCTION NAME:	MeasureExternalRF
//
//  DESCRIPTION: Measure Vz for external RF check / power measurement
//
//  Rough cal at 1MHz:
//
//	+10dBm = 1300,  +5dBm = 640,  0dBm = 380, -5dBm = 200, 
//	-10dBm =  100, -15dBm = 60, -20dBm = 40
//
//  ARGUMENTS: None
//
//  RETURNS: WORD = Vz
//
//-----------------------------------------------------------------------------
WORD MeasureExternalRF(void)
{								
	AMUX4_ADC_InputSelect(AMUX4_ADC_PORT0_5);	// Read Vz
	return Get_CDS_Sample();
}
//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Get_CDS_Sample
//
//  DESCRIPTION:
//
//	Takes sample from ADC using correlated double sampling
//
//  ARGUMENTS:
//     none.
//
//  RETURNS:
//     int Measured value (non-negative)
//
//-----------------------------------------------------------------------------
static WORD Get_CDS_Sample (void)
{
	int iVal = 0;

	PGA_ADC_GAIN_CR1 &= ~1;				// Set input to RefLO
	iVal -= Read_ADC();
	
	PGA_ADC_GAIN_CR1 |= 1;				// Set input to PortInp
	iVal += Read_ADC();
	
	return iNonNegative(iVal);	
}
//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Read_ADC
//
//  DESCRIPTION:
//
//	Reads the ADC and resets the data flag
//
//  ARGUMENTS:
//     none.
//
//  RETURNS:
//     Measured value
//
//-----------------------------------------------------------------------------
static int Read_ADC (void)
{
	int iVal;

	ADCINC12_GetSamples(1);			
	while(ADCINC12_fIsDataAvailable() == 0);	// Wait for data to be ready.
	iVal = ADCINC12_iGetData()+2048;
	ADCINC12_ClearFlag();
		
	return iVal;
	
}

