//*****************************************************************************/
//  This file is a part of the "SARK100 SWR Analyzer firmware"
//
//  Copyright © 2010 Melchor Varela - EA4FRB.  All rights reserved.
//  Melchor Varela, Madrid, Spain.
//  melchor.varela@gmail.com
//
//  Modified in 2024 by Alan Robinson G1OJS Hampshire England G1OJS@yahoo.com 
//
//  "SARK100 SWR Analyzer firmware" is free software: you can redistribute it
//  and/or modify it under the terms of the GNU General Public License as
//  published by the Free Software Foundation, either version 3 of the License,
//  or (at your option) any later version.
//
//  "SARK100 SWR Analyzer firmware" is distributed in the hope that it will be
//  useful,  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with "SARK100 SWR Analyzer firmware".  If not,
//  see <http://www.gnu.org/licenses/>.
//*****************************************************************************/
//*****************************************************************************/
//
//	PROJECT:	SARK100 SWR Analyzer
// 	FILE NAME: 	GLB_DATA.C
// 	AUTHOR:		EA4FRB - Melchor Varela
//
// 	DESCRIPTION
//
//	Global constants and variables
//
// 	HISTORY
//
//	NAME   	DATE		REMARKS
//
//	MVM	   	DEC 2009	Creation
//
//  G1OJSv1.0	DEC 2024	Align data with refactoring and functional changes
//
//*****************************************************************************
//
//*****************************************************************************
// 	IMAGECRAFT COMPILER TYPE DEFINITIONS
// 	From page 17 of the ImageCraft C Compiler Guide, Document # 001-44476 Rev *A
//
//	Type				Bytes		Range
//	[unsigned] char			1		0 .. 255
//      signed char			1		-128 .. 127
//
//	unsigned int			2		0 .. 65535
//	[signed] int			2		-32786 .. 32767
//
//	unsigned int|short		2		0 .. 65535
//	[signed] int|short		2		-32786 .. 32767
//
//	unsigned long			4		0 .. 4,294,967,295
//	[signed] long			4		-2,147,483,648 .. 2,147,483,647
//
//	float | double			4		1.175e-38 .. 3.40e+38
//
//	enum					1		if enum < 256
//							2		if enum >= 256
//
//	BOOL  = unsigned char   1		0 .. 255
//	BYTE  = unsigned char	1		0 .. 255
//	CHAR  = signed char		1		-128 .. 127
//	WORD  = unsigned int	2		0 .. 65535
//	INT   = signed int		2		-32786 .. 32767
//	DWORD = unsigned long	4		0 .. 4,294,967,295
//	LONG  = signed long		4		-2,147,483,648 .. 2,147,483,647
//
//*****************************************************************************
//
//
//


#include <stdlib.h>
#include <m8c.h>

#include "glb_data.h"
#include "PSoCAPI.h"

//-----------------------------------------------------------------------------
//  Public data:
//-----------------------------------------------------------------------------
										// Timer variables managed by Sleep_Timer
volatile BYTE g_bIdleCounter = 0;
volatile BYTE g_bMeasureCounter = 0;
volatile BYTE g_bDebounceCounter = 0;
volatile BYTE g_bSpeedKeyCounter = 0;

BYTE g_buffer16[16];					// global generic string buffer

BYTE g_bIsCalibrated = FALSE;			// TRUE if calibrated
BYTE g_bDDS_GainStep = 0;				// Default setting is 0 (lowest gain)

CAL_SETTINGS g_xwRatiosAtCalFreqs[CAL_FREQS_MAX]; // Cal ratios Vz/Va and Vr/Vf for as measured during cal for each cal freq

BRIDGE_RATIOS g_xBridge;				// Measured bridge ratios
CONFIG_DATA g_xConf;					// Configuration data

DWORD g_dwCurrHz;						// current frequency in Hz
WORD g_wSwr100;							// SWV x 100
WORD g_wZ10;							// |Z|_ohms x 10 
WORD g_wX10;							// X_ohms x 10
WORD g_wR10;							// R_ohms x 10
WORD g_wL10;							// L_uH x 10
WORD g_wC10;							// C_pF x 10
BYTE g_bSgnX = ' ';						// sign of reactance +/-/' '
BYTE g_bMode;							// current measurement mode

										// Band limits definition table
										
const BAND_LIMITS g_xBandLimits[BAND_MAX] =
{
	{10,18,20},		//160m
	{20,37,50},		//80m
	{50,53,60},		//60m
	{60,71,80},		//40m
	{80,101,110},	//30m
	{110,120,130},	//25m
	{130,141,170},	//20m
	{170,181,190},	//17m
	{190,210,230},	//15m
	{230,249,260},	//12m
	{260,270,280},	//11m
	{280,290,310},	//10m
	{310,355,400},	//8m
	{400,445,490},	//7m
	{490,510,530}	//6m
};

// PGA DDS gain settings table
const GAIN_DDS g_xGainDds[GAIN_SETTINGS_MAX] =
{
  {PGA_DDS_2_G0_62,PGA_DDS_2_G0_43}, // 0.62 x 0.43 = 0.2666
  {PGA_DDS_2_G0_68,PGA_DDS_2_G0_37}, // 0.68 x 0.37 = 0.2516
  {PGA_DDS_2_G0_56,PGA_DDS_2_G0_43}, // 0.56 x 0.43 = 0.2408
  {PGA_DDS_2_G0_62,PGA_DDS_2_G0_37}, // 0.62 x 0.37 = 0.2294
  {PGA_DDS_2_G0_43,PGA_DDS_2_G0_50}, // 0.43 x 0.5 = 0.215
  {PGA_DDS_2_G0_56,PGA_DDS_2_G0_37}, // 0.56 x 0.37 = 0.2072
  {PGA_DDS_2_G0_62,PGA_DDS_2_G0_31}, // 0.62 x 0.31 = 0.1922
  {PGA_DDS_2_G0_43,PGA_DDS_2_G0_43}, // 0.43 x 0.43 = 0.1849
  {PGA_DDS_2_G0_56,PGA_DDS_2_G0_31}, // 0.56 x 0.31 = 0.1736
  {PGA_DDS_2_G0_68,PGA_DDS_2_G0_25}, // 0.68 x 0.25 = 0.17
  {PGA_DDS_2_G0_50,PGA_DDS_2_G0_31}, // 0.5 x 0.31 = 0.155
  {PGA_DDS_2_G0_43,PGA_DDS_2_G0_31}, // 0.43 x 0.31 = 0.1333
  {PGA_DDS_2_G0_50,PGA_DDS_2_G0_25}, // 0.5 x 0.25 = 0.125
  {PGA_DDS_2_G0_62,PGA_DDS_2_G0_18}, // 0.62 x 0.18 = 0.1116
  {PGA_DDS_2_G0_56,PGA_DDS_2_G0_18}, // 0.56 x 0.18 = 0.1008
  {PGA_DDS_2_G0_50,PGA_DDS_2_G0_18}, // 0.5 x 0.18 = 0.09
  {PGA_DDS_2_G0_43,PGA_DDS_2_G0_18}, // 0.43 x 0.18 = 0.0774
};




