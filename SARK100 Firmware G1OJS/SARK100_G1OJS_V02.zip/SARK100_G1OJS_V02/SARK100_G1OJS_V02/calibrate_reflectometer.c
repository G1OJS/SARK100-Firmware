//*****************************************************************************/
//  This file is a part of the "SARK100 SWR Analyzer firmware"
//
//  Copyright © 2010 Melchor Varela - EA4FRB.  All rights reserved.
//  Melchor Varela, Madrid, Spain.
//  melchor.varela@gmail.com
//
//  Modified in 2024 by Alan Robinson G1OJS Hampshire England G1OJS@yahoo.com 
//
//  "SARK100 SWR Analyzer firmware" is free software: you can redistribute it
//  and/or modify it under the terms of the GNU General Public License as
//  published by the Free Software Foundation, either version 3 of the License,
//  or (at your option) any later version.
//
//  "SARK100 SWR Analyzer firmware" is distributed in the hope that it will be
//  useful,  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with "SARK100 SWR Analyzer firmware".  If not,
//  see <http://www.gnu.org/licenses/>.
//*****************************************************************************/
//*****************************************************************************/
//
//	PROJECT:	SARK100 SWR Analyzer
// 	FILE NAME: 	CALIBRATE_REFRECTOMETER.C
// 	AUTHOR:		EA4FRB - Melchor Varela
//
// 	DESCRIPTION
//
//	Calibration routines
//
// 	HISTORY
//
//	NAME   		DATE		REMARKS
//
//	MVM	   		DEC 2009	Creation
//
//  G1OJSv1.0	DEC 2024	New calibration routines and interpolation function
//							Refactoring incl SetMeasureCalcDisplay also used by main
//
//*****************************************************************************/

#include <m8c.h>        				// Part specific constants and macros
#include "PSoCAPI.h"
#include "Lcd.h"

#include "dds.h"
#include "util.h"
#include "glb_data.h"
#include "keypad.h"
#include "msg_generic.h"
#include "buzzer.h"
#include "storage.h"
#include "display.h"
#include "calibrate_reflectometer.h"
#include "calcs.h"

//-----------------------------------------------------------------------------
//  Defines
//-----------------------------------------------------------------------------
#define VF_REFERENCE_LEVEL	3900		// Full scale value
#define WAIT_TIME_MEASURE	500			// Estabilizing time for measurement (ms)

//-----------------------------------------------------------------------------
//  Prototypes
//-----------------------------------------------------------------------------
static BOOL WaitLoadUser (const char *pszText);
static WORD wXPrime(DWORD dwX, DWORD dwX1, DWORD dwX2, DWORD dwXPrime1, DWORD dwXprime2);

//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Calibrate_Reflectometer()
//
//  DESCRIPTION:
//
//	Calibration routine
//
//  ARGUMENTS:
//     none.
//
//  RETURNS:
//     none.
//
//-----------------------------------------------------------------------------
void Calibrate_Reflectometer (void)
{
	BYTE bCalFreqIndex;
	BYTE bLoad;
	
	M8C_EnableGInt ;

	do
	{
		LCD_Control(LCD_CLEAR);
	
		// Find DDS Gain step needed for reasonable Vf 
		// This is also an opportunity to abort the calibration without changing anything, so display the Confirm string
		if (!WaitLoadUser(gDisconnectLoadStr))
			break;
  		LCD_Position(1, 0); LCD_PrCString(gSettingGainStr);
		g_dwCurrHz=FREQ_MIN_Hz;
		DDS_Set(g_dwCurrHz);
		DISP_Frequency();
		for (g_bDDS_GainStep=0;g_bDDS_GainStep<GAIN_SETTINGS_MAX;g_bDDS_GainStep++)
		{
			PGA_DDS_1_SetGain(g_xGainDds[g_bDDS_GainStep].bGain1);
			PGA_DDS_2_SetGain(g_xGainDds[g_bDDS_GainStep].bGain2);
			Delay_Ms(100);
			if ( (MeasureDDSOutput() >= VF_REFERENCE_LEVEL) || (g_bDDS_GainStep==(GAIN_SETTINGS_MAX-1) ) ) break;
		}

		// now find and remember the ratios Vz/Va and Vr/Vf at each cal frequency and load			
		for (bLoad=0; bLoad < CAL_LOAD_MAX; bLoad++)
		{
			if (!WaitLoadUser(gCalLoadStr[bLoad]))
				break;
			DISP_Clear(); LCD_Position(1, 0); LCD_PrCString(gCalibratingStr);
			for (bCalFreqIndex=0; bCalFreqIndex<CAL_FREQS_MAX;bCalFreqIndex++)
			{
				g_dwCurrHz=CAL_START_Hz + (DWORD)(bCalFreqIndex * CAL_FREQ_STEP_Hz) ;
				DDS_Set(g_dwCurrHz);
				DISP_Frequency();
				Delay_Ms(10);
				Do_Measure();
				g_xwRatiosAtCalFreqs[bCalFreqIndex].wVzVa[bLoad] = g_xBridge.wVzVa;
				g_xwRatiosAtCalFreqs[bCalFreqIndex].wVrVf[bLoad] = g_xBridge.wVrVf;
			}
		}

		// Store cal factors in EEPROM
		g_bIsCalibrated=TRUE; // this needs to be set to True here, and only here
		STR_SaveCalibration();
	}
	while (FALSE);
	
	// Finish, alert user
	LCD_Control(LCD_CLEAR);
	LCD_Position(0, 0);
	LCD_PrCString(gConfigDoCalStr);
	LCD_Position(1, 0);
	LCD_PrCString(gDoneRestartingStr);
	BUZZ_Beep();
	Delay_Ms(500);


}
//-----------------------------------------------------------------------------
//  FUNCTION NAME:	Do_Correct()
//
//  DESCRIPTION:
//
//	Do the complete adjustment of the measurement based on two-point calibration data
//
//  ARGUMENTS:
//  	none
//
//  RETURNS:
//     none.
//
//-----------------------------------------------------------------------------
void Do_Correct (void)
{
	CAL_SETTINGS CalRatios;		// Cal ratios Vz/Va and Vr/Vf interpolated for curr freq
	WORD alpha;
	BYTE bCalFreqIndex;
	BYTE bLoad;
	
	// Get calibration data for current frequency
	// alpha calc not needed here - can be done direct from freq data as dwXPrime arguments. To Do!
	bCalFreqIndex = (g_dwCurrHz - CAL_START_Hz) / CAL_FREQ_STEP_Hz;																		
	alpha = (DWORD)(g_dwCurrHz - (CAL_START_Hz + (DWORD)(bCalFreqIndex * CAL_FREQ_STEP_Hz)))/ (CAL_FREQ_STEP_Hz/PRECISION);				
	for (bLoad=0; bLoad < CAL_LOAD_MAX; bLoad++)
	{	
		CalRatios.wVzVa[bLoad] = wXPrime(alpha, 0, PRECISION, g_xwRatiosAtCalFreqs[bCalFreqIndex].wVzVa[bLoad], g_xwRatiosAtCalFreqs[bCalFreqIndex+1].wVzVa[bLoad]);			
		CalRatios.wVrVf[bLoad] = wXPrime(alpha, 0, PRECISION, g_xwRatiosAtCalFreqs[bCalFreqIndex].wVrVf[bLoad], g_xwRatiosAtCalFreqs[bCalFreqIndex+1].wVrVf[bLoad]);
	}

	// Recalculate dwVzVa based on its current value relative to the cal points at this frequency.
	// If current value of the ratio is below that measured for 50 ohm cal, use slope downwards towards lower cal point. Otherwise use upper slope towards upper cal point.
	if(g_xBridge.wVzVa < CalRatios.wVzVa[CAL_LOAD_MATCH]) 
	{									
		g_xBridge.wVzVa = wXPrime(g_xBridge.wVzVa, CalRatios.wVzVa[CAL_LOAD_MATCH],  CalRatios.wVzVa[CAL_LOAD_LOW], PRECISION,  TRUE_RATIO_LOW);
	}	else if (g_xBridge.wVzVa < CalRatios.wVzVa[CAL_LOAD_HIGH]) {
		g_xBridge.wVzVa = wXPrime(g_xBridge.wVzVa, CalRatios.wVzVa[CAL_LOAD_MATCH], CalRatios.wVzVa[CAL_LOAD_HIGH], PRECISION, TRUE_RATIO_HIGH);
	} else {
		g_xBridge.wVzVa = wXPrime(g_xBridge.wVzVa, CalRatios.wVzVa[CAL_LOAD_HIGH], CalRatios.wVzVa[CAL_LOAD_HIGH2], TRUE_RATIO_HIGH, TRUE_RATIO_HIGH2);
	}
	
	// Also do similar for Vr/Vf, now using corrected Vz/Va compared with Vz/Va=1 (50 ohms) to decide which half of the V slope to use
	if(g_xBridge.wVzVa < PRECISION) 
	{	// lower side of the V has only one slope from match to lower cal load
		g_xBridge.wVrVf  = wXPrime(g_xBridge.wVrVf, CalRatios.wVrVf[CAL_LOAD_MATCH], CalRatios.wVrVf[CAL_LOAD_LOW], 0, TRUE_MODGAMMA_LOW);						
	} else { // upper side of the "V" is split into two slopes and the portion is determined by wVrVf
		if(g_xBridge.wVrVf < CalRatios.wVrVf[CAL_LOAD_HIGH]) {					
			g_xBridge.wVrVf  = wXPrime(g_xBridge.wVrVf, CalRatios.wVrVf[CAL_LOAD_MATCH], CalRatios.wVrVf[CAL_LOAD_HIGH], 0, TRUE_MODGAMMA_HIGH);	
		} else {
		g_xBridge.wVrVf  = wXPrime(g_xBridge.wVrVf, CalRatios.wVrVf[CAL_LOAD_HIGH], CalRatios.wVrVf[CAL_LOAD_HIGH2], TRUE_MODGAMMA_HIGH, TRUE_MODGAMMA_HIGH2);	
		}
	}
	
	// Vr>Vf represents a failure in the assumptions in the calibration model and is better corrected by a simple cap
	// Also calculating SWRx100 in WORD from PRECISIONxVr/Vf needs PRECISIONxVr/Vf slightly less than PRECISION, so cap at that value rather than PRECISION  
	if(g_xBridge.wVrVf > VR_OVER_VF_MAX) g_xBridge.wVrVf = VR_OVER_VF_MAX;
	
/*
	// write cal for this frequency
	for (bLoad=0; bLoad < CAL_LOAD_MAX; bLoad++) {
		utoa(g_buffer16, CalRatios.wVzVa[bLoad], 10);	UART_PutString(g_buffer16); UART_PutChar(',');
	}
	for (bLoad=0; bLoad < CAL_LOAD_MAX; bLoad++) {
		utoa(g_buffer16, CalRatios.wVrVf[bLoad], 10);	UART_PutString(g_buffer16); UART_PutChar(',');
	}	
*/

}
//-----------------------------------------------------------------------------
//  FUNCTION NAME:	wXPrime(DWORD dwX, DWORD dwX1, DWORD dwX2, DWORD dwXPrime1, DWORD dwXPrime2)
//
//  DESCRIPTION:
//
//	Maps the range dwX1 .. dwX2 onto dwX1' .. dwX2'
//  dwX>dwX2 is OK but note simple linear extrapolation based on X and X' ranges
//  dwX1' < dwX2' is OK provided both are positive and note that the return value must be positive 
//  Result is artificially enforced to be no less than zero and no greater than 
//  WORD_MAX (so no wrap around in WORD)
//  The function works to the precision set by the PRECISION #def
//
//  ARGUMENTS:
//		dwX - the value to map
//		dwX1, dwX2, dwX1', dwX2' end points of the mapping ranges
//
//  RETURNS:
//     dwX' - the input value mapped into the range dwX1' .. dwX2'
//
//-----------------------------------------------------------------------------
static WORD wXPrime(DWORD dwX, DWORD dwX1, DWORD dwX2, DWORD dwXPrime1, DWORD dwXPrime2)
{
	DWORD deltaX = (dwX > dwX1)? (dwX - dwX1):(dwX1 - dwX);
	DWORD rangeX = (dwX2 > dwX1)? (dwX2 - dwX1):(dwX1 - dwX2);
	DWORD alpha = (DWORD)((DWORD)PRECISION*deltaX) / rangeX;
	long tmp= (long)((long)alpha * (long)dwXPrime2)/(long)PRECISION;
	tmp += (long)dwXPrime1*((long)PRECISION - (long)alpha)/(long)PRECISION;
	tmp = lNonNegative(tmp);
	tmp = ( tmp <= WORD_MAX )?  tmp:WORD_MAX;
	return (WORD)tmp;
}
//-----------------------------------------------------------------------------
//  FUNCTION NAME:	SetMeasureCalc()
//
//  DESCRIPTION: Set the DDS frequency, measure, do correction, do calcs
//
//  ARGUMENTS: none
//
//  RETURNS: none
//
//-----------------------------------------------------------------------------
void SetMeasureCalc(void)
{	
	DDS_Set(g_dwCurrHz);
	Delay_Ms(10);
	Do_Measure();
	Do_Correct();
	Do_SZRX_Calcs();
	if(g_bMode==MODE_CAP) Calculate_C();
	if(g_bMode==MODE_IND) Calculate_L();
}

//-----------------------------------------------------------------------------
//  FUNCTION NAME:	DisplayResults()
//
//  DESCRIPTION: Display results according to mode
//
//  ARGUMENTS: none
//
//  RETURNS: none
//
//-----------------------------------------------------------------------------
void DisplayResults(void)
{
	int iTmp;
	#define CAL_Vz_TO_mV 	1640
	#define CAL_Vz_TO_dBm 	370
	#define LOG_TO_dB		20
		
	if(g_bMode!=MODE_SIG) DISP_Frequency();	
	
	if(g_bMode==MODE_IMPD || g_bMode==MODE_IMPN) DISP_SRXZ();
	if(g_bMode==MODE_CAP) DISP_Capacitance();
	if(g_bMode==MODE_IND) DISP_Inductance();
	if(g_bMode==MODE_SIG) {
		iTmp=MeasureExternalRF();
	    DISP_Clear();
		LCD_Position(0, 0); LCD_PrCString(gPowerHeaderStr);
		LCD_Position(1, 0); LCD_PrCString(gPowerLabelsStr);
		itoa(g_buffer16,((LONG)iTmp*PRECISION)/CAL_Vz_TO_mV,10);
		LCD_Position(1, 3); LCD_PrString(g_buffer16);
		itoa(g_buffer16,(LOG_TO_dB * (iTmp-CAL_Vz_TO_dBm))/(iTmp+CAL_Vz_TO_dBm),10);
		LCD_Position(1, 12); LCD_PrString(g_buffer16);
	}
}	
//-----------------------------------------------------------------------------
//  FUNCTION NAME:	WaitLoadUser()
//
//  DESCRIPTION:
//
//	Wait for load and user action
//
//  ARGUMENTS:
//  	pszText	Text in display
//
//  RETURNS:
//     FALSE user abort
//
//-----------------------------------------------------------------------------
static BOOL WaitLoadUser (const char *pszText)
{
	DISP_Clear();
	LCD_Position(0, 0); LCD_PrCString(pszText);
	LCD_Position(1, 0); LCD_PrCString(gConfirmStr);
	BUZZ_Beep();
	if ( KEYPAD_WaitKey(TIME_WAIT_KEY_S) == KBD_UP )
		return FALSE;
	LCD_Position(1, 0); LCD_PrCString(gBlankStr_16);
	
	return TRUE;
}