// Online C compiler to run C program online
#include <stdio.h>
#include <string.h>
typedef char BYTE;
typedef unsigned long DWORD;
BYTE g_buffer16[16];

static void PrintX100toSerial(DWORD dwVal)
{
	size_t len;
	BYTE i;
//	itoa(g_buffer16, wVal , 10); len=strlen(g_buffer16);
    sprintf(g_buffer16, "%d", dwVal); len=strlen(g_buffer16);
    printf(g_buffer16);
    printf("|");
	if(len > 5) {
		printf("***.**");
	} else {
		if(len>2) {
		    for (i=0;i<len-2;i++) putc( g_buffer16[i], stdout );
		} else {
	    	printf("0");
	    }
		printf(".");
		if(len>1) {
		    putc( g_buffer16[len-2], stdout ); 
		} else {
	    	printf("0");
	    }
		putc( g_buffer16[len-1], stdout );
		printf(",");
	}
	printf("\n");
}

int main() {
    // Write C code here
    DWORD i;
    for (i=0;i<100;i++) PrintX100toSerial(i);

    return 0;
}