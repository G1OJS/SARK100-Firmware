// Online C compiler to run C program online
#include <stdio.h>
#include <string.h>
typedef unsigned BYTE;
typedef unsigned int WORD;
typedef unsigned long DWORD;
BYTE g_buffer16[16];

DWORD g_dwCurrHz;
DWORD finterp;

#define CAL_MAX	9
#define BAND_FREQ_ToHz	100000


const WORD g_wCalBoundaries[CAL_MAX] =
{10,41,142,270,294,439,507,550,600};

BYTE GetLowerCalBoundary (void)
{
	// bLowerCalBoundary is in the range (0 .. CAL_MAX - 2)
	// bLowerCalBoundary +1  is in the range (1 .. CAL_MAX - 1)

	BYTE bLowerCalBoundary = CAL_MAX-2;
	for (bLowerCalBoundary=0; bLowerCalBoundary < (CAL_MAX-2) ; bLowerCalBoundary++)
	{
		if (g_dwCurrHz < g_wCalBoundaries[bLowerCalBoundary+1]*BAND_FREQ_ToHz) break;
	}

	return bLowerCalBoundary;
}



DWORD dwGetCalFreqHz(BYTE bLowerCalBoundary)
{
	DWORD dwCalFreqHz=0;
//    if(bLowerCalBoundary>CAL_MAX-2) bLowerCalBoundary=CAL_MAX-2;

	// Set the freq at the middle of the frequency segment (g_wCalBoundaries[bLowerCalBoundary] to g_wCalBoundaries[bLowerCalBoundary+1])
	dwCalFreqHz=(DWORD)g_wCalBoundaries[bLowerCalBoundary]* BAND_FREQ_ToHz ;
		
	return dwCalFreqHz;
}

int main() {
BYTE i,bLowerCalBoundary,alpha;
    
    for (i=0;i<CAL_MAX-1;i++){
        g_dwCurrHz=dwGetCalFreqHz(i);
        bLowerCalBoundary=GetLowerCalBoundary();
        printf("%d %d %d %d",i,g_wCalBoundaries[i],bLowerCalBoundary,dwGetCalFreqHz(bLowerCalBoundary));
        printf("\n");        
    }
    
    g_dwCurrHz=1000000;
    do {
        bLowerCalBoundary=GetLowerCalBoundary();
		alpha=
		    (g_dwCurrHz-dwGetCalFreqHz(bLowerCalBoundary))
		    /
		    (dwGetCalFreqHz(bLowerCalBoundary+1)/256
		                -dwGetCalFreqHz(bLowerCalBoundary)/256);

        finterp=((dwGetCalFreqHz(bLowerCalBoundary)/1000) * (255-alpha)
                + alpha*(dwGetCalFreqHz(bLowerCalBoundary+1)/1000) +128)/255;

        printf("%d %d %d %d %d",g_dwCurrHz/1000,bLowerCalBoundary,dwGetCalFreqHz(bLowerCalBoundary), alpha,finterp);
        printf("\n");  
        g_dwCurrHz += 1000000;
    } while (g_dwCurrHz<60000001);



    return 0;
}

