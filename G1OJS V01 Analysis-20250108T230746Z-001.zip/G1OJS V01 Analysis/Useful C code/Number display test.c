#include <stdio.h>
#include <string.h>
#include <stdlib.h>

  typedef char BYTE;
  typedef unsigned long DWORD;
	char g_buffer16[16];


/**
 * Inserts a decimal point in a string representation of a number.
 *
 * @param buffer   The string buffer containing the number.
 *                 It should be null-terminated and have enough space for modifications.
 * @param dp_pos   The zero-based position from the right to insert the decimal point.
 *                 If dp_pos is 0, the decimal point is not inserted.
 */
void myFormatNumber(BYTE *buffer, BYTE dp_pos, BYTE maxLen) {
    BYTE ii;
	size_t len;
	
	len = strlen(buffer);
	if (len + ((dp_pos>0)? 1:0) > maxLen)			// string length > maxLen (or will be after '.' inserted)
	{
		for(ii=0; ii<maxLen; ii++) buffer[ii]='*';	// fill with * to indicate overflow
		buffer[maxLen]='\0';						// MUL terminate
	} 
	else
	{
    	if (dp_pos > 0) {        
        	if (dp_pos <= len) {  // Ensure dp_pos is within the string's length
            	memmove(buffer + len + 1 - dp_pos, buffer + len - dp_pos, dp_pos + 1);
            	buffer[len - dp_pos] = '.';
        	}
			if(dp_pos==len) // value represents number < 1 so add leading zero before dp
			{
				memmove(buffer +1 , buffer , len +1);  	// shift whole string to right by 1
				buffer[0]='0';										// put '0' in first position
			}
        // If dp_pos > len, the string is left unchanged
    	}
    	// If dp_pos == 0, do nothing
	}
}



void ultoSpecial(DWORD dwVal, BYTE maxLen)
{
  
	sprintf(g_buffer16, "%d",		(dwVal>=100)? dwVal/10:dwVal);
	myFormatNumber(g_buffer16,  (dwVal>=100)? 0:1	, maxLen);
}


int main(void)
{
  DWORD i;

  for (i=0;i<150;i++)
  {
    ultoSpecial(i,3);
    printf(g_buffer16);
    printf("\n");
  }
  
  for (i=9980;i<10100;i++)
  {
    ultoSpecial(i,3);
    printf(g_buffer16);
    printf("\n");
  }


	return 0;
}




