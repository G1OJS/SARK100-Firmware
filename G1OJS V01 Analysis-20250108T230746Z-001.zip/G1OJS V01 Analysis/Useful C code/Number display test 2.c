#include <stdio.h>
#include <string.h>
#include <stdlib.h>

  typedef char BYTE;
  typedef unsigned long DWORD;
	char g_buffer16[16];

void ultoSpecial(DWORD dwVal, BYTE maxLen)
{
	BYTE ii;
	BYTE len;

	if(dwVal<10){
    	sprintf(g_buffer16, "%d",dwVal);
    	len=strlen(g_buffer16);
		memmove(g_buffer16+2, g_buffer16, 2);
        g_buffer16[1]='.';
        g_buffer16[0]='0';
        g_buffer16[len+2]='\0';
    } else if(dwVal<100){
    	sprintf(g_buffer16, "%d",dwVal);
    	len=strlen(g_buffer16);
        memmove(g_buffer16+1, g_buffer16, 2);
        g_buffer16[1]='.';
        g_buffer16[len+1]='\0';
    } else {
    sprintf(g_buffer16, "%d",dwVal/10);
    }

    if(strlen(g_buffer16)>maxLen) {
		for(ii=0; ii<maxLen; ii++) g_buffer16[ii]='*';	// fill with * to indicate overflow
		g_buffer16[maxLen]='\0';						// NUL terminate
    }
}





int main(void)
{
  DWORD i;

  for (i=100;i<2000;i+=25)
  {
    ultoSpecial((i+5)/10,3);
    printf(g_buffer16);
    printf("|\n");
  }

  for (i=0;i<150;i++)
  {
    ultoSpecial(i,3);
    printf(g_buffer16);
    printf("|\n");
  }
  
  for (i=9980;i<10100;i++)
  {
    ultoSpecial(i,3);
    printf(g_buffer16);
    printf("|\n");
  }


	return 0;
}




