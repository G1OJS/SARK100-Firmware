import serial
import math

debug=False
global VSWR,modZ,R,X
global Vf,Vr,Vz,Va

def doCalcs():
  global VSWR,modZ,R,X
  VSWR=(Vf+Vr)/abs(Vf-Vr) if(Vf!=Vr) else 1000
  modZ=50*Vz/Va if(Va!=0) else 1000
  R=((50*50+modZ*modZ)*VSWR)/(50*(VSWR*VSWR+1))
  X=math.sqrt(abs(modZ*modZ-R*R))
  R="{:.1f}".format(R); X="{:.1f}".format(X); VSWR="{:.2f}".format(VSWR);modZ="{:.2f}".format(modZ)
 

def startComms():
  global sark
  sark = serial.Serial(port='COM7',baudrate=57600,timeout=1)
  print('Set Sark for PC link')
  while(sark.readline()==b''):
    pass
  while(sark.readline()!=b'>>'):
    pass
  print('Serial link OK')

def sendCmd(cmd):
  if(debug): print("cmd",cmd)
  sark.write((cmd+'\r\n').encode('utf-8'))

def getResponse():
  respraw=sark.readline()
  if(debug): print(respraw)
  resp=respraw.decode('utf-8').rstrip().split(',')

  return(resp)

def scan(fStart,fStop,fStep):
  headers= ['MHz','VSWR', 'Re(Z)','|Im(Z)|','|Z|'];

  fo=open("fScan.txt","w")
  for el in headers: 
    fo.write(el+'\t');
  fo.write('\n');

  sendCmd('scan '+str(fStart)+'000 '+str(fStop)+'000 '+str(fStep)+'000')
  resp=['']
  f=fStart
  while(resp[0]!='Start'):
    resp=getResponse()

  while(resp[0]!='End'):
    resp=getResponse();
    if(resp[0]!='End'):
      fo.write("{:.3f}".format(f/1000)+'\t');
      for el in resp: 
        fo.write(el+"\t");
      fo.write("\n")
      f+=fStep;
      print("f={:.3f}".format(f/1000),end="\r");
  fo.close();

def scanr(fStart,fStop,fStep):
  headers= ['MHz','Vf', 'Vr','Vz','Va'];

  fo=open("fScan.txt","w")
  for el in headers: 
    fo.write(el+'\t');
  fo.write('\n');

  sendCmd('scanr '+str(fStart)+'000 '+str(fStop)+'000 '+str(fStep)+'000')
  resp=['']
  f=fStart
  while(resp[0]!='Start'):
    resp=getResponse()

  while(resp[0]!='End'):
    resp=getResponse();
    if(resp[0]!='End'):
      fo.write("{:.3f}".format(f/1000)+'\t');
      for el in resp: 
        fo.write(el+"\t");
      fo.write("\n")
      f+=fStep;
      print("f={:.3f}".format(f/1000),end="\r");
  fo.close();

def scanrp(fStart,fStop,fStep):
  global Vf,Vr,Vz,Va
#  headers= ['MHz','Vfuc','Vruc','Vzuc','Vauc','VSWRuc','Re(Z)uc','Im(Z)uc','Zuc','Vf','Vr','Vz','Va','VSWR','Re(Z)','Im(Z)','Z','VrS','VrO','VzS','VzO','Va1S','Va1O','Va2S','Va2O','Vz0','Va0','Vac/o'];
  headers= ['MHz','Vfuc','Vruc','Vzuc','Vauc','VSWRuc','Re(Z)uc','Im(Z)uc','Zuc','Vf','Vr','Vz','Va','VSWR','Re(Z)','Im(Z)','Z','VrS','VrO','VzS','VzO','Va1S','Va1O','Va2S','Va2O','Vz0','Va0','Vac/o'];


  fo=open("fScan.txt","w")
  for el in headers: 
    fo.write(el+'\t');
  fo.write('\n');

  sendCmd('scanrp '+str(fStart)+'000 '+str(fStop)+'000 '+str(fStep)+'000')
  resp=['']
  f=fStart
  while(resp[0]!='Start'):
    resp=getResponse()
  while(resp[0]!='End'):
    resp=getResponse();
    if(resp[0]!='End'):

      fo.write("{:.3f}".format(f/1000)+'\t');
      for el in resp: 
        fo.write(el+"\t");
      fo.write("\n")

      print("f={:.3f} |Z|={:.1f} SWR={:.2f}".format(f/1000, float(resp[15]), float(resp[12]) ),end="\r");
      f+=fStep;
  fo.close();


startComms()

calcs='internal'

scanr(1000,60000,233)








